
import { GoogleGenAI, Type, Schema } from "@google/genai";
import { GeneratedSpec, FileData } from "../types";

// Define the schema for the output to ensure strict JSON structure matching the user's request.
const specSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    prompt_schema_version: { type: Type.STRING },
    request_timestamp: { type: Type.STRING },
    application_definition: {
      type: Type.OBJECT,
      properties: {
        application_name: { type: Type.STRING },
        marketing_slogan: { type: Type.STRING },
        description: { type: Type.STRING },
        target_audience: { type: Type.STRING },
        core_problem_statement: { type: Type.STRING },
        key_features: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              feature_id: { type: Type.STRING },
              feature_name: { type: Type.STRING },
              description: { type: Type.STRING },
              priority: { type: Type.STRING, enum: ["HIGH", "MEDIUM", "LOW"] },
              dependencies: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
            required: ["feature_id", "feature_name", "description", "priority", "dependencies"],
          },
        },
        user_stories: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              story_id: { type: Type.STRING },
              as_a: { type: Type.STRING },
              i_want_to: { type: Type.STRING },
              so_that: { type: Type.STRING },
              priority: { type: Type.STRING, enum: ["HIGH", "MEDIUM", "LOW"] },
            },
            required: ["story_id", "as_a", "i_want_to", "so_that", "priority"],
          },
        },
      },
      required: ["application_name", "marketing_slogan", "description", "target_audience", "core_problem_statement", "key_features", "user_stories"],
    },
    technical_specifications: {
      type: Type.OBJECT,
      properties: {
        preferred_tech_stack: {
          type: Type.OBJECT,
          properties: {
            frontend: { type: Type.ARRAY, items: { type: Type.STRING } },
            backend: { type: Type.ARRAY, items: { type: Type.STRING } },
            database: { type: Type.ARRAY, items: { type: Type.STRING } },
            cloud_platform: { type: Type.ARRAY, items: { type: Type.STRING } },
            containerization: { type: Type.ARRAY, items: { type: Type.STRING } },
            ci_cd_tooling: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          required: ["frontend", "backend", "database", "cloud_platform", "containerization", "ci_cd_tooling"],
        },
        scalability_requirements: { type: Type.STRING },
        security_compliance: { type: Type.ARRAY, items: { type: Type.STRING } },
        performance_metrics: {
          type: Type.OBJECT,
          properties: {
            response_time_ms: { type: Type.NUMBER },
            uptime_percentage: { type: Type.STRING },
            error_rate_percentage: { type: Type.STRING },
          },
          required: ["response_time_ms", "uptime_percentage", "error_rate_percentage"],
        },
      },
      required: ["preferred_tech_stack", "scalability_requirements", "security_compliance", "performance_metrics"],
    },
    ui_ux_guidelines: {
      type: Type.OBJECT,
      properties: {
        design_philosophy: { type: Type.STRING },
        branding_elements: {
          type: Type.OBJECT,
          properties: {
            color_palette_url: { type: Type.STRING },
            typography_guide_url: { type: Type.STRING },
          },
          required: ["color_palette_url", "typography_guide_url"],
        },
        accessibility_standards: { type: Type.ARRAY, items: { type: Type.STRING } },
      },
      required: ["design_philosophy", "branding_elements", "accessibility_standards"],
    },
    monetization_strategy: {
      type: Type.OBJECT,
      properties: {
        model_type: { type: Type.STRING },
        pricing_tiers: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              tier_name: { type: Type.STRING },
              features_included: { type: Type.ARRAY, items: { type: Type.STRING } },
              price_per_month: { type: Type.STRING },
            },
            required: ["tier_name", "features_included", "price_per_month"],
          },
        },
      },
      required: ["model_type", "pricing_tiers"],
    },
    development_methodology_preference: { type: Type.STRING },
    mermaid_diagram: { type: Type.STRING },
    additional_notes: { type: Type.STRING },
  },
  required: [
    "prompt_schema_version",
    "request_timestamp",
    "application_definition",
    "technical_specifications",
    "ui_ux_guidelines",
    "monetization_strategy",
    "development_methodology_preference",
    "mermaid_diagram",
    "additional_notes",
  ],
};

export const generateSpecification = async (idea: string, files: FileData[], language: 'vi' | 'en'): Promise<GeneratedSpec> => {
  if (!process.env.API_KEY) {
    throw new Error("API Key is missing.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  // Upgrade to Gemini 3.0 Pro Preview for superior reasoning in complex technical tasks.
  const model = "gemini-3-pro-preview";
  
  const textPrompt = `
    You are an elite Software Architect AI powered by Gemini 3.0, connected to the Quantum Event Mesh. 
    Your task is to take a high-level application idea (and any provided design documents or sketches) and expand it into a detailed, professional technical specification.
    
    The user's idea/description is: "${idea}"

    ${files.length > 0 ? "The user has also attached images or documents. Please analyze them carefully to understand the visual design, architecture, or requirements depicted and incorporate them into the specification." : ""}

    Please generate a comprehensive specification JSON based on this idea. 

    IMPORTANT: 
    1. The output language for all descriptions, features, user stories, and general text content MUST be in ${language === 'vi' ? 'Vietnamese' : 'English'}.
    2. Ensure the "application_name" is creative, modern, and unique.
    3. Ensure the "marketing_slogan" is catchy and short.
    4. Ensure technical choices are modern (e.g., React, Node, Go, Rust, K8s, Terraform, Supabase) and suitable for a scalable architecture.
    5. In the "mermaid_diagram" field, provide valid Mermaid.js code for a high-level System Architecture Diagram (e.g., C4 model or high-level flowchart) that visualizes the relationship between the Frontend, Backend, Database, and External Services. Use 'graph TD' or 'graph LR'. Do NOT include markdown code block syntax (e.g., \`\`\`mermaid).
    6. Populate the "request_timestamp" with the current ISO time.
    7. Use "3.0.0" for schema version to reflect the new engine.
  `;

  // Construct the contents with text and optional files
  const parts: any[] = [{ text: textPrompt }];

  files.forEach(file => {
    parts.push({
      inlineData: {
        mimeType: file.mimeType,
        data: file.data
      }
    });
  });

  try {
    const response = await ai.models.generateContent({
      model,
      contents: { parts },
      config: {
        responseMimeType: "application/json",
        responseSchema: specSchema,
        temperature: 0.45,
      },
    });

    if (response.text) {
      return JSON.parse(response.text) as GeneratedSpec;
    } else {
      throw new Error("No content generated");
    }
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};
