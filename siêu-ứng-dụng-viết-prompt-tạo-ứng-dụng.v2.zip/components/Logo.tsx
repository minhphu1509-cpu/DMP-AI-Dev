
import React from 'react';
import { Cpu } from 'lucide-react';

export const Logo: React.FC = () => {
  return (
    <div className="flex items-center gap-3 select-none">
      <div className="relative group">
        <div className="absolute -inset-1 bg-gradient-to-r from-quantum-accent to-quantum-secondary rounded-full blur opacity-25 group-hover:opacity-75 transition duration-1000 group-hover:duration-200"></div>
        <div className="relative p-2 bg-quantum-900 ring-1 ring-gray-900/5 rounded-xl leading-none flex items-center justify-center">
          <Cpu className="w-8 h-8 text-quantum-accent animate-pulse-fast" />
        </div>
      </div>
      <div className="flex flex-col">
        <span className="text-xl font-bold tracking-tight text-white">
          QUANTUM<span className="text-quantum-accent">.ARCHITECT</span>
        </span>
        <span className="text-[10px] text-gray-500 font-mono tracking-widest uppercase">Event Mesh Protocol v3.0</span>
      </div>
    </div>
  );
};
