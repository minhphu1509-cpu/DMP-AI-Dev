import React, { useState } from 'react';
import { GeneratedSpec } from '../types';
import { 
  Layers, Server, Database, Globe, ShieldCheck, TrendingUp, Users, Target,
  Code2, Box, Zap, DollarSign, Palette, Layout, Download, Copy, Share2, Workflow, Check
} from 'lucide-react';
import { MermaidDiagram } from './MermaidDiagram';

interface SpecificationViewProps {
  spec: GeneratedSpec;
  onReset: () => void;
  language: 'vi' | 'en';
}

const TEXT = {
  en: {
    startNew: "NEW PROJECT",
    problem: "Problem Statement",
    target: "Target Audience",
    techStack: "Technical Stack",
    frontend: "Frontend",
    backend: "Backend",
    data: "Data",
    infra: "Infrastructure",
    coreFeatures: "Core Features",
    dependsOn: "DEPENDS ON",
    metrics: "Metrics & Compliance",
    responseTime: "Response Time",
    uptime: "Uptime SLA",
    security: "Security",
    strategy: "Monetization",
    featuresIncluded: "Features included",
    design: "Design Guidelines",
    exportJSON: "Export JSON",
    copyJson: "Copy JSON",
    jsonCopied: "JSON Copied!",
    copyMarkdown: "Copy Markdown",
    diagram: "Architecture Diagram (Mermaid.js)",
    copied: "Copied!",
    copy: "Copy Code"
  },
  vi: {
    startNew: "DỰ ÁN MỚI",
    problem: "Vấn Đề Cốt Lõi",
    target: "Đối Tượng Mục Tiêu",
    techStack: "Ngăn Xếp Kỹ Thuật",
    frontend: "Frontend",
    backend: "Backend",
    data: "Dữ Liệu",
    infra: "Hạ Tầng",
    coreFeatures: "Tính Năng Cốt Lõi",
    dependsOn: "PHỤ THUỘC VÀO",
    metrics: "Chỉ Số & Tuân Thủ",
    responseTime: "Thời Gian Phản Hồi",
    uptime: "Cam Kết (SLA)",
    security: "Bảo Mật",
    strategy: "Chiến Lược Kiếm Tiền",
    featuresIncluded: "Tính năng bao gồm",
    design: "Hướng Dẫn Thiết Kế",
    exportJSON: "Xuất JSON",
    copyJson: "Sao Chép JSON",
    jsonCopied: "Đã Chép JSON!",
    copyMarkdown: "Sao Chép Markdown",
    diagram: "Biểu Đồ Kiến Trúc (Mermaid.js)",
    copied: "Đã chép!",
    copy: "Sao chép"
  }
};

const Card: React.FC<{ title: string; icon: React.ReactNode; children: React.ReactNode; className?: string }> = ({ title, icon, children, className = "" }) => (
  <div className={`bg-quantum-800/40 backdrop-blur-md border border-quantum-700/50 rounded-2xl p-6 hover:border-quantum-accent/40 hover:shadow-[0_0_20px_rgba(0,240,255,0.05)] transition duration-300 ${className}`}>
    <div className="flex items-center gap-3 mb-4 border-b border-white/5 pb-3">
      <div className="p-2 bg-gradient-to-br from-quantum-800 to-quantum-900 rounded-lg text-quantum-accent shadow-inner ring-1 ring-white/10">
        {icon}
      </div>
      <h3 className="text-lg font-bold text-white tracking-wide">{title}</h3>
    </div>
    {children}
  </div>
);

const TechBadge: React.FC<{ label: string }> = ({ label }) => (
  <span className="px-3 py-1.5 rounded-lg bg-quantum-900/80 border border-quantum-700 text-xs font-mono text-cyan-200 hover:bg-quantum-accent hover:text-quantum-900 hover:border-quantum-accent transition cursor-default shadow-sm">
    {label}
  </span>
);

export const SpecificationView: React.FC<SpecificationViewProps> = ({ spec, onReset, language }) => {
  const { application_definition: app, technical_specifications: tech, monetization_strategy: money, ui_ux_guidelines: ui } = spec;
  const t = TEXT[language];
  const [copied, setCopied] = useState(false);
  const [jsonCopied, setJsonCopied] = useState(false);

  const handleDownloadJson = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(spec, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", `${app.application_name.replace(/\s+/g, '_').toLowerCase()}_spec.json`);
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  const handleCopyJson = () => {
    navigator.clipboard.writeText(JSON.stringify(spec, null, 2));
    setJsonCopied(true);
    setTimeout(() => setJsonCopied(false), 2000);
  };

  const handleCopyDiagram = () => {
    navigator.clipboard.writeText(spec.mermaid_diagram);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 py-8 animate-fade-in-up pb-20">
      {/* Header Actions */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <button 
          onClick={onReset}
          className="flex items-center gap-2 px-4 py-2 rounded-lg border border-quantum-700 text-gray-400 hover:text-white hover:bg-quantum-800 transition text-sm font-mono group"
        >
          <div className="w-2 h-2 rounded-full bg-gray-500 group-hover:bg-red-500 transition"></div>
          {t.startNew}
        </button>
        <div className="flex gap-3">
          <button 
            onClick={handleCopyJson} 
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-quantum-800/50 text-quantum-accent border border-quantum-700 hover:bg-quantum-700 transition text-sm font-bold shadow-lg shadow-quantum-accent/5"
          >
            {jsonCopied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            {jsonCopied ? t.jsonCopied : t.copyJson}
          </button>
          <button onClick={handleDownloadJson} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-quantum-800 text-quantum-accent border border-quantum-700 hover:bg-quantum-700 transition text-sm font-bold shadow-lg shadow-quantum-accent/5">
            <Download className="w-4 h-4" />
            {t.exportJSON}
          </button>
        </div>
      </div>

      {/* Hero Title */}
      <div className="mb-12 text-center md:text-left relative">
        <div className="absolute top-0 right-0 p-4 opacity-10 hidden md:block">
           <Code2 className="w-32 h-32 text-quantum-accent" />
        </div>
        <h1 className="text-5xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-100 to-quantum-accent mb-4 tracking-tight">
          {app.application_name}
        </h1>
        <p className="text-xl md:text-2xl text-quantum-accent font-light mb-4 font-mono">{app.marketing_slogan}</p>
        <p className="text-gray-400 max-w-3xl text-lg leading-relaxed">{app.description}</p>
      </div>

      {/* Grid Layout */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 mb-8">
        {/* Core Info - Takes full width on mobile, 8 cols on desktop */}
        <div className="md:col-span-8 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card title={t.problem} icon={<Target className="w-5 h-5" />}>
               <p className="text-gray-300 leading-relaxed text-sm">{app.core_problem_statement}</p>
            </Card>
            <Card title={t.target} icon={<Users className="w-5 h-5" />}>
               <p className="text-gray-300 text-sm">{app.target_audience}</p>
            </Card>
          </div>

          {/* Architecture Diagram */}
          <div className="bg-[#0d0e1a] border border-quantum-700/50 rounded-2xl overflow-hidden shadow-2xl">
            <div className="bg-[#151725] px-4 py-3 border-b border-quantum-800 flex justify-between items-center">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <Workflow className="w-4 h-4 text-pink-500" />
                {t.diagram}
              </div>
              <button 
                onClick={handleCopyDiagram}
                className="text-xs flex items-center gap-1 text-gray-400 hover:text-white transition"
              >
                {copied ? <span className="text-green-400">{t.copied}</span> : (
                  <>
                    <Copy className="w-3 h-3" />
                    {t.copy}
                  </>
                )}
              </button>
            </div>
            <div className="overflow-hidden">
               <MermaidDiagram code={spec.mermaid_diagram} />
            </div>
          </div>

          {/* Tech Stack Matrix */}
          <div className="bg-gradient-to-br from-quantum-900 to-[#0c0d18] rounded-2xl p-6 border border-quantum-700/50">
            <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
              <Layers className="text-quantum-accent" />
              {t.techStack}
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-white/5 p-4 rounded-xl border border-white/5">
                <div className="flex items-center gap-2 mb-3 text-purple-400 font-bold text-sm uppercase tracking-wider">
                  <Layout className="w-4 h-4" /> {t.frontend}
                </div>
                <div className="flex flex-wrap gap-2">
                  {tech.preferred_tech_stack.frontend.map(t => <TechBadge key={t} label={t} />)}
                </div>
              </div>
              <div className="bg-white/5 p-4 rounded-xl border border-white/5">
                <div className="flex items-center gap-2 mb-3 text-green-400 font-bold text-sm uppercase tracking-wider">
                  <Server className="w-4 h-4" /> {t.backend}
                </div>
                <div className="flex flex-wrap gap-2">
                  {tech.preferred_tech_stack.backend.map(t => <TechBadge key={t} label={t} />)}
                </div>
              </div>
              <div className="bg-white/5 p-4 rounded-xl border border-white/5">
                <div className="flex items-center gap-2 mb-3 text-blue-400 font-bold text-sm uppercase tracking-wider">
                  <Database className="w-4 h-4" /> {t.data}
                </div>
                <div className="flex flex-wrap gap-2">
                  {tech.preferred_tech_stack.database.map(t => <TechBadge key={t} label={t} />)}
                </div>
              </div>
              <div className="bg-white/5 p-4 rounded-xl border border-white/5">
                <div className="flex items-center gap-2 mb-3 text-orange-400 font-bold text-sm uppercase tracking-wider">
                  <Box className="w-4 h-4" /> {t.infra}
                </div>
                <div className="flex flex-wrap gap-2">
                  {[...tech.preferred_tech_stack.cloud_platform, ...tech.preferred_tech_stack.containerization].map(t => <TechBadge key={t} label={t} />)}
                </div>
              </div>
            </div>
          </div>

           {/* Features List */}
           <div className="space-y-4">
             <h3 className="text-xl font-bold text-white flex items-center gap-2">
               <Zap className="text-yellow-400" />
               {t.coreFeatures}
             </h3>
             <div className="grid gap-4">
               {app.key_features.map((feat) => (
                 <div key={feat.feature_id} className="group relative bg-quantum-800/30 p-5 rounded-xl border border-quantum-700/50 hover:bg-quantum-800/60 transition hover:border-l-4 hover:border-l-quantum-accent">
                   <div className="flex justify-between items-start mb-2">
                      <h4 className="font-bold text-white text-lg group-hover:text-quantum-accent transition">{feat.feature_name}</h4>
                      <span className={`text-[10px] px-2 py-1 rounded border font-mono ${
                        feat.priority === 'HIGH' ? 'border-red-500/50 text-red-400 bg-red-500/10' : 
                        feat.priority === 'MEDIUM' ? 'border-yellow-500/50 text-yellow-400 bg-yellow-500/10' : 
                        'border-blue-500/50 text-blue-400 bg-blue-500/10'
                      }`}>
                        {feat.priority}
                      </span>
                   </div>
                   <p className="text-gray-400 text-sm mb-3">{feat.description}</p>
                   {feat.dependencies.length > 0 && (
                     <div className="flex items-center gap-2 text-xs text-gray-500">
                       <span className="font-mono text-quantum-accent">{t.dependsOn}:</span>
                       {feat.dependencies.map(d => <span key={d} className="bg-white/5 px-1.5 rounded">{d}</span>)}
                     </div>
                   )}
                 </div>
               ))}
             </div>
          </div>
        </div>

        {/* Sidebar - Takes 4 cols on desktop */}
        <div className="md:col-span-4 space-y-6">
           {/* Metrics */}
           <div className="bg-quantum-900/50 p-6 rounded-2xl border border-quantum-700/50">
             <h3 className="text-lg font-bold text-white flex items-center gap-2 mb-4">
               <TrendingUp className="text-green-400 w-5 h-5" />
               {t.metrics}
             </h3>
             <div className="space-y-4">
                <div className="flex justify-between items-center pb-2 border-b border-white/5">
                  <span className="text-sm text-gray-400">{t.responseTime}</span>
                  <span className="text-lg font-mono text-white">{tech.performance_metrics.response_time_ms}ms</span>
                </div>
                <div className="flex justify-between items-center pb-2 border-b border-white/5">
                  <span className="text-sm text-gray-400">{t.uptime}</span>
                  <span className="text-lg font-mono text-green-400">{tech.performance_metrics.uptime_percentage}</span>
                </div>
                <div className="pt-2">
                  <span className="text-sm text-gray-400 block mb-2">{t.security}</span>
                  <div className="flex flex-wrap gap-2">
                    {tech.security_compliance.map(s => (
                      <span key={s} className="text-xs border border-green-500/30 text-green-400 px-2 py-1 rounded bg-green-500/5">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
             </div>
           </div>

           {/* Monetization */}
           <div className="bg-quantum-900/50 p-6 rounded-2xl border border-quantum-700/50">
             <h3 className="text-lg font-bold text-white flex items-center gap-2 mb-4">
               <DollarSign className="text-emerald-400 w-5 h-5" />
               {t.strategy}
             </h3>
             <p className="text-xs text-gray-400 uppercase tracking-widest mb-3">{money.model_type}</p>
             <div className="space-y-3">
               {money.pricing_tiers.map(tier => (
                 <div key={tier.tier_name} className="p-3 rounded-lg bg-white/5 border border-white/5 hover:border-emerald-500/30 transition">
                   <div className="flex justify-between items-center mb-1">
                     <div className="font-bold text-white">{tier.tier_name}</div>
                     <div className="font-mono text-emerald-400 text-sm">{tier.price_per_month}</div>
                   </div>
                   <div className="text-xs text-gray-500">{tier.features_included.length} {t.featuresIncluded}</div>
                 </div>
               ))}
             </div>
           </div>

           {/* UX Design */}
           <div className="bg-gradient-to-br from-purple-900/10 to-pink-900/10 p-6 rounded-2xl border border-pink-500/20">
             <h3 className="text-lg font-bold text-white flex items-center gap-2 mb-4">
               <Palette className="text-pink-400 w-5 h-5" />
               {t.design}
             </h3>
             <p className="text-sm italic text-gray-300 mb-4 border-l-2 border-pink-500 pl-3">"{ui.design_philosophy}"</p>
             <div className="flex flex-wrap gap-2">
               {ui.accessibility_standards.map(std => (
                 <span key={std} className="text-[10px] uppercase tracking-wider bg-pink-500/20 px-2 py-1 rounded text-pink-200 border border-pink-500/20">{std}</span>
               ))}
             </div>
           </div>
        </div>
      </div>
    </div>
  );
};