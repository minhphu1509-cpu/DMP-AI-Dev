
import React, { useEffect, useState } from 'react';
import { Terminal } from 'lucide-react';

interface LoadingTerminalProps {
  language: 'vi' | 'en';
}

const LOGS = {
  en: [
    "Initializing Quantum Core v3.0...",
    "Connecting to Gemini 3.0 Neural Mesh...",
    "Upgrading semantic context [PRO LEVEL]...",
    "Allocating massive reasoning resources...",
    "Synthesizing advanced architecture pattern...",
    "Optimizing database schemas (Zero-latency)...",
    "Constructing scalable API interfaces...",
    "Applying Enterprise-grade security...",
    "Validating logic integrity...",
    "Compiling Gemini 3.0 specification artifact..."
  ],
  vi: [
    "Khởi tạo Lõi Lượng Tử v3.0...",
    "Kết nối Mạng Lưới Gemini 3.0...",
    "Nâng cấp ngữ cảnh ngữ nghĩa [CẤP PRO]...",
    "Phân bổ tài nguyên suy luận đa chiều...",
    "Tổng hợp mô hình kiến trúc nâng cao...",
    "Tối ưu hóa lược đồ cơ sở dữ liệu...",
    "Xây dựng giao diện API mở rộng...",
    "Áp dụng bảo mật cấp doanh nghiệp...",
    "Kiểm tra tính toàn vẹn logic...",
    "Biên dịch tạo tác kỹ thuật Gemini 3.0..."
  ]
};

export const LoadingTerminal: React.FC<LoadingTerminalProps> = ({ language }) => {
  const [lines, setLines] = useState<string[]>([]);
  const allLogs = LOGS[language];

  useEffect(() => {
    let currentIndex = 0;
    
    // Initial line
    setLines([`> ${allLogs[0]}`]);

    const interval = setInterval(() => {
      currentIndex++;
      if (currentIndex < allLogs.length) {
        setLines(prev => {
          const newLines = [...prev, `> ${allLogs[currentIndex]}`];
          // Keep only last 6 lines
          return newLines.slice(-6);
        });
      } else {
        clearInterval(interval);
      }
    }, 800);

    return () => clearInterval(interval);
  }, [language]);

  return (
    <div className="w-full max-w-2xl mx-auto my-12 animate-fade-in">
      <div className="bg-[#0a0b14] border border-quantum-700 rounded-xl overflow-hidden shadow-[0_0_30px_rgba(0,240,255,0.1)]">
        {/* Terminal Header */}
        <div className="bg-[#131525] px-4 py-2 flex items-center gap-2 border-b border-quantum-800">
          <div className="flex gap-1.5">
            <div className="w-3 h-3 rounded-full bg-red-500/50"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-500/50"></div>
            <div className="w-3 h-3 rounded-full bg-green-500/50"></div>
          </div>
          <div className="flex-1 text-center text-xs font-mono text-gray-500 flex items-center justify-center gap-2">
            <Terminal className="w-3 h-3" />
            root@quantum-architect-v3:~
          </div>
        </div>
        
        {/* Terminal Body */}
        <div className="p-6 font-mono text-sm md:text-base min-h-[200px] flex flex-col justify-end">
          {lines.map((line, idx) => (
            <div key={idx} className="text-quantum-accent/90 mb-1 last:animate-pulse last:font-bold">
              {line}
            </div>
          ))}
          <div className="flex items-center gap-2 mt-2">
            <span className="text-green-500">➜</span>
            <span className="w-2.5 h-5 bg-quantum-accent animate-pulse"></span>
          </div>
        </div>
      </div>
    </div>
  );
};
