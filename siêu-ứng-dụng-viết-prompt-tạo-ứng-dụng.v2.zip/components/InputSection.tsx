
import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, ArrowRight, Command, Paperclip, X, FileText, Image as ImageIcon } from 'lucide-react';
import { LoadingTerminal } from './LoadingTerminal';
import { FileData } from '../types';

interface InputSectionProps {
  onGenerate: (idea: string, files: FileData[]) => void;
  isGenerating: boolean;
  language: 'vi' | 'en';
}

const TEXT = {
  en: {
    titleStart: "Architect Your",
    titleEnd: "Digital Reality",
    description: "Initialize the Quantum Event Mesh. Describe your application concept, upload sketches or specs, and our AI core will construct a comprehensive technical specification.",
    placeholder: "e.g., A decentralized social network for urban gardeners...",
    buttonDefault: "Initialize",
    buttonProcessing: "Initializing Core...",
    systemOnline: "System Online",
    meshConnected: "Mesh Connected",
    hint: "Press Enter to submit, Shift+Enter for new line",
    uploadTip: "Upload images or PDFs"
  },
  vi: {
    titleStart: "Kiến Tạo",
    titleEnd: "Thực Tại Số Của Bạn",
    description: "Khởi tạo Mạng Lưới Sự Kiện Lượng Tử. Mô tả ý tưởng, tải lên bản phác thảo, và lõi AI của chúng tôi sẽ xây dựng thông số kỹ thuật toàn diện ngay lập tức.",
    placeholder: "Ví dụ: Một mạng xã hội phi tập trung cho người làm vườn đô thị...",
    buttonDefault: "Khởi Tạo",
    buttonProcessing: "Đang Khởi Tạo...",
    systemOnline: "Hệ Thống Online",
    meshConnected: "Đã Kết Nối Mesh",
    hint: "Nhấn Enter để gửi, Shift+Enter để xuống dòng",
    uploadTip: "Tải lên ảnh hoặc PDF"
  }
};

export const InputSection: React.FC<InputSectionProps> = ({ onGenerate, isGenerating, language }) => {
  const [idea, setIdea] = useState('');
  const [files, setFiles] = useState<FileData[]>([]);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const t = TEXT[language];

  // Auto-resize textarea logic
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      const scrollHeight = textareaRef.current.scrollHeight;
      // Cap height at 300px, then scroll
      const maxHeight = 300;
      textareaRef.current.style.height = `${Math.min(scrollHeight, maxHeight)}px`;
      textareaRef.current.style.overflowY = scrollHeight > maxHeight ? 'auto' : 'hidden';
    }
  }, [idea]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (idea.trim() || files.length > 0) {
      onGenerate(idea, files);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    // Submit on Enter (without Shift)
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (idea.trim() || files.length > 0) {
        onGenerate(idea, files);
      }
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newFiles: FileData[] = [];
      const fileList = Array.from(e.target.files) as File[];

      for (const file of fileList) {
        // Simple base64 conversion
        const base64 = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.readAsDataURL(file);
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = error => reject(error);
        });

        // Remove the data URL prefix (e.g., "data:image/png;base64,")
        const base64Data = base64.split(',')[1];
        
        newFiles.push({
          mimeType: file.type,
          data: base64Data,
          fileName: file.name
        });
      }

      setFiles(prev => [...prev, ...newFiles]);
      // Reset input so same file can be selected again if needed (though we append)
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const removeFile = (index: number) => {
    setFiles(files.filter((_, i) => i !== index));
  };

  if (isGenerating) {
    return <LoadingTerminal language={language} />;
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-4">
      <h1 className="text-5xl md:text-7xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white via-gray-200 to-gray-500 mb-6 tracking-tighter animate-fade-in-up">
        {t.titleStart} <br />
        <span className="text-transparent bg-clip-text bg-gradient-to-r from-quantum-accent to-quantum-secondary">
          {t.titleEnd}
        </span>
      </h1>
      
      <p className="text-gray-400 max-w-2xl text-lg mb-10 leading-relaxed animate-fade-in-up delay-100">
        {t.description}
      </p>

      <form onSubmit={handleSubmit} className="w-full max-w-3xl relative group animate-fade-in-up delay-200 text-left">
        <div className="absolute -inset-1 bg-gradient-to-r from-quantum-accent to-quantum-secondary rounded-2xl blur opacity-20 group-hover:opacity-40 transition duration-500"></div>
        <div className="relative flex flex-col bg-quantum-800 rounded-2xl border border-quantum-700 p-4 shadow-2xl transition-all duration-300 focus-within:border-quantum-accent/50 focus-within:shadow-[0_0_30px_rgba(0,240,255,0.1)]">
          
          {/* Files Preview */}
          {files.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-3 px-2">
              {files.map((file, idx) => (
                <div key={idx} className="flex items-center gap-2 bg-quantum-900/80 border border-quantum-700 rounded-lg px-3 py-1.5 text-xs font-mono text-gray-300 animate-fade-in">
                  {file.mimeType.includes('image') ? (
                    <ImageIcon className="w-3 h-3 text-purple-400" />
                  ) : (
                    <FileText className="w-3 h-3 text-blue-400" />
                  )}
                  <span className="truncate max-w-[150px]">{file.fileName}</span>
                  <button 
                    type="button" 
                    onClick={() => removeFile(idx)}
                    className="hover:text-red-400 transition ml-1"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          )}

          <div className="flex gap-4">
            <div className="pt-3 pl-2 text-gray-500">
              <Command className="w-6 h-6" />
            </div>
            <textarea 
              ref={textareaRef}
              value={idea}
              onChange={(e) => setIdea(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={isGenerating}
              placeholder={t.placeholder}
              rows={1}
              className="flex-1 bg-transparent border-none outline-none text-white text-lg placeholder-gray-600 font-medium focus:ring-0 resize-none min-h-[80px] py-2 overflow-hidden"
            />
          </div>
          
          <div className="flex justify-between items-center mt-2 md:pl-12 pl-2 pr-2 border-t border-white/5 pt-3">
             <div className="flex items-center gap-4">
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleFileChange} 
                  className="hidden" 
                  multiple 
                  accept="image/*,application/pdf"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="text-gray-500 hover:text-quantum-accent transition flex items-center gap-1.5 text-sm font-medium px-2 py-1 rounded-lg hover:bg-white/5"
                  title={t.uploadTip}
                >
                  <Paperclip className="w-4 h-4" />
                  <span className="hidden sm:inline">{t.uploadTip}</span>
                </button>
                <div className="text-xs text-gray-600 font-mono hidden md:block select-none border-l border-white/10 pl-4">
                  {t.hint}
                </div>
             </div>

            <button 
              type="submit"
              disabled={(!idea.trim() && files.length === 0) || isGenerating}
              className={`
                flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold transition-all duration-300
                ${(!idea.trim() && files.length === 0) || isGenerating 
                  ? 'bg-quantum-700 text-gray-500 cursor-not-allowed' 
                  : 'bg-white text-quantum-900 hover:bg-quantum-accent hover:scale-105 active:scale-95 shadow-[0_0_20px_rgba(255,255,255,0.3)]'
                }
              `}
            >
              {isGenerating ? (
                <>
                  <Sparkles className="w-5 h-5 animate-spin" />
                  <span>{t.buttonProcessing}</span>
                </>
              ) : (
                <>
                  <span>{t.buttonDefault}</span>
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </button>
          </div>
        </div>
      </form>

      <div className="mt-8 flex gap-4 text-sm text-gray-500 font-mono animate-fade-in-up delay-300">
        <span className="flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
          {t.systemOnline}
        </span>
        <span className="flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-quantum-accent"></span>
          {t.meshConnected}
        </span>
      </div>
    </div>
  );
};
