import React, { useEffect, useState } from 'react';
import mermaid from 'mermaid';

interface MermaidDiagramProps {
  code: string;
}

// Initialize mermaid with the quantum theme colors
mermaid.initialize({
  startOnLoad: false,
  theme: 'base',
  securityLevel: 'loose',
  fontFamily: 'JetBrains Mono',
  themeVariables: {
    darkMode: true,
    background: '#0d0e1a',
    primaryColor: '#1c1f36',
    primaryTextColor: '#e2e8f0',
    primaryBorderColor: '#7000ff',
    lineColor: '#00f0ff',
    secondaryColor: '#131525',
    tertiaryColor: '#0a0b14',
    fontFamily: 'JetBrains Mono'
  }
});

export const MermaidDiagram: React.FC<MermaidDiagramProps> = ({ code }) => {
  const [svg, setSvg] = useState<string>('');
  const [error, setError] = useState<boolean>(false);

  useEffect(() => {
    const render = async () => {
      // Clean up code if it has markdown blocks just in case the AI adds them
      const cleanCode = code.replace(/```mermaid/g, '').replace(/```/g, '').trim();
      
      if (!cleanCode) return;

      try {
        setError(false);
        const id = `mermaid-${Math.random().toString(36).substr(2, 9)}`;
        const { svg } = await mermaid.render(id, cleanCode);
        setSvg(svg);
      } catch (err) {
        console.error('Mermaid render failed:', err);
        setError(true);
      }
    };

    render();
  }, [code]);

  if (error) {
    return (
      <div className="p-4 text-red-400 text-xs font-mono bg-red-900/10 rounded border border-red-500/20">
        <p className="mb-2 font-bold">Diagram Render Error</p>
        <pre className="whitespace-pre-wrap">{code}</pre>
      </div>
    );
  }

  return (
    <div 
      className="w-full flex justify-center p-6 bg-[#0d0e1a] overflow-x-auto"
      dangerouslySetInnerHTML={{ __html: svg }} 
    />
  );
};