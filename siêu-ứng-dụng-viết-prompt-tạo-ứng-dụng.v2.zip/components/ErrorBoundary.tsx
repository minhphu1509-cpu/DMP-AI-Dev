import React, { ErrorInfo, ReactNode } from 'react';
import { ShieldAlert, RefreshCw, Terminal, AlertTriangle } from 'lucide-react';

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null
  };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // In a real app, you would log this to a service like Sentry
    console.error("Quantum Core Integrity Failure:", error, errorInfo);
  }

  handleReload = () => {
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#050505] text-white flex items-center justify-center p-4 font-mono relative overflow-hidden selection:bg-red-500/30">
            {/* Ambient Background for Error State */}
            <div className="absolute inset-0 z-0">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-red-600 to-transparent opacity-50"></div>
                <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-red-600 to-transparent opacity-50"></div>
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(220,38,38,0.1)_0%,transparent_70%)]"></div>
            </div>

            <div className="relative z-10 max-w-xl w-full bg-[#0a0b14] border border-red-500/30 rounded-2xl shadow-[0_0_60px_rgba(220,38,38,0.15)] backdrop-blur-xl overflow-hidden animate-fade-in-up">
                {/* Header Strip */}
                <div className="bg-red-950/30 px-6 py-3 border-b border-red-500/20 flex items-center justify-between">
                    <div className="flex items-center gap-2 text-red-500">
                        <Terminal className="w-4 h-4" />
                        <span className="text-xs font-bold tracking-widest">SYSTEM_CRITICAL_EVENT</span>
                    </div>
                    <div className="flex gap-1.5">
                        <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
                        <div className="w-2 h-2 rounded-full bg-red-500/50"></div>
                        <div className="w-2 h-2 rounded-full bg-red-500/20"></div>
                    </div>
                </div>

                <div className="p-8 flex flex-col items-center text-center">
                    <div className="mb-6 relative group">
                        <div className="absolute -inset-4 bg-red-500/20 rounded-full blur-xl group-hover:bg-red-500/30 transition duration-500"></div>
                        <ShieldAlert className="w-24 h-24 text-red-500 relative z-10 drop-shadow-[0_0_15px_rgba(239,68,68,0.5)]" />
                    </div>
                    
                    <h1 className="text-2xl md:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-b from-white to-red-200 mb-2 tracking-tight">
                        MÃ PHÒNG VỆ KÍCH HOẠT
                    </h1>
                    <p className="text-red-400 font-bold text-sm tracking-widest uppercase mb-6 opacity-80">
                        APP CRASH PROTECTION PROTOCOL
                    </p>
                    
                    <p className="text-gray-400 text-sm mb-8 max-w-md leading-relaxed">
                        Hệ thống đã phát hiện một dị thường nghiêm trọng trong luồng xử lý. 
                        Để bảo vệ dữ liệu, Mạng Lưới Sự Kiện đã cô lập thành phần bị lỗi.
                        <br/><span className="italic text-xs opacity-50 mt-2 block">(A runtime anomaly has been isolated to prevent cascade failure.)</span>
                    </p>

                    {/* Error Log */}
                    <div className="w-full bg-[#050505] rounded-lg border border-red-900/30 p-4 mb-8 text-left relative group">
                        <div className="absolute top-2 right-2 text-[10px] text-gray-600 uppercase">Stack Trace Snippet</div>
                        <div className="flex items-start gap-3">
                            <AlertTriangle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                            <code className="text-red-300 text-xs break-all font-mono">
                                {this.state.error?.toString() || "Unknown Error"}
                            </code>
                        </div>
                    </div>

                    <button 
                        onClick={this.handleReload}
                        className="group relative inline-flex items-center gap-3 px-8 py-3 bg-red-600 hover:bg-red-500 text-white rounded-xl font-bold transition-all duration-200 shadow-[0_0_20px_rgba(220,38,38,0.3)] hover:shadow-[0_0_30px_rgba(220,38,38,0.5)] hover:-translate-y-0.5"
                    >
                        <RefreshCw className="w-5 h-5 group-hover:rotate-180 transition-transform duration-500" />
                        <span>KHỞI ĐỘNG LẠI HỆ THỐNG</span>
                    </button>
                </div>
                
                {/* Footer Strip */}
                <div className="bg-[#050505] px-6 py-2 border-t border-red-500/10 flex justify-between items-center text-[10px] text-gray-600 font-mono uppercase">
                    <span>ERR_CODE: 0xCRASH_PREVENTION</span>
                    <span>QUANTUM SECURE GUARD</span>
                </div>
            </div>
        </div>
      );
    }

    return this.props.children || null;
  }
}