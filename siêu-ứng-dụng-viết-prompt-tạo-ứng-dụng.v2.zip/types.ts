
export interface Feature {
  feature_id: string;
  feature_name: string;
  description: string;
  priority: "HIGH" | "MEDIUM" | "LOW";
  dependencies: string[];
}

export interface UserStory {
  story_id: string;
  as_a: string;
  i_want_to: string;
  so_that: string;
  priority: "HIGH" | "MEDIUM" | "LOW";
}

export interface ApplicationDefinition {
  application_name: string;
  marketing_slogan: string;
  description: string;
  target_audience: string;
  core_problem_statement: string;
  key_features: Feature[];
  user_stories: UserStory[];
}

export interface TechnicalSpecifications {
  preferred_tech_stack: {
    frontend: string[];
    backend: string[];
    database: string[];
    cloud_platform: string[];
    containerization: string[];
    ci_cd_tooling: string[];
  };
  scalability_requirements: string;
  security_compliance: string[];
  performance_metrics: {
    response_time_ms: number;
    uptime_percentage: string;
    error_rate_percentage: string;
  };
}

export interface PricingTier {
  tier_name: string;
  features_included: string[];
  price_per_month: string;
}

export interface MonetizationStrategy {
  model_type: string;
  pricing_tiers: PricingTier[];
}

export interface UiUxGuidelines {
  design_philosophy: string;
  branding_elements: {
    color_palette_url: string;
    typography_guide_url: string;
  };
  accessibility_standards: string[];
}

export interface GeneratedSpec {
  prompt_schema_version: string;
  request_timestamp: string;
  application_definition: ApplicationDefinition;
  technical_specifications: TechnicalSpecifications;
  ui_ux_guidelines: UiUxGuidelines;
  monetization_strategy: MonetizationStrategy;
  development_methodology_preference: string;
  mermaid_diagram: string;
  additional_notes: string;
}

export interface FileData {
  mimeType: string;
  data: string;
  fileName: string;
}
