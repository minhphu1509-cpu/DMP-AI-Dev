
import React, { useState } from 'react';
import { Logo } from './components/Logo';
import { InputSection } from './components/InputSection';
import { SpecificationView } from './components/SpecificationView';
import { generateSpecification } from './services/geminiService';
import { GeneratedSpec, FileData } from './types';
import { AlertCircle, Code, Mail, Phone, Smartphone } from 'lucide-react';

const App: React.FC = () => {
  const [spec, setSpec] = useState<GeneratedSpec | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [language, setLanguage] = useState<'vi' | 'en'>('vi');

  const handleGenerate = async (idea: string, files: FileData[]) => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await generateSpecification(idea, files, language);
      setSpec(result);
    } catch (err: any) {
      console.error(err);
      setError(err.message || (language === 'vi' ? "Đã xảy ra lỗi không mong muốn khi giao tiếp với Quantum Mesh." : "An unexpected error occurred while communicating with the Quantum Mesh."));
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    setSpec(null);
    setError(null);
  };

  return (
    <div className="min-h-screen bg-[#050505] text-slate-200 selection:bg-quantum-accent selection:text-quantum-900 overflow-x-hidden flex flex-col">
      {/* Background Ambience */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-purple-900/10 rounded-full blur-[120px]"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-900/10 rounded-full blur-[120px]"></div>
        <div className="absolute top-[20%] left-[50%] w-[20%] h-[20%] bg-quantum-accent/5 rounded-full blur-[100px]"></div>
      </div>

      <header className="relative z-10 w-full p-6 flex justify-between items-center border-b border-white/5 bg-[#050505]/80 backdrop-blur-md sticky top-0">
        <Logo />
        <div className="flex items-center gap-6">
           <div className="flex items-center gap-1 bg-white/5 rounded-lg p-1 border border-white/10">
            <button 
              onClick={() => setLanguage('en')} 
              className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${language === 'en' ? 'bg-quantum-accent text-quantum-900 shadow-sm' : 'text-gray-400 hover:text-white'}`}
            >
              EN
            </button>
            <button 
              onClick={() => setLanguage('vi')} 
              className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${language === 'vi' ? 'bg-quantum-accent text-quantum-900 shadow-sm' : 'text-gray-400 hover:text-white'}`}
            >
              VI
            </button>
          </div>

          <div className="hidden md:flex items-center gap-4 text-xs font-mono text-gray-500">
            <span>{language === 'vi' ? 'TRẠNG THÁI: TRỰC TUYẾN' : 'STATUS: ONLINE'}</span>
            <span className="text-quantum-accent">•</span>
            <span>{language === 'vi' ? 'ĐỘ TRỄ: 5ms' : 'LATENCY: 5ms'}</span>
          </div>
        </div>
      </header>

      <main className="relative z-10 flex-grow">
        {error && (
          <div className="max-w-2xl mx-auto mt-8 p-4 bg-red-900/20 border border-red-500/50 rounded-xl flex items-center gap-3 text-red-200">
            <AlertCircle className="w-5 h-5" />
            <p>{error}</p>
          </div>
        )}

        {!spec ? (
          <InputSection onGenerate={handleGenerate} isGenerating={isLoading} language={language} />
        ) : (
          <SpecificationView spec={spec} onReset={handleReset} language={language} />
        )}
      </main>

      <footer className="relative z-10 py-12 text-center text-gray-600 text-sm font-mono border-t border-white/5 mt-auto bg-[#080910]">
        <div className="max-w-7xl mx-auto px-4">
            <p className="mb-8 tracking-widest opacity-70">{language === 'vi' ? 'ĐƯỢC CUNG CẤP BỞI GEMINI 3.0 PRO • GIAO THỨC QUANTUM EVENT MESH' : 'POWERED BY GEMINI 3.0 PRO • QUANTUM EVENT MESH PROTOCOL'}</p>
            
            <div className="flex flex-col md:flex-row justify-center items-center gap-6 md:gap-12 text-xs border-t border-white/5 pt-8">
                <div className="flex items-center gap-2 group">
                    <div className="p-2 rounded-full bg-white/5 group-hover:bg-quantum-accent/10 transition">
                        <Code className="w-4 h-4 text-quantum-accent" />
                    </div>
                    <span className="text-gray-400 group-hover:text-white transition">DMP AI Dev</span>
                </div>

                <a href="mailto:dmpaidev@gmail.com" className="flex items-center gap-2 group">
                    <div className="p-2 rounded-full bg-white/5 group-hover:bg-quantum-accent/10 transition">
                        <Mail className="w-4 h-4 text-quantum-accent" />
                    </div>
                    <span className="text-gray-400 group-hover:text-white transition">dmpaidev@gmail.com</span>
                </a>

                <a href="tel:+84766771509" className="flex items-center gap-2 group">
                    <div className="p-2 rounded-full bg-white/5 group-hover:bg-quantum-accent/10 transition">
                        <Phone className="w-4 h-4 text-quantum-accent" />
                    </div>
                    <span className="text-gray-400 group-hover:text-white transition">+84 766771509</span>
                </a>

                <div className="flex items-center gap-2 group cursor-pointer" title="Zalo">
                     <div className="p-2 rounded-full bg-white/5 group-hover:bg-quantum-accent/10 transition">
                        <Smartphone className="w-4 h-4 text-quantum-accent" />
                    </div>
                    <span className="text-gray-400 group-hover:text-white transition">Zalo: 0766771509</span>
                </div>
            </div>
            
            <div className="mt-8 text-[10px] text-gray-700">
                © {new Date().getFullYear()} QUANTUM ARCHITECT. ALL RIGHTS RESERVED.
            </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
