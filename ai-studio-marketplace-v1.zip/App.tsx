import React, { lazy, Suspense, useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import FeaturedApps from './components/FeaturedApps';
import MarketplacePreview from './components/MarketplacePreview';
import SubmitCTA from './components/SubmitCTA';
import Footer from './components/Footer';
import ToastContainer from './components/ToastContainer';
import { useApp } from './hooks/useApp';
import AppFormModal from './components/AppFormModal';
import { useMarketplace } from './hooks/useMarketplace';
import { useToast } from './hooks/useToast';
import { useI18n } from './hooks/useI18n';
import { App as AppType, NewsPost, SiteContentKey, BilingualContent, ContactInfoContent } from './types';
import ContactPage from './components/ContactPage';
import ChatWidget from './components/ChatWidget';
import AppDetailModal from './components/AppDetailModal';
import LoadingSpinner from './components/LoadingSpinner';
import { useAuth } from './hooks/useAuth';
import { useNews } from './hooks/useNews';
import { useSiteContent } from './hooks/useSiteContent';

const OrderConfirmation = lazy(() => import('./components/OrderConfirmation'));
const CheckoutPage = lazy(() => import('./components/CheckoutPage'));
const TermsOfService = lazy(() => import('./components/TermsOfService'));
const PrivacyPolicyPage = lazy(() => import('./components/PrivacyPolicyPage'));
const LoginPage = lazy(() => import('./components/LoginPage'));
const SignupPage = lazy(() => import('./components/SignupPage'));
const MarketplacePage = lazy(() => import('./components/MarketplacePage'));
const AnalyticsDashboard = lazy(() => import('./components/AnalyticsDashboard'));
const SiteManagementPage = lazy(() => import('./components/SiteManagementPage'));
const AppManagementPage = lazy(() => import('./components/AppManagementPage'));
const SplashScreen = lazy(() => import('./components/SplashScreen'));
const BlogPage = lazy(() => import('./components/BlogPage'));
const NewsManagementPage = lazy(() => import('./components/NewsManagementPage'));
const NewsFormModal = lazy(() => import('./components/NewsFormModal'));
const ContentEditModal = lazy(() => import('./components/ContentEditModal'));
const CareersPage = lazy(() => import('./components/CareersPage'));
const PressPage = lazy(() => import('./components/PressPage'));
const AboutPage = lazy(() => import('./components/AboutPage'));
const AdminLoginPage = lazy(() => import('./components/AdminLoginPage'));
const ProfilePage = lazy(() => import('./components/ProfilePage'));


const App: React.FC = () => {
  const { 
    view, 
    isAppFormModalOpen, appToEdit, closeAppFormModal, 
    isAppDetailModalOpen, selectedApp, closeAppDetailModal,
    isNewsFormModalOpen, newsPostToEdit, closeNewsFormModal,
    isContentEditModalOpen, contentToEdit, closeContentEditModal
  } = useApp();
  const { addApp, updateApp } = useMarketplace();
  const { addNewsPost, updateNewsPost } = useNews();
  const { updateSiteContent } = useSiteContent();
  const { showToast } = useToast();
  const { t } = useI18n();
  const { isAdmin } = useAuth();
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    try {
      if (sessionStorage.getItem('splash_seen')) {
        setShowSplash(false);
      } else {
        sessionStorage.setItem('splash_seen', 'true');
      }
    } catch (e) {
      // If sessionStorage is not available, just hide the splash screen
      setShowSplash(false);
    }
  }, []);

  const handleSplashComplete = () => {
    setShowSplash(false);
  };
  
  const renderView = () => {
    const adminOnlyViews: (typeof view)[] = ['analytics', 'site_management', 'app_management', 'news_management'];
    const isAccessingAdminView = adminOnlyViews.includes(view);

    if (isAccessingAdminView && !isAdmin) {
       return (
          <>
            <Hero />
            <FeaturedApps />
            <MarketplacePreview />
            <SubmitCTA />
          </>
        );
    }
    
    switch(view) {
      case 'marketplace':
        return (
          <>
            <Hero />
            <FeaturedApps />
            <MarketplacePreview />
            <SubmitCTA />
          </>
        );
      case 'marketplace_full':
        return <MarketplacePage />;
      case 'checkout':
        return <CheckoutPage />;
      case 'confirmation':
        return <OrderConfirmation />;
      case 'terms':
        return <TermsOfService />;
      case 'privacy':
        return <PrivacyPolicyPage />;
      case 'login':
        return <LoginPage />;
      case 'signup':
        return <SignupPage />;
      case 'contact':
        return <ContactPage />;
      case 'analytics':
        return <AnalyticsDashboard />;
      case 'site_management':
        return <SiteManagementPage />;
      case 'app_management':
        return <AppManagementPage />;
      case 'blog':
        return <BlogPage />;
      case 'news_management':
        return <NewsManagementPage />;
      case 'careers':
        return <CareersPage />;
      case 'press':
        return <PressPage />;
      case 'about':
        return <AboutPage />;
      case 'admin_login':
        return <AdminLoginPage />;
      case 'profile':
        return <ProfilePage />;
      default:
        return null;
    }
  }
  
  const handleSaveApp = (appData: AppType) => {
    if (appToEdit) {
      updateApp(appData);
      showToast(t('app_updated_successfully'), 'success');
    } else {
      addApp(appData);
      showToast(t('app_added_successfully'), 'success');
    }
    closeAppFormModal();
  };
  
  const handleSaveNewsPost = (postData: NewsPost) => {
    if (newsPostToEdit) {
      updateNewsPost(postData);
      showToast(t('post_updated_successfully'), 'success');
    } else {
      addNewsPost(postData);
      showToast(t('post_added_successfully'), 'success');
    }
    closeNewsFormModal();
  };
  
  const handleSaveContent = (key: SiteContentKey, content: BilingualContent | ContactInfoContent) => {
    updateSiteContent(key, content);
    showToast(t('content_updated_successfully'), 'success');
    closeContentEditModal();
  };

  return (
    <div className="bg-[#0f0f0f] text-[#EAEAEA] min-h-screen">
       <Suspense fallback={<div className="fixed inset-0 bg-[#0f0f0f]" />}>
        {showSplash && <SplashScreen onComplete={handleSplashComplete} />}
      </Suspense>
      <Header />
      <main>
        <Suspense fallback={<LoadingSpinner />}>
          {renderView()}
        </Suspense>
      </main>
      <Footer />
      <ToastContainer />
      <AppFormModal
        isOpen={isAppFormModalOpen}
        onClose={closeAppFormModal}
        onSave={handleSaveApp}
        appToEdit={appToEdit}
      />
      <AppDetailModal
        isOpen={isAppDetailModalOpen}
        onClose={closeAppDetailModal}
        app={selectedApp}
      />
      <Suspense fallback={null}>
          <NewsFormModal
            isOpen={isNewsFormModalOpen}
            onClose={closeNewsFormModal}
            onSave={handleSaveNewsPost}
            postToEdit={newsPostToEdit}
          />
          <ContentEditModal
            isOpen={isContentEditModalOpen}
            onClose={closeContentEditModal}
            onSave={handleSaveContent}
            contentToEdit={contentToEdit}
          />
      </Suspense>
      <ChatWidget />
    </div>
  );
};

export default App;