import React, { createContext, useState, ReactNode, useEffect } from 'react';
import { User, PurchasedApp } from '../types';
import { useApp } from '../hooks/useApp';
import { useToast } from '../hooks/useToast';
import { useI18n } from '../hooks/useI18n';

interface AuthContextType {
  isAuthenticated: boolean;
  user: User | null;
  isAdmin: boolean;
  login: (email: string, password?: string) => void;
  signup: (email: string) => void;
  logout: () => void;
  updateProfile: (updatedData: Partial<Pick<User, 'displayName'>>) => void;
  addPurchaseToHistory: (items: PurchasedApp[]) => void;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    try {
        return window.localStorage.getItem('is-authenticated') === 'true';
    } catch {
        return false;
    }
  });
  const [user, setUser] = useState<User | null>(() => {
      try {
          const userJson = window.localStorage.getItem('user-data');
          return userJson ? JSON.parse(userJson) : null;
      } catch {
          return null;
      }
  });
  const [isAdmin, setIsAdmin] = useState<boolean>(() => {
    try {
        return window.localStorage.getItem('is-admin') === 'true';
    } catch {
        return false;
    }
  });

  const { backToMarketplace, postLoginAction, clearPostLoginAction, openAppFormModal, goToAppManagement } = useApp();
  const { showToast } = useToast();
  const { t } = useI18n();

  useEffect(() => {
    try {
      if (isAuthenticated && user) {
        window.localStorage.setItem('is-authenticated', 'true');
        window.localStorage.setItem('user-data', JSON.stringify(user));
        if (isAdmin) {
            window.localStorage.setItem('is-admin', 'true');
        } else {
            window.localStorage.removeItem('is-admin');
        }
      } else {
        window.localStorage.removeItem('is-authenticated');
        window.localStorage.removeItem('user-data');
        window.localStorage.removeItem('is-admin');
      }
    } catch (error) {
      console.error("Error saving auth state to localStorage", error);
    }
  }, [isAuthenticated, user, isAdmin]);


  const handlePostAuth = (email: string, displayName?: string) => {
    const mockUser: User = { 
        email,
        displayName: displayName || email.split('@')[0],
        purchaseHistory: []
    };
    setUser(mockUser);
    setIsAuthenticated(true);
    showToast(t('welcome_back'), 'success');

    if (postLoginAction === 'submit_app') {
      openAppFormModal(null);
      clearPostLoginAction();
    }
    
    backToMarketplace();
  }

  const login = (email: string, password?: string) => {
    // Simulate API call
    setTimeout(() => {
        // By default, dmpaidev@gmail.com has admin rights.
        if (email.toLowerCase() === 'dmpaidev@gmail.com' && password === 'Phu@1976') {
            // Admin Login Flow
            const mockUser: User = { email, displayName: 'Admin', purchaseHistory: [] };
            setUser(mockUser);
            setIsAuthenticated(true);
            setIsAdmin(true);
            showToast(t('welcome_back'), 'success');
            goToAppManagement(); // Redirect admin to the management page
        } else {
            // Regular User Login Flow
            setIsAdmin(false);
            handlePostAuth(email);
        }
    }, 1500);
  };
  
  const signup = (email: string) => {
    setIsAdmin(false);
    // Simulate API call
    setTimeout(() => {
      handlePostAuth(email);
    }, 1500);
  };

  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
    setIsAdmin(false);
    backToMarketplace();
  };

  const updateProfile = (updatedData: Partial<Pick<User, 'displayName'>>) => {
    setUser(prevUser => {
        if (!prevUser) return null;
        return { ...prevUser, ...updatedData };
    });
  };

  const addPurchaseToHistory = (items: PurchasedApp[]) => {
      setUser(prevUser => {
          if (!prevUser) return null;
          const newHistory = [...(prevUser.purchaseHistory || []), ...items];
          return { ...prevUser, purchaseHistory: newHistory };
      });
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, user, isAdmin, login, signup, logout, updateProfile, addPurchaseToHistory }}>
      {children}
    </AuthContext.Provider>
  );
};