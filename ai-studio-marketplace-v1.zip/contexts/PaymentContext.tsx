import React, { createContext, useState, ReactNode, useContext } from 'react';
import { PaymentMethod, PurchasedApp, App } from '../types';
import { useApp } from '../hooks/useApp';
import { useCart } from '../hooks/useCart';
import { useToast } from '../hooks/useToast';
import { useI18n } from '../hooks/useI18n';
import { AnalyticsContext } from './AnalyticsContext';
import { getPriceAsNumber } from '../utils/formatters';
import { useAuth } from '../hooks/useAuth';

interface PaymentContextType {
  selectedMethod: PaymentMethod | null;
  isProcessing: boolean;
  selectMethod: (method: PaymentMethod) => void;
  processPayment: (items: App[]) => void;
}

export const PaymentContext = createContext<PaymentContextType | undefined>(undefined);

interface PaymentProviderProps {
  children: ReactNode;
}

export const PaymentProvider: React.FC<PaymentProviderProps> = ({ children }) => {
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod>('bank');
  const [isProcessing, setIsProcessing] = useState(false);
  const { completeCheckout } = useApp();
  const { clearCart } = useCart();
  const { showToast } = useToast();
  const { t } = useI18n();
  const { logEvent } = useContext(AnalyticsContext) ?? {};
  const { addPurchaseToHistory } = useAuth();

  const selectMethod = (method: PaymentMethod) => {
    setSelectedMethod(method);
  };

  const processPayment = (items: App[]) => {
    if (!selectedMethod || items.length === 0) return;

    setIsProcessing(true);
    showToast(t('processing_payment'), 'info');
    logEvent?.('CHECKOUT_START');

    // Simulate payment processing
    setTimeout(() => {
      const purchasedItems: PurchasedApp[] = items.map(item => ({
        ...item,
        downloadUrl: `https://aistudio.dev/download/${item.id}/${Date.now()}${Math.random().toString(36).substring(2)}`
      }));
      
      const total = items.reduce((acc, item) => acc + getPriceAsNumber(item.price), 0);

      logEvent?.('ORDER_COMPLETED', {
        orderDetails: {
          items: purchasedItems,
          total,
        }
      });
      
      addPurchaseToHistory(purchasedItems);
      completeCheckout(purchasedItems);
      clearCart();
      setIsProcessing(false);
    }, 2500);
  };

  return (
    <PaymentContext.Provider value={{ selectedMethod, isProcessing, selectMethod, processPayment }}>
      {children}
    </PaymentContext.Provider>
  );
};