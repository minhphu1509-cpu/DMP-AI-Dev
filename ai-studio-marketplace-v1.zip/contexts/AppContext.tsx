import React, { createContext, useState, ReactNode } from 'react';
import { PurchasedApp, App, NewsPost, SiteContentKey, SiteContent, BilingualContent, ContactInfoContent } from '../types';

type View = 'marketplace' | 'checkout' | 'confirmation' | 'terms' | 'login' | 'signup' | 'marketplace_full' | 'contact' | 'privacy' | 'analytics' | 'site_management' | 'app_management' | 'blog' | 'news_management' | 'careers' | 'press' | 'about' | 'admin_login' | 'profile';
type PostLoginAction = 'submit_app' | null;
type ContentToEdit = { key: SiteContentKey; content: BilingualContent | ContactInfoContent };


interface AppContextType {
  view: View;
  purchasedItems: PurchasedApp[];
  isAppFormModalOpen: boolean;
  isAppDetailModalOpen: boolean;
  isNewsFormModalOpen: boolean;
  isContentEditModalOpen: boolean;
  selectedApp: App | null;
  appToEdit: App | null;
  newsPostToEdit: NewsPost | null;
  contentToEdit: ContentToEdit | null;
  postLoginAction: PostLoginAction;
  goToCheckout: () => void;
  completeCheckout: (items: PurchasedApp[]) => void;
  backToMarketplace: () => void;
  goToMarketplace: () => void;
  goToTerms: () => void;
  goToPrivacy: () => void;
  goToLogin: () => void;
  goToSignup: () => void;
  goToContact: () => void;
  goToAnalytics: () => void;
  goToSiteManagement: () => void;
  goToAppManagement: () => void;
  goToBlog: () => void;
  goToNewsManagement: () => void;
  goToCareers: () => void;
  goToPress: () => void;
  goToAbout: () => void;
  goToAdminLogin: () => void;
  goToProfile: () => void;
  openAppFormModal: (app: App | null) => void;
  closeAppFormModal: () => void;
  openAppDetailModal: (app: App) => void;
  closeAppDetailModal: () => void;
  openNewsFormModal: (post: NewsPost | null) => void;
  closeNewsFormModal: () => void;
  openContentEditModal: (key: SiteContentKey, content: BilingualContent | ContactInfoContent) => void;
  closeContentEditModal: () => void;
  setPostLoginAction: (action: PostLoginAction) => void;
  clearPostLoginAction: () => void;
}

export const AppContext = createContext<AppContextType | undefined>(undefined);

interface AppProviderProps {
  children: ReactNode;
}

export const AppProvider: React.FC<AppProviderProps> = ({ children }) => {
  const [view, setView] = useState<View>('marketplace');
  const [purchasedItems, setPurchasedItems] = useState<PurchasedApp[]>([]);
  const [isAppFormModalOpen, setIsAppFormModalOpen] = useState(false);
  const [isAppDetailModalOpen, setIsAppDetailModalOpen] = useState(false);
  const [isNewsFormModalOpen, setIsNewsFormModalOpen] = useState(false);
  const [isContentEditModalOpen, setIsContentEditModalOpen] = useState(false);
  const [selectedApp, setSelectedApp] = useState<App | null>(null);
  const [appToEdit, setAppToEdit] = useState<App | null>(null);
  const [newsPostToEdit, setNewsPostToEdit] = useState<NewsPost | null>(null);
  const [contentToEdit, setContentToEdit] = useState<ContentToEdit | null>(null);
  const [postLoginAction, setPostLoginAction] = useState<PostLoginAction>(null);


  const goToCheckout = () => setView('checkout');

  const completeCheckout = (items: PurchasedApp[]) => {
    setPurchasedItems(items);
    setView('confirmation');
  };

  const backToMarketplace = () => {
    setPurchasedItems([]);
    setView('marketplace');
  };

  const goToMarketplace = () => setView('marketplace_full');
  const goToTerms = () => setView('terms');
  const goToPrivacy = () => setView('privacy');
  const goToLogin = () => setView('login');
  const goToSignup = () => setView('signup');
  const goToContact = () => setView('contact');
  const goToAnalytics = () => setView('analytics');
  const goToSiteManagement = () => setView('site_management');
  const goToAppManagement = () => setView('app_management');
  const goToBlog = () => setView('blog');
  const goToNewsManagement = () => setView('news_management');
  const goToCareers = () => setView('careers');
  const goToPress = () => setView('press');
  const goToAbout = () => setView('about');
  const goToAdminLogin = () => setView('admin_login');
  const goToProfile = () => setView('profile');
  
  const openAppFormModal = (app: App | null) => {
    setAppToEdit(app);
    setIsAppFormModalOpen(true);
  };
  
  const closeAppFormModal = () => {
    setAppToEdit(null);
    setIsAppFormModalOpen(false);
  };

  const openAppDetailModal = (app: App) => {
    setSelectedApp(app);
    setIsAppDetailModalOpen(true);
  };

  const closeAppDetailModal = () => {
    setSelectedApp(null);
    setIsAppDetailModalOpen(false);
  };

  const openNewsFormModal = (post: NewsPost | null) => {
    setNewsPostToEdit(post);
    setIsNewsFormModalOpen(true);
  };
  
  const closeNewsFormModal = () => {
    setNewsPostToEdit(null);
    setIsNewsFormModalOpen(false);
  };

  const openContentEditModal = (key: SiteContentKey, content: BilingualContent | ContactInfoContent) => {
    setContentToEdit({ key, content });
    setIsContentEditModalOpen(true);
  };

  const closeContentEditModal = () => {
    setContentToEdit(null);
    setIsContentEditModalOpen(false);
  };
  
  const clearPostLoginAction = () => {
    setPostLoginAction(null);
  };

  return (
    <AppContext.Provider value={{ 
        view, 
        purchasedItems, 
        isAppFormModalOpen,
        isAppDetailModalOpen,
        isNewsFormModalOpen,
        isContentEditModalOpen,
        selectedApp,
        appToEdit,
        newsPostToEdit,
        contentToEdit,
        postLoginAction,
        goToCheckout, 
        completeCheckout, 
        backToMarketplace, 
        goToMarketplace, 
        goToTerms, 
        goToPrivacy,
        goToLogin, 
        goToSignup,
        goToContact,
        goToAnalytics,
        goToSiteManagement,
        goToAppManagement,
        goToBlog,
        goToNewsManagement,
        goToCareers,
        goToPress,
        goToAbout,
        goToAdminLogin,
        goToProfile,
        openAppFormModal,
        closeAppFormModal,
        openAppDetailModal,
        closeAppDetailModal,
        openNewsFormModal,
        closeNewsFormModal,
        openContentEditModal,
        closeContentEditModal,
        setPostLoginAction,
        clearPostLoginAction,
    }}>
      {children}
    </AppContext.Provider>
  );
};