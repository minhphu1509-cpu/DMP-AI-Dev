
import React, { createContext, useState, useCallback, ReactNode, useEffect } from 'react';
import { Locale } from '../types';
import { translations } from '../constants/translations';

interface I18nContextType {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  t: (key: string) => string;
}

export const I18nContext = createContext<I18nContextType | undefined>(undefined);

interface I18nProviderProps {
  children: ReactNode;
}

export const I18nProvider: React.FC<I18nProviderProps> = ({ children }) => {
  const [locale, setLocale] = useState<Locale>(() => {
    try {
      const storedLocale = window.localStorage.getItem('app-locale') as Locale;
      return ['vi', 'en'].includes(storedLocale) ? storedLocale : 'vi';
    } catch {
      return 'vi';
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem('app-locale', locale);
    } catch (error) {
      console.error("Error saving locale to localStorage", error);
    }
  }, [locale]);

  const t = useCallback((key: string) => {
    const keys = key.split('.');
    let result = translations[locale];
    for (const k of keys) {
      result = result?.[k];
      if (!result) {
        // Fallback to English if translation not found
        let fallbackResult = translations['en'];
        for(const fk of keys) {
           fallbackResult = fallbackResult?.[fk];
        }
        return fallbackResult || key;
      }
    }
    return result || key;
  }, [locale]);

  return (
    <I18nContext.Provider value={{ locale, setLocale, t }}>
      {children}
    </I18nContext.Provider>
  );
};