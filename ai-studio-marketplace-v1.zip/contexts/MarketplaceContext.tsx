import React, { createContext, useState, ReactNode, useMemo, useEffect } from 'react';
import { App, Review, Comment } from '../types';
import { mockApps } from '../constants/mockData';

interface MarketplaceContextType {
  apps: App[];
  addApp: (app: App) => void;
  updateApp: (updatedApp: App) => void;
  deleteApp: (appId: number) => void;
  addReview: (appId: number, review: Review) => void;
  addComment: (appId: number, comment: Omit<Comment, 'id' | 'timestamp'>) => void;
}

export const MarketplaceContext = createContext<MarketplaceContextType | undefined>(undefined);

interface MarketplaceProviderProps {
  children: ReactNode;
}

export const MarketplaceProvider: React.FC<MarketplaceProviderProps> = ({ children }) => {
  const [apps, setApps] = useState<App[]>(() => {
    try {
      const item = window.localStorage.getItem('marketplace-apps');
      return item ? JSON.parse(item) : mockApps;
    } catch (error) {
      console.error("Error parsing marketplace apps from localStorage", error);
      return mockApps;
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem('marketplace-apps', JSON.stringify(apps));
    } catch (error) {
      console.error("Error saving marketplace apps to localStorage", error);
    }
  }, [apps]);

  const addApp = (newApp: App) => {
    setApps(prevApps => [newApp, ...prevApps]);
  };

  const updateApp = (updatedApp: App) => {
    setApps(prevApps => prevApps.map(app => app.id === updatedApp.id ? updatedApp : app));
  };

  const deleteApp = (appId: number) => {
    setApps(prevApps => prevApps.filter(app => app.id !== appId));
  };
  
  const addReview = (appId: number, review: Review) => {
    setApps(prevApps =>
      prevApps.map(app => {
        if (app.id === appId) {
          const existingReviews = app.reviews || [];
          const newReviews = [review, ...existingReviews];
          const totalRating = newReviews.reduce((sum, r) => sum + r.rating, 0);
          const newAverageRating = totalRating / newReviews.length;

          return {
            ...app,
            reviews: newReviews,
            rating: parseFloat(newAverageRating.toFixed(1)),
            reviewCount: newReviews.length,
          };
        }
        return app;
      }),
    );
  };
  
  const addComment = (appId: number, commentData: Omit<Comment, 'id' | 'timestamp'>) => {
    const newComment: Comment = {
      ...commentData,
      id: Date.now(),
      timestamp: new Date().toISOString(),
    };
    
    setApps(prevApps =>
      prevApps.map(app => {
        if (app.id === appId) {
          return {
            ...app,
            comments: [ ...(app.comments || []), newComment ],
          };
        }
        return app;
      })
    );
  };

  const contextValue = useMemo(() => ({
    apps,
    addApp,
    updateApp,
    deleteApp,
    addReview,
    addComment,
  }), [apps]);

  return (
    <MarketplaceContext.Provider value={contextValue}>
      {children}
    </MarketplaceContext.Provider>
  );
};