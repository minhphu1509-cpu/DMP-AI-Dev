import React, { createContext, useState, ReactNode, useEffect, useCallback, useContext } from 'react';
import { AnalyticsEvent, AnalyticsEventType, PurchasedApp } from '../types';
import { AuthContext } from './AuthContext';

interface AnalyticsContextType {
  events: AnalyticsEvent[];
  logEvent: (type: AnalyticsEventType, data?: Record<string, any>) => void;
}

export const AnalyticsContext = createContext<AnalyticsContextType | undefined>(undefined);

interface AnalyticsProviderProps {
  children: ReactNode;
}

export const AnalyticsProvider: React.FC<AnalyticsProviderProps> = ({ children }) => {
  const [events, setEvents] = useState<AnalyticsEvent[]>(() => {
    try {
      const item = window.localStorage.getItem('analytics-events');
      return item ? JSON.parse(item) : [];
    } catch (error) {
      console.error("Error parsing analytics events from localStorage", error);
      return [];
    }
  });

  const { user } = useContext(AuthContext) ?? {};

  useEffect(() => {
    try {
      window.localStorage.setItem('analytics-events', JSON.stringify(events));
    } catch (error) {
      console.error("Error saving analytics events to localStorage", error);
    }
  }, [events]);

  const logEvent = useCallback((type: AnalyticsEventType, data: Record<string, any> = {}) => {
    const newEvent: AnalyticsEvent = {
      id: `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      type,
      timestamp: Date.now(),
      userId: user?.email,
      ...data,
    };
    setEvents(prev => [...prev, newEvent]);
  }, [user]);

  return (
    <AnalyticsContext.Provider value={{ events, logEvent }}>
      {children}
    </AnalyticsContext.Provider>
  );
};
