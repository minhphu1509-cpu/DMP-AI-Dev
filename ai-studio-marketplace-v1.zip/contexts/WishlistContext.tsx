import React, { createContext, useState, ReactNode, useMemo, useEffect } from 'react';
import { App } from '../types';

interface WishlistContextType {
  wishlistItems: App[];
  addToWishlist: (app: App) => void;
  removeFromWishlist: (appId: number) => void;
  isItemInWishlist: (appId: number) => boolean;
}

export const WishlistContext = createContext<WishlistContextType | undefined>(undefined);

interface WishlistProviderProps {
  children: ReactNode;
}

export const WishlistProvider: React.FC<WishlistProviderProps> = ({ children }) => {
  const [wishlistItems, setWishlistItems] = useState<App[]>(() => {
    try {
      const item = window.localStorage.getItem('wishlist-items');
      return item ? JSON.parse(item) : [];
    } catch (error) {
      console.error("Error parsing wishlist items from localStorage", error);
      return [];
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem('wishlist-items', JSON.stringify(wishlistItems));
    } catch (error) {
      console.error("Error saving wishlist items to localStorage", error);
    }
  }, [wishlistItems]);

  const addToWishlist = (app: App) => {
    setWishlistItems(prevItems => {
      if (!prevItems.find(item => item.id === app.id)) {
        return [...prevItems, app];
      }
      return prevItems;
    });
  };

  const removeFromWishlist = (appId: number) => {
    setWishlistItems(prevItems => prevItems.filter(item => item.id !== appId));
  };

  const isItemInWishlist = (appId: number) => {
    return wishlistItems.some(item => item.id === appId);
  };
  
  const contextValue = useMemo(() => ({
    wishlistItems,
    addToWishlist,
    removeFromWishlist,
    isItemInWishlist,
  }), [wishlistItems]);

  return (
    <WishlistContext.Provider value={contextValue}>
      {children}
    </WishlistContext.Provider>
  );
};