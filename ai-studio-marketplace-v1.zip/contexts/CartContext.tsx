import React, { createContext, useState, ReactNode, useMemo, useEffect, useContext } from 'react';
import { App } from '../types';
import { AnalyticsContext } from './AnalyticsContext';

interface CartContextType {
  cartItems: App[];
  addToCart: (app: App) => void;
  addMultipleToCart: (apps: App[]) => number;
  removeFromCart: (appId: number) => void;
  isItemInCart: (appId: number) => boolean;
  clearCart: () => void;
}

export const CartContext = createContext<CartContextType | undefined>(undefined);

interface CartProviderProps {
  children: ReactNode;
}

export const CartProvider: React.FC<CartProviderProps> = ({ children }) => {
  const [cartItems, setCartItems] = useState<App[]>(() => {
    try {
      const item = window.localStorage.getItem('cart-items');
      return item ? JSON.parse(item) : [];
    } catch (error) {
        console.error("Error parsing cart items from localStorage", error);
        return [];
    }
  });

  const { logEvent } = useContext(AnalyticsContext) ?? {};

  useEffect(() => {
    try {
        window.localStorage.setItem('cart-items', JSON.stringify(cartItems));
    } catch (error) {
        console.error("Error saving cart items to localStorage", error);
    }
  }, [cartItems]);

  const addToCart = (app: App) => {
    setCartItems(prevItems => {
      if (!prevItems.find(item => item.id === app.id)) {
        logEvent?.('ADD_TO_CART', { appId: app.id, appName: app.title.en });
        return [...prevItems, app];
      }
      return prevItems;
    });
  };

  const addMultipleToCart = (apps: App[]): number => {
    let newItemsCount = 0;
    setCartItems(prevItems => {
      const newItems = apps.filter(app => {
        const isInCart = prevItems.some(item => item.id === app.id);
        if(!isInCart){
            logEvent?.('ADD_TO_CART', { appId: app.id, appName: app.title.en });
        }
        return !isInCart;
      });
      newItemsCount = newItems.length;
      return [...prevItems, ...newItems];
    });
    return newItemsCount;
  };

  const removeFromCart = (appId: number) => {
    setCartItems(prevItems => prevItems.filter(item => item.id !== appId));
  };

  const isItemInCart = (appId: number) => {
    return cartItems.some(item => item.id === appId);
  };
  
  const clearCart = () => {
    setCartItems([]);
  };
  
  const contextValue = useMemo(() => ({
    cartItems,
    addToCart,
    addMultipleToCart,
    removeFromCart,
    isItemInCart,
    clearCart,
  }), [cartItems, logEvent]);

  return (
    <CartContext.Provider value={contextValue}>
      {children}
    </CartContext.Provider>
  );
};