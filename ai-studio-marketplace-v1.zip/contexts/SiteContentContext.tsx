import React, { createContext, useState, ReactNode, useMemo, useEffect } from 'react';
import { SiteContent, SiteContentKey, BilingualContent, ContactInfoContent } from '../types';

interface SiteContentContextType {
  siteContent: SiteContent;
  updateSiteContent: (key: SiteContentKey, content: BilingualContent | ContactInfoContent) => void;
}

export const SiteContentContext = createContext<SiteContentContextType | undefined>(undefined);

interface SiteContentProviderProps {
  children: ReactNode;
}

const initialContent: SiteContent = {
  terms: {
    vi: `Cập nhật lần cuối: 18 tháng 7, 2024\n\n1. Chấp nhận Điều khoản\nBằng cách truy cập hoặc sử dụng AI Studio Marketplace, bạn đồng ý bị ràng buộc bởi các Điều khoản Dịch vụ này. Nếu bạn không đồng ý với tất cả các điều khoản và điều kiện, thì bạn không được truy cập vào dịch vụ.\n\n2. Thay đổi Điều khoản\nChúng tôi có quyền sửa đổi hoặc thay thế các Điều khoản này bất kỳ lúc nào. Chúng tôi sẽ cố gắng cung cấp thông báo ít nhất 30 ngày trước khi bất kỳ điều khoản mới nào có hiệu lực. Việc bạn tiếp tục sử dụng Dịch vụ sau khi các sửa đổi đó có hiệu lực sẽ cấu thành sự thừa nhận và đồng ý của bạn với các điều khoản đã sửa đổi.`,
    en: `Last updated: July 18, 2024\n\n1. Acceptance of Terms\nBy accessing or using the AI Studio Marketplace, you agree to be bound by these Terms of Service. If you disagree with any part of the terms, then you may not access the service.\n\n2. Changes to Terms\nWe reserve the right to modify or replace these Terms at any time. We will try to provide at least 30 days' notice prior to any new terms taking effect. Your continued use of the Service after those revisions become effective constitutes your acknowledgment and agreement of the modified terms.`
  },
  privacy: {
    vi: `Cập nhật lần cuối: 18 tháng 7, 2024\n\n1. Thông tin chúng tôi thu thập\nChúng tôi thu thập thông tin bạn cung cấp trực tiếp cho chúng tôi, chẳng hạn như khi bạn tạo tài khoản, mua ứng dụng hoặc liên hệ với chúng tôi để được hỗ trợ. Thông tin này có thể bao gồm tên, địa chỉ email và thông tin thanh toán của bạn.\n\n2. Cách chúng tôi sử dụng thông tin của bạn\nChúng tôi sử dụng thông tin chúng tôi thu thập để cung cấp, duy trì và cải thiện dịch vụ của mình, xử lý các giao dịch, giao tiếp với bạn và cá nhân hóa trải nghiệm của bạn trên AI Studio Marketplace.\n\n3. Bảo mật dữ liệu\nChúng tôi thực hiện các biện pháp hợp lý để giúp bảo vệ thông tin về bạn khỏi mất mát, trộm cắp, lạm dụng và truy cập, tiết lộ, thay đổi và phá hủy trái phép.`,
    en: `Last updated: July 18, 2024\n\n1. Information We Collect\nWe collect information you provide directly to us, such as when you create an account, purchase an app, or contact us for support. This may include your name, email address, and payment information.\n\n2. How We Use Your Information\nWe use the information we collect to provide, maintain, and improve our services, process transactions, communicate with you, and personalize your experience on the AI Studio Marketplace.\n\n3. Data Security\nWe take reasonable measures to help protect information about you from loss, theft, misuse, and unauthorized access, disclosure, alteration, and destruction.`
  },
  about: {
    vi: 'Nội dung trang Về chúng tôi. Chỉnh sửa nội dung này trong bảng quản trị.',
    en: 'About Us page content. Edit this in the admin dashboard.'
  },
  careers: {
    vi: 'Nội dung trang Tuyển dụng. Chỉnh sửa nội dung này trong bảng quản trị.',
    en: 'Careers page content. Edit this in the admin dashboard.'
  },
  press: {
    vi: 'Nội dung trang Báo chí. Chỉnh sửa nội dung này trong bảng quản trị.',
    en: 'Press page content. Edit this in the admin dashboard.'
  },
  contact: {
    email: 'dmpaidev@gmail.com',
    phone: '+84 766771509',
    address_vi: '06 Nguyễn Bính, P. Vĩ Dạ, Tp Huế, Việt Nam',
    address_en: '06 Nguyen Binh, Vi Da Ward, Hue City, Vietnam',
    zalo: '0766771509',
    whatsapp: '+84766771509'
  }
};


export const SiteContentProvider: React.FC<SiteContentProviderProps> = ({ children }) => {
  const [siteContent, setSiteContent] = useState<SiteContent>(() => {
    try {
      const item = window.localStorage.getItem('site-content');
      return item ? JSON.parse(item) : initialContent;
    } catch (error) {
        console.error("Error parsing site content from localStorage", error);
        return initialContent;
    }
  });

  useEffect(() => {
    try {
        window.localStorage.setItem('site-content', JSON.stringify(siteContent));
    } catch (error) {
        console.error("Error saving site content to localStorage", error);
    }
  }, [siteContent]);

  const updateSiteContent = (key: SiteContentKey, content: BilingualContent | ContactInfoContent) => {
    setSiteContent(prev => ({
        ...prev,
        [key]: content,
    }));
  };
  
  const contextValue = useMemo(() => ({
    siteContent,
    updateSiteContent
  }), [siteContent]);

  return (
    <SiteContentContext.Provider value={contextValue}>
      {children}
    </SiteContentContext.Provider>
  );
};
