import React, { createContext, useState, ReactNode, useMemo, useEffect } from 'react';
import { NewsPost } from '../types';
import { mockNewsPosts } from '../constants/mockData';

interface NewsContextType {
  newsPosts: NewsPost[];
  addNewsPost: (post: Omit<NewsPost, 'id' | 'timestamp'>) => void;
  updateNewsPost: (updatedPost: NewsPost) => void;
  deleteNewsPost: (postId: number) => void;
}

export const NewsContext = createContext<NewsContextType | undefined>(undefined);

interface NewsProviderProps {
  children: ReactNode;
}

export const NewsProvider: React.FC<NewsProviderProps> = ({ children }) => {
  const [newsPosts, setNewsPosts] = useState<NewsPost[]>(() => {
    try {
      const item = window.localStorage.getItem('news-posts');
      return item ? JSON.parse(item) : mockNewsPosts;
    } catch (error) {
      console.error("Error parsing news posts from localStorage", error);
      return mockNewsPosts;
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem('news-posts', JSON.stringify(newsPosts));
    } catch (error) {
      console.error("Error saving news posts to localStorage", error);
    }
  }, [newsPosts]);

  const addNewsPost = (postData: Omit<NewsPost, 'id' | 'timestamp'>) => {
    const newPost: NewsPost = {
      ...postData,
      id: Date.now(),
      timestamp: new Date().toISOString(),
    };
    setNewsPosts(prevPosts => [newPost, ...prevPosts]);
  };

  const updateNewsPost = (updatedPost: NewsPost) => {
    setNewsPosts(prevPosts => prevPosts.map(post => post.id === updatedPost.id ? updatedPost : post));
  };

  const deleteNewsPost = (postId: number) => {
    setNewsPosts(prevPosts => prevPosts.filter(post => post.id !== postId));
  };
  
  const contextValue = useMemo(() => ({
    newsPosts,
    addNewsPost,
    updateNewsPost,
    deleteNewsPost,
  }), [newsPosts]);

  return (
    <NewsContext.Provider value={contextValue}>
      {children}
    </NewsContext.Provider>
  );
};