export type Locale = 'vi' | 'en';

export type DemoImage = {
  url: string;
  caption: {
    vi: string;
    en: string;
  };
};

export interface Review {
  id: number;
  author: string;
  rating: number; // 1-5
  comment: string;
  date: string; // ISO 8601 format
}

export interface Comment {
  id: number;
  authorEmail: string;
  text: string;
  timestamp: string; // ISO 8601 format
}


export interface App {
  id: number;
  image: string;
  title: {
    vi: string;
    en: string;
  };
  description: {
    vi: string;
    en: string;
  };
  price: string;
  tags: string[];
  rating: number;
  reviewCount: number;
  demoImages?: DemoImage[];
  reviews?: Review[];
  comments?: Comment[];
}

export interface PurchasedApp extends App {
  downloadUrl: string;
}

export type ToastType = 'success' | 'error' | 'info';

export interface ToastMessage {
  id: number;
  message: string;
  type: ToastType;
}

export type PaymentMethod = 'bank' | 'momo' | 'paypal';

export interface User {
  email: string;
  displayName?: string;
  purchaseHistory?: PurchasedApp[];
}

// Analytics Types
export type AnalyticsEventType = 'APP_VIEW' | 'ADD_TO_CART' | 'CHECKOUT_START' | 'ORDER_COMPLETED';

export interface AnalyticsEvent {
  id: string;
  type: AnalyticsEventType;
  timestamp: number;
  userId?: string;
  appId?: number;
  appName?: string;
  orderDetails?: {
    items: PurchasedApp[];
    total: number;
  };
}

// News/Blog Types
export type NewsPostType = 'youtube' | 'social' | 'link';

export interface NewsPost {
  id: number;
  type: NewsPostType;
  url: string;
  title: {
    vi: string;
    en: string;
  };
  description: {
    vi: string;
    en: string;
  };
  source: string; // e.g., 'YouTube', 'Facebook', 'TechCrunch'
  timestamp: string; // ISO 8601 format
  imageUrl?: string; // Optional image for link previews
}

// Site Content Management Types
export type SiteContentKey = 'terms' | 'privacy' | 'about' | 'careers' | 'press' | 'contact';

export interface BilingualContent {
  vi: string;
  en: string;
}

export interface ContactInfoContent {
  email: string;
  phone: string;
  address_vi: string;
  address_en: string;
  zalo: string;
  whatsapp: string;
}

export interface SiteContent {
  terms: BilingualContent;
  privacy: BilingualContent;
  about: BilingualContent;
  careers: BilingualContent;
  press: BilingualContent;
  contact: ContactInfoContent;
}