export const getYoutubeVideoId = (url: string): string | null => {
  if (!url) return null;
  
  let videoId = null;
  
  // Standard youtube.com/watch?v=...
  const urlParams = new URLSearchParams(new URL(url).search);
  videoId = urlParams.get('v');
  if (videoId) return videoId;

  // Shortened youtu.be/...
  if (url.includes('youtu.be/')) {
    videoId = url.split('youtu.be/')[1].split('?')[0];
    if (videoId) return videoId;
  }
  
  // Embedded youtube.com/embed/...
  if (url.includes('/embed/')) {
    videoId = url.split('/embed/')[1].split('?')[0];
    if (videoId) return videoId;
  }
  
  return null;
};
