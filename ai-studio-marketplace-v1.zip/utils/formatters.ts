import { Locale } from '../types';

const USD_TO_VND_RATE = 25450;

export const getPriceAsNumber = (priceString: string): number => {
    if (!priceString) return 0;
    const numberPart = parseFloat(priceString.replace(/[^0-9.-]+/g, ''));
    return isNaN(numberPart) ? 0 : numberPart;
}

export const formatCurrency = (amount: number, locale: Locale): string => {
  if (locale === 'vi') {
    const vndAmount = amount * USD_TO_VND_RATE;
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(vndAmount);
  }

  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
}
