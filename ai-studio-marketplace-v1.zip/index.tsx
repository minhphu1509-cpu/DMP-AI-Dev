import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { I18nProvider } from './contexts/I18nContext';
import { CartProvider } from './contexts/CartContext';
import { WishlistProvider } from './contexts/WishlistContext';
import { ToastProvider } from './contexts/ToastContext';
import { AppProvider } from './contexts/AppContext';
import { PaymentProvider } from './contexts/PaymentContext';
import { AuthProvider } from './contexts/AuthContext';
import { MarketplaceProvider } from './contexts/MarketplaceContext';
import { AnalyticsProvider } from './contexts/AnalyticsContext';
import { NewsProvider } from './contexts/NewsContext';
import { SiteContentProvider } from './contexts/SiteContentContext';

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <I18nProvider>
      <AppProvider>
        <ToastProvider>
          <AuthProvider>
            <AnalyticsProvider>
              <SiteContentProvider>
                <MarketplaceProvider>
                  <NewsProvider>
                    <CartProvider>
                      <WishlistProvider>
                        <PaymentProvider>
                          <App />
                        </PaymentProvider>
                      </WishlistProvider>
                    </CartProvider>
                  </NewsProvider>
                </MarketplaceProvider>
              </SiteContentProvider>
            </AnalyticsProvider>
          </AuthProvider>
        </ToastProvider>
      </AppProvider>
    </I18nProvider>
  </React.StrictMode>
);