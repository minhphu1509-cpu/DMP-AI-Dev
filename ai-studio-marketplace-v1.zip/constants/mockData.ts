import { App, DemoImage, NewsPost } from '../types';

export const mockApps: App[] = [
  {
    id: 13,
    image: 'https://picsum.photos/seed/ai13/600/400',
    title: {
      vi: 'AI Tối ưu Quản trị Doanh nghiệp',
      en: 'AI Business Management Optimizer',
    },
    description: {
      vi: 'Tự động hóa các quy trình kinh doanh, quản lý tài chính và tối ưu hóa nguồn nhân lực.',
      en: 'Automate business processes, manage finances, and optimize human resources.',
    },
    price: '$199.99/mo',
    tags: ['Business', 'Management', 'Automation'],
    rating: 4.8,
    reviewCount: 110,
    demoImages: [
        { url: 'https://picsum.photos/seed/ai13_demo1/800/600', caption: { vi: 'Demo 1', en: 'Demo 1' } },
        { url: 'https://picsum.photos/seed/ai13_demo2/800/600', caption: { vi: 'Demo 2', en: 'Demo 2' } },
        { url: 'https://picsum.photos/seed/ai13_demo3/800/600', caption: { vi: 'Demo 3', en: 'Demo 3' } },
    ],
    reviews: [],
  },
  {
    id: 12,
    image: 'https://picsum.photos/seed/ai12/600/400',
    title: {
      vi: 'AI chăm sóc sắc đẹp',
      en: 'AI Beauty Care',
    },
    description: {
      vi: 'Phân tích làn da của bạn và đề xuất các sản phẩm và liệu trình chăm sóc da được cá nhân hóa.',
      en: 'Analyzes your skin and suggests personalized skincare products and routines.',
    },
    price: '$24.99',
    tags: ['Beauty', 'Skincare', 'Health'],
    rating: 4.8,
    reviewCount: 550,
    demoImages: [
        { url: 'https://picsum.photos/seed/ai12_demo1/800/600', caption: { vi: 'Demo 1', en: 'Demo 1' } },
        { url: 'https://picsum.photos/seed/ai12_demo2/800/600', caption: { vi: 'Demo 2', en: 'Demo 2' } },
    ],
    reviews: [],
  },
  {
    id: 11,
    image: 'https://picsum.photos/seed/ai11/600/400',
    title: {
      vi: 'AI Xem tướng pháp & chỉ tay',
      en: 'AI Physiognomy & Palm Reading',
    },
    description: {
      vi: 'Phân tích các đặc điểm trên khuôn mặt và đường chỉ tay để đưa ra những hiểu biết về tính cách và tương lai.',
      en: 'Analyzes facial features and palm lines to provide insights into personality and future.',
    },
    price: '$14.99',
    tags: ['Lifestyle', 'Divination'],
    rating: 4.7,
    reviewCount: 410,
    demoImages: [
        { url: 'https://picsum.photos/seed/ai11_demo1/800/600', caption: { vi: 'Demo 1', en: 'Demo 1' } },
    ],
    reviews: [],
  },
  {
    id: 10,
    image: 'https://picsum.photos/seed/ai10/600/400',
    title: {
      vi: 'AI Xem tử vi phong thuỷ',
      en: 'AI Horoscope & Feng Shui',
    },
    description: {
      vi: 'Cung cấp các thông tin chi tiết về tử vi, phong thủy và các yếu tố tâm linh dựa trên trí tuệ nhân tạo.',
      en: 'Provides detailed insights into horoscopes, feng shui, and spiritual elements powered by AI.',
    },
    price: '$9.99',
    tags: ['Lifestyle', 'Astrology'],
    rating: 4.8,
    reviewCount: 320,
    demoImages: [
        { url: 'https://picsum.photos/seed/ai10_demo1/800/600', caption: { vi: 'Demo 1', en: 'Demo 1' } },
        { url: 'https://picsum.photos/seed/ai10_demo2/800/600', caption: { vi: 'Demo 2', en: 'Demo 2' } },
        { url: 'https://picsum.photos/seed/ai10_demo3/800/600', caption: { vi: 'Demo 3', en: 'Demo 3' } },
    ],
    reviews: [],
  },
  {
    id: 9,
    image: 'https://picsum.photos/seed/ai9/600/400',
    title: {
      vi: 'AI Showroom Ảnh cưới và Makeup',
      en: 'AI Wedding & Makeup Showroom',
    },
    description: {
      vi: 'Trải nghiệm thử các kiểu trang điểm và trang phục cưới khác nhau bằng công nghệ thực tế ảo tăng cường (AR).',
      en: 'Virtually try on different makeup styles and wedding outfits using augmented reality.',
    },
    price: '$59.99',
    tags: ['Fashion', 'AR', 'Lifestyle'],
    rating: 4.9,
    reviewCount: 150,
    demoImages: [
        { url: 'https://picsum.photos/seed/ai9_demo1/800/600', caption: { vi: 'Demo 1', en: 'Demo 1' } },
        { url: 'https://picsum.photos/seed/ai9_demo2/800/600', caption: { vi: 'Demo 2', en: 'Demo 2' } },
    ],
    reviews: [],
  },
  {
    id: 8,
    image: 'https://picsum.photos/seed/ai8/600/400',
    title: {
      vi: 'AI Thiết kế kiến trúc',
      en: 'AI Architectural Designer',
    },
    description: {
      vi: 'Tạo ra các bản vẽ và mô hình kiến trúc 3D chi tiết từ các thông số đầu vào đơn giản.',
      en: 'Generate detailed architectural drawings and 3D models from simple input parameters.',
    },
    price: '$149.99',
    tags: ['Design', 'Architecture', '3D Model'],
    rating: 4.8,
    reviewCount: 75,
    demoImages: [
        { url: 'https://picsum.photos/seed/ai8_demo1/800/600', caption: { vi: 'Demo 1', en: 'Demo 1' } },
        { url: 'https://picsum.photos/seed/ai8_demo2/800/600', caption: { vi: 'Demo 2', en: 'Demo 2' } },
        { url: 'https://picsum.photos/seed/ai8_demo3/800/600', caption: { vi: 'Demo 3', en: 'Demo 3' } },
    ],
    reviews: [],
  },
  {
    id: 7,
    image: 'https://picsum.photos/seed/ai7/600/400',
    title: {
      vi: 'AI Bán hàng thời trang',
      en: 'AI Fashion Merchandiser',
    },
    description: {
      vi: 'Tối ưu hóa doanh số bán lẻ thời trang với các đề xuất sản phẩm được cá nhân hóa và phân tích xu hướng.',
      en: 'Optimize fashion retail sales with personalized product recommendations and trend analysis.',
    },
    price: '$79.99/mo',
    tags: ['Business', 'Retail', 'Fashion'],
    rating: 4.7,
    reviewCount: 88,
    demoImages: [
        { url: 'https://picsum.photos/seed/ai7_demo1/800/600', caption: { vi: 'Demo 1', en: 'Demo 1' } },
        { url: 'https://picsum.photos/seed/ai7_demo2/800/600', caption: { vi: 'Demo 2', en: 'Demo 2' } },
    ],
    reviews: [],
  },
  {
    id: 1,
    image: 'https://picsum.photos/seed/ai1/600/400',
    title: {
      vi: 'Trợ lý Viết AI Pro',
      en: 'AI Writing Assistant Pro',
    },
    description: {
      vi: 'Nâng cao khả năng viết của bạn với các đề xuất và chỉnh sửa thông minh.',
      en: 'Elevate your writing with intelligent suggestions and corrections.',
    },
    price: '$19.99',
    tags: ['Productivity', 'Text'],
    rating: 4.8,
    reviewCount: 258,
    demoImages: [
        { url: 'https://picsum.photos/seed/ai1_demo1/800/600', caption: { vi: 'Demo 1', en: 'Demo 1' } },
        { url: 'https://picsum.photos/seed/ai1_demo2/800/600', caption: { vi: 'Demo 2', en: 'Demo 2' } },
    ],
    reviews: [
      { id: 101, author: 'janesmith', rating: 5, comment: 'Absolutely essential for my daily writing tasks. A real time-saver!', date: '2024-07-15T10:00:00Z' },
      { id: 102, author: 'mark_dev', rating: 4, comment: 'Very helpful, though I wish it had more integrations. Still, a solid tool.', date: '2024-07-12T14:30:00Z' },
    ],
    comments: [
      { id: 1, authorEmail: 'dmpaidev@gmail.com', text: 'Let\'s check the English description. I think it could be more powerful.', timestamp: '2024-07-20T10:30:00Z' },
      { id: 2, authorEmail: 'guest@example.com', text: 'Good point. I\'ll try to use the AI to generate a more punchy version.', timestamp: '2024-07-20T10:32:00Z' },
    ],
  },
  {
    id: 2,
    image: 'https://picsum.photos/seed/ai2/600/400',
    title: {
      vi: 'Tạo ảnh nghệ thuật Diffusion',
      en: 'Diffusion Art Generator',
    },
    description: {
      vi: 'Biến văn bản thành những tác phẩm nghệ thuật kỹ thuật số tuyệt đẹp.',
      en: 'Turn your text prompts into beautiful digital art pieces.',
    },
    price: '$29.99',
    tags: ['Art', 'Image'],
    rating: 4.9,
    reviewCount: 790,
    demoImages: [
        { url: 'https://picsum.photos/seed/ai2_demo1/800/600', caption: { vi: 'Demo 1', en: 'Demo 1' } },
        { url: 'https://picsum.photos/seed/ai2_demo2/800/600', caption: { vi: 'Demo 2', en: 'Demo 2' } },
        { url: 'https://picsum.photos/seed/ai2_demo3/800/600', caption: { vi: 'Demo 3', en: 'Demo 3' } },
    ],
    reviews: [
        { id: 201, author: 'art_lover_88', rating: 5, comment: 'The quality of the generated images is breathtaking. I can spend hours creating with this.', date: '2024-07-20T18:45:00Z' },
    ],
  },
  {
    id: 3,
    image: 'https://picsum.photos/seed/ai3/600/400',
    title: {
      vi: 'Phân tích Dữ liệu Thông minh',
      en: 'Smart Data Analyzer',
    },
    description: {
      vi: 'Trực quan hóa và tìm hiểu sâu hơn về bộ dữ liệu của bạn một cách dễ dàng.',
      en: 'Visualize and gain deep insights from your datasets effortlessly.',
    },
    price: '$49.99/mo',
    tags: ['Data', 'Analytics'],
    rating: 4.7,
    reviewCount: 102,
    demoImages: [
        { url: 'https://picsum.photos/seed/ai3_demo1/800/600', caption: { vi: 'Demo 1', en: 'Demo 1' } },
    ],
    reviews: [],
  },
    {
    id: 4,
    image: 'https://picsum.photos/seed/ai4/600/400',
    title: {
      vi: 'AI Tạo Video',
      en: 'Video Generation AI',
    },
    description: {
      vi: 'Tạo video ngắn từ mô tả văn bản cho mạng xã hội và marketing.',
      en: 'Create short videos from text descriptions for social media and marketing.',
    },
    price: '$35.00',
    tags: ['Video', 'Marketing'],
    rating: 4.6,
    reviewCount: 98,
    demoImages: [
        { url: 'https://picsum.photos/seed/ai4_demo1/800/600', caption: { vi: 'Demo 1', en: 'Demo 1' } },
        { url: 'https://picsum.photos/seed/ai4_demo2/800/600', caption: { vi: 'Demo 2', en: 'Demo 2' } },
    ],
    reviews: [],
  },
  {
    id: 5,
    image: 'https://picsum.photos/seed/ai5/600/400',
    title: {
      vi: 'Lập trình viên cặp AI',
      en: 'AI Code Companion',
    },
    description: {
      vi: 'Tăng tốc quá trình phát triển với tính năng tự động hoàn thành và gỡ lỗi.',
      en: 'Speed up your development with smart autocompletion and debugging.',
    },
    price: '$25.00/mo',
    tags: ['Development', 'Code'],
    rating: 4.9,
    reviewCount: 1200,
    demoImages: [
        { url: 'https://picsum.photos/seed/ai5_demo1/800/600', caption: { vi: 'Demo 1', en: 'Demo 1' } },
        { url: 'https://picsum.photos/seed/ai5_demo2/800/600', caption: { vi: 'Demo 2', en: 'Demo 2' } },
    ],
    reviews: [],
  },
    {
    id: 6,
    image: 'https://picsum.photos/seed/ai6/600/400',
    title: {
      vi: 'Tối ưu hóa Logistics',
      en: 'Logistics Optimizer',
    },
    description: {
      vi: 'Giải quyết các vấn đề về định tuyến và tối ưu hóa chuỗi cung ứng.',
      en: 'Solve complex routing problems and optimize your supply chain.',
    },
    price: '$99.00',
    tags: ['Business', 'Logistics'],
    rating: 4.8,
    reviewCount: 45,
    demoImages: [
        { url: 'https://picsum.photos/seed/ai6_demo1/800/600', caption: { vi: 'Demo 1', en: 'Demo 1' } },
    ],
    reviews: [],
  },
];

export const mockNewsPosts: NewsPost[] = [
    {
        id: 1,
        type: 'youtube',
        url: 'https://www.youtube.com/watch?v=g-w_x2_p_0M',
        title: {
            vi: 'Giới thiệu Gemini 1.5',
            en: 'Introducing Gemini 1.5',
        },
        description: {
            vi: 'Tìm hiểu về các khả năng đột phá của thế hệ mô hình tiếp theo từ Google, mang lại những cải tiến lớn về hiệu suất và khả năng đa phương thức.',
            en: 'Learn about the breakthrough capabilities of the next-generation model from Google, delivering massive performance and multimodality improvements.',
        },
        source: 'YouTube',
        timestamp: '2024-07-18T10:00:00Z',
    },
    {
        id: 2,
        type: 'link',
        url: 'https://techcrunch.com/2024/05/14/google-launches-project-astra-its-vision-for-the-future-of-ai-assistants/',
        title: {
            vi: 'Google ra mắt Project Astra, tầm nhìn về tương lai của trợ lý AI',
            en: 'Google launches Project Astra, its vision for the future of AI assistants',
        },
        description: {
            vi: 'Tại hội nghị I/O, Google đã giới thiệu Project Astra, một dự án nhằm phát triển các trợ lý AI phổ quát có thể hiểu ngữ cảnh và hành động chủ động.',
            en: 'At its I/O conference, Google showed off Project Astra, an effort to develop universal AI agents that are context-aware and proactive.',
        },
        source: 'TechCrunch',
        timestamp: '2024-07-17T14:30:00Z',
        imageUrl: 'https://picsum.photos/seed/astra/600/400',
    },
    {
        id: 3,
        type: 'social',
        url: 'https://x.com/sundarpichai/status/1790449176939384917',
        title: {
            vi: 'Sundar Pichai về AI trong Tìm kiếm',
            en: 'Sundar Pichai on AI in Search',
        },
        description: {
            vi: 'Những thay đổi lớn sắp tới cho Google Search với AI tạo sinh, mang lại các câu trả lời được AI tổng hợp ngay trên đầu trang kết quả. #GoogleIO',
            en: 'Big changes coming to Search with generative AI, delivering AI-synthesized answers right at the top of the results page. #GoogleIO',
        },
        source: 'X (Twitter)',
        timestamp: '2024-07-16T09:00:00Z',
        imageUrl: 'https://picsum.photos/seed/sundar/600/400',
    },
];
