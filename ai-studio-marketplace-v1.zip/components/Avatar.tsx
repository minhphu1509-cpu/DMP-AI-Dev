import React from 'react';

interface AvatarProps {
  email: string;
}

const Avatar: React.FC<AvatarProps> = ({ email }) => {
  const getInitials = (email: string) => {
    if (!email) return '?';
    const parts = email.split('@')[0].split(/[._-]/);
    if (parts.length > 1) {
      return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return email.substring(0, 2).toUpperCase();
  };

  const stringToColor = (str: string) => {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    let color = '#';
    for (let i = 0; i < 3; i++) {
      const value = (hash >> (i * 8)) & 0xFF;
      color += ('00' + value.toString(16)).substr(-2);
    }
    return color;
  };
  
  const bgColor = stringToColor(email);

  return (
    <div
      className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white border-2 border-[#1a1a1a]"
      style={{ backgroundColor: bgColor }}
      title={email}
    >
      {getInitials(email)}
    </div>
  );
};

export default React.memo(Avatar);