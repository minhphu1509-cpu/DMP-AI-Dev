import React, { useState, useMemo } from 'react';
import { useNews } from '../hooks/useNews';
import { useApp as useAppNavigation } from '../hooks/useApp';
import { useI18n } from '../hooks/useI18n';
import { useToast } from '../hooks/useToast';
import { NewsPost } from '../types';
import EditIcon from './icons/EditIcon';
import TrashIcon from './icons/TrashIcon';
import SortIcon from './icons/SortIcon';

type SortableKeys = 'id' | 'title' | 'source' | 'type' | 'timestamp';

const NewsManagementPage: React.FC = () => {
    const { newsPosts, deleteNewsPost } = useNews();
    const { openNewsFormModal } = useAppNavigation();
    const { t, locale } = useI18n();
    const { showToast } = useToast();

    const [sortConfig, setSortConfig] = useState<{ key: SortableKeys; direction: 'asc' | 'desc' }>({ key: 'timestamp', direction: 'desc' });

    const sortedPosts = useMemo(() => {
        let sortablePosts = [...newsPosts];
        sortablePosts.sort((a, b) => {
            let aValue, bValue;

            switch (sortConfig.key) {
                case 'title':
                    aValue = a.title[locale].toLowerCase();
                    bValue = b.title[locale].toLowerCase();
                    break;
                case 'timestamp':
                    aValue = new Date(a.timestamp).getTime();
                    bValue = new Date(b.timestamp).getTime();
                    break;
                default:
                    aValue = a[sortConfig.key];
                    bValue = b[sortConfig.key];
            }

            if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
            if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
            return 0;
        });
        return sortablePosts;
    }, [newsPosts, sortConfig, locale]);

    const requestSort = (key: SortableKeys) => {
        let direction: 'asc' | 'desc' = 'asc';
        if (sortConfig.key === key && sortConfig.direction === 'asc') {
            direction = 'desc';
        }
        setSortConfig({ key, direction });
    };
    
    const handleEdit = (post: NewsPost) => openNewsFormModal(post);

    const handleDelete = (postId: number) => {
        if (window.confirm(t('delete_post_confirm'))) {
            deleteNewsPost(postId);
            showToast(t('post_deleted_successfully'), 'success');
        }
    };
    
    const SortableHeader: React.FC<{ sortKey: SortableKeys, children: React.ReactNode }> = ({ sortKey, children }) => (
        <th scope="col" className="px-6 py-3">
            <button onClick={() => requestSort(sortKey)} className="flex items-center gap-2 group">
                {children}
                <SortIcon className={`w-4 h-4 text-gray-500 transition-opacity ${sortConfig.key === sortKey ? 'opacity-100' : 'opacity-30 group-hover:opacity-100'}`} />
            </button>
        </th>
    );

    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
                <div>
                    <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">{t('news_management_title')}</h1>
                    <p className="mt-2 text-lg text-[#A8A8A8]">{t('news_management_desc')}</p>
                </div>
                <button onClick={() => openNewsFormModal(null)} className="mt-6 md:mt-0 inline-flex items-center justify-center px-6 py-3 text-base font-medium text-black bg-[#FF6A00] border border-transparent rounded-md shadow-sm hover:bg-[#ff8533] transition-colors">
                    {t('add_new_post')}
                </button>
            </div>

            <div className="bg-[#1a1a1a] border border-[#2b2b2b] rounded-xl overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-[#A8A8A8]">
                        <thead className="bg-[#0f0f0f] text-xs text-white uppercase tracking-wider">
                            <tr>
                                <SortableHeader sortKey="id">{t('table_id')}</SortableHeader>
                                <SortableHeader sortKey="title">{t('table_title')}</SortableHeader>
                                <SortableHeader sortKey="type">{t('table_type')}</SortableHeader>
                                <SortableHeader sortKey="source">{t('table_source')}</SortableHeader>
                                <SortableHeader sortKey="timestamp">{t('table_date')}</SortableHeader>
                                <th scope="col" className="px-6 py-3 text-right">{t('table_actions')}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {sortedPosts.map((post) => (
                                <tr key={post.id} className="border-b border-[#2b2b2b] hover:bg-[#222222]">
                                    <td className="px-6 py-4 font-medium text-gray-400">{post.id}</td>
                                    <td className="px-6 py-4 font-semibold text-white max-w-sm truncate" title={post.title[locale]}>{post.title[locale]}</td>
                                    <td className="px-6 py-4 capitalize">{post.type}</td>
                                    <td className="px-6 py-4">{post.source}</td>
                                    <td className="px-6 py-4 whitespace-nowrap">{new Date(post.timestamp).toLocaleDateString()}</td>
                                    <td className="px-6 py-4 text-right">
                                        <div className="flex items-center justify-end gap-4">
                                            <button onClick={() => handleEdit(post)} className="text-gray-400 hover:text-[#FF6A00]" title={t('edit_post')}><EditIcon className="w-5 h-5"/></button>
                                            <button onClick={() => handleDelete(post.id)} className="text-gray-400 hover:text-red-500" title={t('delete_post')}><TrashIcon className="w-5 h-5"/></button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default NewsManagementPage;