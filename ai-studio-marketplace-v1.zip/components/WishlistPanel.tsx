import React from 'react';
import { useWishlist } from '../hooks/useWishlist';
import { useI18n } from '../hooks/useI18n';
import { useToast } from '../hooks/useToast';
import { useCart } from '../hooks/useCart';
import { App } from '../types';

const WishlistPanel: React.FC = () => {
  const { wishlistItems, removeFromWishlist } = useWishlist();
  const { addMultipleToCart, addToCart, isItemInCart } = useCart();
  const { t, locale } = useI18n();
  const { showToast } = useToast();

  const handleAddAllToCart = () => {
    if(wishlistItems.length === 0) return;
    
    addMultipleToCart(wishlistItems);
    showToast(t('all_items_added_to_cart'), 'success');
  };
  
  const handleAddToCart = (item: App) => {
    if (isItemInCart(item.id)) return;
    addToCart(item);
    const message = t('app_added_to_cart').replace('{appName}', item.title[locale]);
    showToast(message, 'success');
  };

  return (
    <div 
        className="absolute right-0 mt-2 w-80 bg-[#1a1a1a] border border-white/10 rounded-md shadow-lg py-2 z-50"
        role="dialog"
        aria-modal="true"
        aria-labelledby="wishlist-heading"
    >
      <div className="px-4 py-2 border-b border-white/10">
        <h3 id="wishlist-heading" className="font-semibold text-white">{t('wishlist')} ({wishlistItems.length})</h3>
      </div>
      {wishlistItems.length === 0 ? (
        <p className="px-4 py-6 text-center text-[#A8A8A8]">{t('wishlist_empty')}</p>
      ) : (
        <>
          <div className="max-h-64 overflow-y-auto p-2">
            {wishlistItems.map(item => {
              const isInCart = isItemInCart(item.id);
              return (
              <div key={item.id} className="p-2 rounded-md hover:bg-[#2b2b2b]">
                <div className="flex items-center">
                  <img src={item.image} alt={item.title[locale]} className="w-12 h-12 object-cover rounded-md flex-shrink-0" />
                  <div className="ml-3 flex-grow overflow-hidden">
                    <p className="text-sm font-medium text-white truncate">{item.title[locale]}</p>
                    <p className="text-sm text-[#FF6A00] font-semibold">{item.price}</p>
                  </div>
                  <button 
                    onClick={() => removeFromWishlist(item.id)}
                    className="text-[#A8A8A8] hover:text-red-500 ml-2 p-1 flex-shrink-0"
                    aria-label={`Remove ${item.title[locale]} from wishlist`}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                  </button>
                </div>
                <div className="mt-2">
                  <button
                    onClick={() => handleAddToCart(item)}
                    disabled={isInCart}
                    className={`w-full text-center py-1.5 text-xs font-semibold rounded-md transition-colors duration-200 ${
                      isInCart
                        ? 'bg-green-500/20 text-green-400 cursor-not-allowed'
                        : 'bg-[#FF6A00]/20 text-[#FF6A00] hover:bg-[#FF6A00] hover:text-black'
                    }`}
                  >
                    {isInCart ? t('added_to_cart') : t('buy_now')}
                  </button>
                </div>
              </div>
            )})}
          </div>
          <div className="px-4 py-3 border-t border-white/10">
            <button 
              onClick={handleAddAllToCart}
              className="w-full bg-[#FF6A00] text-black font-semibold py-2.5 rounded-lg transition-colors hover:bg-[#ff8533]"
            >
              {t('add_all_to_cart')}
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default WishlistPanel;