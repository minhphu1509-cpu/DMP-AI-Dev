import React from 'react';
import { useCart } from '../hooks/useCart';
import { useI18n } from '../hooks/useI18n';
import { formatCurrency, getPriceAsNumber } from '../utils/formatters';

const OrderSummary: React.FC = () => {
  const { cartItems } = useCart();
  const { t, locale } = useI18n();

  const subtotal = cartItems.reduce((acc, item) => {
    return acc + getPriceAsNumber(item.price);
  }, 0);

  return (
    <div>
      <h2 className="text-xl font-semibold text-white mb-6">{t('order_summary')}</h2>
      <div className="space-y-4 max-h-64 overflow-y-auto pr-2">
        {cartItems.map(item => (
          <div key={item.id} className="flex items-center">
            <img src={item.image} alt={item.title[locale]} className="w-16 h-12 object-cover rounded-md flex-shrink-0" />
            <div className="ml-4 flex-grow overflow-hidden">
              <p className="text-sm font-medium text-white truncate">{item.title[locale]}</p>
            </div>
            <p className="text-sm text-white font-semibold ml-4 flex-shrink-0">
              {formatCurrency(getPriceAsNumber(item.price), locale)}{item.price.includes('/mo') ? t('monthly_billing') : ''}
            </p>
          </div>
        ))}
      </div>
      <div className="mt-6 pt-4 border-t border-white/10">
        <div className="flex justify-between text-base font-medium text-white">
          <p>{t('subtotal')}</p>
          <p>{formatCurrency(subtotal, locale)}</p>
        </div>
      </div>
    </div>
  );
};

export default OrderSummary;