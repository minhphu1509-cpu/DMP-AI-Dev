import React from 'react';
import { useI18n } from '../hooks/useI18n';
import AppCard from './AppCard';
import { useMarketplace } from '../hooks/useMarketplace';

const FeaturedApps: React.FC = () => {
  const { t } = useI18n();
  const { apps } = useMarketplace();
  
  const featuredApps = apps.slice(0, 3);

  return (
    <section className="py-20 sm:py-24 bg-[#0f0f0f]">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">
            {t('featured_apps_title')}
          </h2>
          <p className="mt-4 text-lg text-[#A8A8A8]">
            {t('featured_apps_description')}
          </p>
        </div>
        <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {featuredApps.map((app) => (
            <AppCard key={app.id} app={app} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedApps;