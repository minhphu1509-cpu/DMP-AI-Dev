import React from 'react';
import { useCart } from '../hooks/useCart';
import { useI18n } from '../hooks/useI18n';
import { useApp } from '../hooks/useApp';
import { formatCurrency, getPriceAsNumber } from '../utils/formatters';

const MiniCart: React.FC = () => {
  const { cartItems, removeFromCart } = useCart();
  const { t, locale } = useI18n();
  const { goToCheckout } = useApp();

  const subtotal = cartItems.reduce((acc, item) => {
    return acc + getPriceAsNumber(item.price);
  }, 0);

  const handleCheckout = () => {
    if (cartItems.length === 0) return;
    goToCheckout();
  };

  return (
    <div 
        className="absolute right-0 mt-2 w-80 bg-[#1a1a1a] border border-white/10 rounded-md shadow-lg py-2 z-50"
        role="dialog"
        aria-modal="true"
        aria-labelledby="cart-heading"
    >
      <div className="px-4 py-2 border-b border-white/10">
        <h3 id="cart-heading" className="font-semibold text-white">{t('shopping_cart')} ({cartItems.length})</h3>
      </div>
      {cartItems.length === 0 ? (
        <p className="px-4 py-6 text-center text-[#A8A8A8]">{t('cart_empty')}</p>
      ) : (
        <>
          <div className="max-h-64 overflow-y-auto p-2">
            {cartItems.map(item => (
              <div key={item.id} className="flex items-center p-2 rounded-md hover:bg-[#2b2b2b]">
                <img src={item.image} alt={item.title[locale]} className="w-12 h-12 object-cover rounded-md flex-shrink-0" />
                <div className="ml-3 flex-grow overflow-hidden">
                  <p className="text-sm font-medium text-white truncate">{item.title[locale]}</p>
                  <p className="text-sm text-[#FF6A00] font-semibold">
                    {formatCurrency(getPriceAsNumber(item.price), locale)}{item.price.includes('/mo') ? t('monthly_billing') : ''}
                  </p>
                </div>
                <button 
                  onClick={() => removeFromCart(item.id)}
                  className="text-[#A8A8A8] hover:text-white ml-2 p-1 flex-shrink-0"
                  aria-label={`Remove ${item.title[locale]} from cart`}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                </button>
              </div>
            ))}
          </div>
          <div className="px-4 py-3 border-t border-white/10">
            <div className="flex justify-between text-base font-medium text-white">
              <p>{t('subtotal')}</p>
              <p>{formatCurrency(subtotal, locale)}</p>
            </div>
            <button 
              onClick={handleCheckout}
              className="w-full mt-4 bg-[#FF6A00] text-black font-semibold py-2.5 rounded-lg transition-colors hover:bg-[#ff8533]"
            >
              {t('checkout')}
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default MiniCart;