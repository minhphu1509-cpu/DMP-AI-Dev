import React, { useState } from 'react';
import StarIcon from './icons/StarIcon';

interface StarRatingInputProps {
  rating: number;
  onRatingChange: (rating: number) => void;
  maxStars?: number;
}

const StarRatingInput: React.FC<StarRatingInputProps> = ({ rating, onRatingChange, maxStars = 5 }) => {
  const [hoverRating, setHoverRating] = useState(0);

  return (
    <div className="flex items-center">
      {[...Array(maxStars)].map((_, i) => {
        const starValue = i + 1;
        return (
          <button
            type="button"
            key={i}
            onMouseEnter={() => setHoverRating(starValue)}
            onMouseLeave={() => setHoverRating(0)}
            onClick={() => onRatingChange(starValue)}
            className="p-1 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-[#1a1a1a] focus-visible:ring-[#FF6A00] rounded-full"
            aria-label={`Rate ${starValue} out of ${maxStars} stars`}
          >
            <StarIcon 
              className={`w-7 h-7 transition-colors duration-150 ${
                (hoverRating || rating) >= starValue
                  ? 'text-yellow-400'
                  : 'text-gray-500 hover:text-yellow-300'
              }`} 
            />
          </button>
        );
      })}
    </div>
  );
};

export default React.memo(StarRatingInput);
