import React from 'react';
import { useI18n } from '../hooks/useI18n';
import { useSiteContent } from '../hooks/useSiteContent';

const AboutPage: React.FC = () => {
  const { t, locale } = useI18n();
  const { siteContent } = useSiteContent();

  const content = siteContent.about[locale] || '';

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-24">
      <div className="max-w-3xl mx-auto">
        <div className="text-center">
          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">
            {t('footer_about')}
          </h1>
        </div>
        
        <div className="mt-12 text-left prose prose-invert prose-lg max-w-none text-[#A8A8A8] space-y-6">
           <div className="whitespace-pre-wrap">{content}</div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;
