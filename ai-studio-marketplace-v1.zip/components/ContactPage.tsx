import React, { useState } from 'react';
import { useI18n } from '../hooks/useI18n';
import { useToast } from '../hooks/useToast';
import SpinnerIcon from './icons/SpinnerIcon';
import MailIcon from './icons/MailIcon';
import PhoneIcon from './icons/PhoneIcon';
import MapPinIcon from './icons/MapPinIcon';
import ZaloIcon from './icons/ZaloIcon';
import WhatsappIcon from './icons/WhatsappIcon';
import { useSiteContent } from '../hooks/useSiteContent';

const ContactPage: React.FC = () => {
  const { t, locale } = useI18n();
  const { showToast } = useToast();
  const { siteContent } = useSiteContent();
  const { email, phone, address_vi, address_en, zalo, whatsapp } = siteContent.contact;

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    address: '',
    subject: '',
    message: '',
  });
  const [errors, setErrors] = useState({ address: '' });
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (name === 'address' && errors.address) {
      setErrors(prev => ({ ...prev, address: '' }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    const isAddressValid = formData.address.length >= 10 && /\d/.test(formData.address);

    if (!isAddressValid) {
      setErrors({ address: t('form_address_invalid') });
      setIsLoading(false);
      return;
    }

    setErrors({ address: '' });

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      showToast(t('message_sent_success'), 'success');
      setFormData({ name: '', email: '', address: '', subject: '', message: '' });
    }, 2000);
  };
  
  const address = locale === 'vi' ? address_vi : address_en;

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-24">
      <div className="max-w-5xl mx-auto">
        <div className="text-center">
          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">
            {t('contact_title')}
          </h1>
          <p className="mt-4 text-lg text-[#A8A8A8]">
            {t('contact_subtitle')}
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="bg-[#1a1a1a] border border-[#2b2b2b] rounded-xl p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              <InputField label={t('form_name')} name="name" value={formData.name} onChange={handleChange} required />
              <InputField label={t('form_email')} name="email" type="email" value={formData.email} onChange={handleChange} required />
              <InputField label={t('form_address')} name="address" value={formData.address} onChange={handleChange} error={errors.address} required />
              <InputField label={t('form_subject')} name="subject" value={formData.subject} onChange={handleChange} required />
              <TextAreaField label={t('form_message')} name="message" value={formData.message} onChange={handleChange} required />
              <div>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full flex items-center justify-center bg-[#FF6A00] text-black font-semibold py-3 rounded-lg transition-all duration-300 hover:bg-[#ff8533] disabled:bg-[#FF6A00]/50 disabled:cursor-not-allowed"
                >
                  {isLoading ? (
                    <>
                      <SpinnerIcon className="animate-spin -ml-1 mr-3 h-5 w-5" />
                      {t('sending_message')}
                    </>
                  ) : (
                    t('send_message')
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* Contact Info */}
          <div className="space-y-8">
             <div className="bg-[#1a1a1a] border border-[#2b2b2b] rounded-xl p-8">
                <h2 className="text-xl font-bold text-white mb-6">{t('contact_info_title')}</h2>
                <div className="space-y-6">
                    <ContactInfoItem icon={<MailIcon />} title={t('contact_email')} value={email} href={`mailto:${email}`}/>
                    <ContactInfoItem icon={<PhoneIcon />} title={t('contact_phone')} value={phone} href={`tel:${phone}`}/>
                    <ContactInfoItem icon={<ZaloIcon />} title={t('contact_zalo')} value={zalo} href={`https://zalo.me/${zalo}`} />
                    <ContactInfoItem icon={<WhatsappIcon />} title={t('contact_whatsapp')} value={whatsapp} href={`https://wa.me/${whatsapp.replace('+', '')}`} />
                    <ContactInfoItem icon={<MapPinIcon />} title={t('contact_address')} value={address} />
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const InputField: React.FC<any> = ({ label, error, ...props }) => (
  <div>
    <label htmlFor={props.name} className="block text-sm font-medium text-[#A8A8A8] mb-2">{label}</label>
    <input 
        id={props.name} 
        {...props} 
        className={`w-full px-4 py-2.5 bg-[#0f0f0f] border rounded-md text-white outline-none transition-colors ${
            error 
            ? 'border-red-500 focus:ring-2 focus:ring-red-500/50 focus:border-red-500' 
            : 'border-[#2b2b2b] focus:ring-2 focus:ring-[#FF6A00] focus:border-[#FF6A00]'
        }`}
        aria-invalid={!!error}
        aria-describedby={error ? `${props.name}-error` : undefined}
    />
    {error && <p id={`${props.name}-error`} className="text-sm text-red-400 mt-1.5">{error}</p>}
  </div>
);

const TextAreaField: React.FC<any> = ({ label, ...props }) => (
  <div>
    <label htmlFor={props.name} className="block text-sm font-medium text-[#A8A8A8] mb-2">{label}</label>
    <textarea id={props.name} {...props} rows={4} className="w-full px-4 py-2.5 bg-[#0f0f0f] border border-[#2b2b2b] rounded-md text-white focus:ring-2 focus:ring-[#FF6A00] focus:border-[#FF6A00] outline-none" />
  </div>
);

const ContactInfoItem: React.FC<{icon: React.ReactNode, title: string, value: string, href?: string}> = ({icon, title, value, href}) => (
    <div className="flex items-start">
        <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center bg-[#2b2b2b] text-[#FF6A00] rounded-lg">
            {icon}
        </div>
        <div className="ml-4">
            <h3 className="text-base font-medium text-[#A8A8A8]">{title}</h3>
            {href ? (
                 <a href={href} target="_blank" rel="noopener noreferrer" className="text-lg font-semibold text-white hover:text-[#FF6A00] transition-colors">{value}</a>
            ) : (
                 <p className="text-lg font-semibold text-white">{value}</p>
            )}
           
        </div>
    </div>
);

export default ContactPage;