import React from 'react';
import { useI18n } from '../hooks/useI18n';
import { useSiteContent } from '../hooks/useSiteContent';
import { useApp } from '../hooks/useApp';
import { SiteContentKey, BilingualContent, ContactInfoContent } from '../types';
import EditIcon from './icons/EditIcon';

const SiteManagementPage: React.FC = () => {
  const { t } = useI18n();
  const { siteContent } = useSiteContent();
  const { openContentEditModal } = useApp();
  
  const contentAreas: { key: SiteContentKey, title: string }[] = [
    { key: 'terms', title: t('manage_terms') },
    { key: 'privacy', title: t('manage_privacy') },
    { key: 'about', title: t('manage_about') },
    { key: 'careers', title: t('manage_careers') },
    { key: 'press', title: t('manage_press') },
    { key: 'contact', title: t('manage_contact') },
  ];

  const handleEdit = (key: SiteContentKey) => {
      openContentEditModal(key, siteContent[key]);
  };

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
      <div className="mb-10">
        <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">
          {t('site_management_title')}
        </h1>
        <p className="mt-2 text-lg text-[#A8A8A8]">{t('site_management_desc')}</p>
      </div>

      <div className="bg-[#1a1a1a] border border-[#2b2b2b] rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left text-[#A8A8A8]">
            <thead className="bg-[#0f0f0f] text-xs text-white uppercase tracking-wider">
              <tr>
                <th scope="col" className="px-6 py-3">{t('content_area')}</th>
                <th scope="col" className="px-6 py-3 text-right">{t('table_actions')}</th>
              </tr>
            </thead>
            <tbody>
              {contentAreas.map(({ key, title }) => (
                <tr key={key} className="border-b border-[#2b2b2b] hover:bg-[#222222]">
                  <td className="px-6 py-4 font-semibold text-white">
                    {title}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button onClick={() => handleEdit(key)} className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-[#FF6A00] bg-[#FF6A00]/10 rounded-lg hover:bg-[#FF6A00]/20 transition-colors">
                      <EditIcon className="w-4 h-4" />
                      {t('edit_content')}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default SiteManagementPage;
