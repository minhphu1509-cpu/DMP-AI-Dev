import React from 'react';
import { useI18n } from '../hooks/useI18n';
import AppCard from './AppCard';
import ArrowRightIcon from './icons/ArrowRightIcon';
import { useMarketplace } from '../hooks/useMarketplace';
import { useApp } from '../hooks/useApp';

const MarketplacePreview: React.FC = () => {
  const { t } = useI18n();
  const { apps } = useMarketplace();
  const { goToMarketplace } = useApp();
  
  const marketplaceApps = apps.slice(3, 6);

  return (
    <section className="py-20 sm:py-24 bg-black">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">
              {t('marketplace_title')}
            </h2>
            <p className="mt-4 text-lg text-[#A8A8A8] max-w-2xl">
              {t('marketplace_description')}
            </p>
          </div>
          <button
            onClick={goToMarketplace}
            className="mt-6 md:mt-0 inline-flex items-center text-base font-medium text-[#FF6A00] hover:text-[#ff8533] transition-colors"
          >
            {t('marketplace_cta')} <ArrowRightIcon className="ml-2" />
          </button>
        </div>
        <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {marketplaceApps.map((app) => (
            <AppCard key={app.id} app={app} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default MarketplacePreview;