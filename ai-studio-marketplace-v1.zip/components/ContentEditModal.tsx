import React, { useState, useEffect } from 'react';
import { useI18n } from '../hooks/useI18n';
import { SiteContentKey, BilingualContent, ContactInfoContent } from '../types';

interface ContentEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (key: SiteContentKey, content: BilingualContent | ContactInfoContent) => void;
  contentToEdit: { key: SiteContentKey; content: BilingualContent | ContactInfoContent } | null;
}

const ContentEditModal: React.FC<ContentEditModalProps> = ({ isOpen, onClose, onSave, contentToEdit }) => {
  const { t } = useI18n();
  const [formData, setFormData] = useState<BilingualContent | ContactInfoContent | null>(null);

  useEffect(() => {
    if (contentToEdit) {
      setFormData(contentToEdit.content);
    }
  }, [contentToEdit]);

  if (!isOpen || !contentToEdit || !formData) return null;

  const { key, content } = contentToEdit;
  const isContactInfo = key === 'contact';
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => prev ? { ...prev, [name]: value } : null);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if(formData) {
        onSave(key, formData);
    }
  };

  const renderFormFields = () => {
    if (isContactInfo) {
      const contactData = formData as ContactInfoContent;
      return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <InputField label={t('contact_email')} name="email" value={contactData.email} onChange={handleChange} />
            <InputField label={t('contact_phone')} name="phone" value={contactData.phone} onChange={handleChange} />
            <InputField label={`${t('contact_address')} (VI)`} name="address_vi" value={contactData.address_vi} onChange={handleChange} />
            <InputField label={`${t('contact_address')} (EN)`} name="address_en" value={contactData.address_en} onChange={handleChange} />
            <InputField label={t('contact_zalo_phone')} name="zalo" value={contactData.zalo} onChange={handleChange} />
            <InputField label={t('contact_whatsapp_phone')} name="whatsapp" value={contactData.whatsapp} onChange={handleChange} />
        </div>
      );
    } else {
      const bilingualData = formData as BilingualContent;
      return (
        <div className="space-y-4">
            <TextAreaField label={t('content_vi')} name="vi" value={bilingualData.vi} onChange={handleChange} />
            <TextAreaField label={t('content_en')} name="en" value={bilingualData.en} onChange={handleChange} />
        </div>
      );
    }
  };
  
  return (
    <div className="fixed inset-0 bg-black/70 z-[100] flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-[#1a1a1a] border border-[#2b2b2b] rounded-xl w-full max-w-3xl max-h-[90vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
        <form onSubmit={handleSubmit} className="flex flex-col h-full">
          <div className="p-6 border-b border-[#2b2b2b]">
            <h2 className="text-xl font-bold text-white">
              {t('edit_content')}: {t(`manage_${key}`)}
            </h2>
          </div>
          <div className="p-6 flex-grow overflow-y-auto">
              {renderFormFields()}
          </div>
          <div className="p-4 bg-[#0f0f0f] border-t border-[#2b2b2b] flex justify-end gap-4 rounded-b-xl">
            <button type="button" onClick={onClose} className="px-5 py-2.5 text-sm font-medium text-[#A8A8A8] bg-transparent border border-[#2b2b2b] rounded-lg hover:bg-[#2b2b2b] transition-colors">
              {t('cancel')}
            </button>
            <button type="submit" className="px-5 py-2.5 text-sm font-medium text-black bg-[#FF6A00] rounded-lg hover:bg-[#ff8533] transition-colors">
              {t('save_changes')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

const InputField: React.FC<any> = ({ label, ...props }) => (
    <div>
        <label className="block text-sm font-medium text-[#A8A8A8] mb-2">{label}</label>
        <input {...props} className="w-full px-4 py-2.5 bg-[#0f0f0f] border border-[#2b2b2b] rounded-md text-white focus:ring-2 focus:ring-[#FF6A00] focus:border-[#FF6A00] outline-none" />
    </div>
);
const TextAreaField: React.FC<any> = ({ label, ...props }) => (
    <div>
        <label className="block text-sm font-medium text-[#A8A8A8] mb-2">{label}</label>
        <textarea {...props} rows={12} className="w-full px-4 py-2 bg-[#0f0f0f] border border-[#2b2b2b] rounded-md text-white focus:ring-2 focus:ring-[#FF6A00] focus:border-[#FF6A00] outline-none" />
    </div>
);

export default ContentEditModal;
