import React from 'react';
import { useI18n } from '../hooks/useI18n';
import { useApp } from '../hooks/useApp';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';

const SubmitCTA: React.FC = () => {
  const { t } = useI18n();
  const { openAppFormModal, setPostLoginAction, goToLogin } = useApp();
  const { isAuthenticated } = useAuth();
  const { showToast } = useToast();

  const handleSubmitClick = () => {
    if (isAuthenticated) {
      openAppFormModal(null);
    } else {
      showToast(t('login_to_submit'), 'info');
      setPostLoginAction('submit_app');
      goToLogin();
    }
  };

  return (
    <div className="bg-[#0f0f0f]">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-24">
        <div className="relative rounded-2xl p-8 md:p-12 overflow-hidden bg-[#1a1a1a] border border-[#2b2b2b]">
          <div className="absolute -top-10 -right-10 w-40 h-40 bg-[#FF6A00]/10 rounded-full blur-3xl"></div>
          <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl"></div>
          <div className="relative z-10 text-center">
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">
              {t('submit_cta_title')}
            </h2>
            <p className="mt-4 max-w-2xl mx-auto text-lg text-[#A8A8A8]">
              {t('submit_cta_description')}
            </p>
            <div className="mt-8">
              <button
                onClick={handleSubmitClick}
                className="inline-flex items-center justify-center px-8 py-3 text-base font-medium text-black bg-[#FF6A00] border border-transparent rounded-md shadow-sm hover:bg-[#ff8533] transition-colors"
              >
                {t('submit_cta_button')}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SubmitCTA;