import React, { useState, useEffect, useLayoutEffect, useRef } from 'react';
import { useI18n } from '../hooks/useI18n';

type TourStep = {
  target: string;
  content: string;
  position: 'top' | 'bottom' | 'left' | 'right' | 'bottom-end';
};

interface GuidedTourProps {
  steps: TourStep[];
  onComplete: () => void;
}

const GuidedTour: React.FC<GuidedTourProps> = ({ steps, onComplete }) => {
  const { t } = useI18n();
  const [currentStep, setCurrentStep] = useState(0);
  const [targetRect, setTargetRect] = useState<DOMRect | null>(null);
  const popoverRef = useRef<HTMLDivElement>(null);

  const step = steps[currentStep];

  useLayoutEffect(() => {
    if (!step) return;

    const targetElement = document.querySelector(step.target);
    if (targetElement) {
        targetElement.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });

        const updateRect = () => {
            const rect = targetElement.getBoundingClientRect();
            setTargetRect(rect);
        };
        
        // Wait for scroll to finish before getting rect
        const scrollTimeout = setTimeout(updateRect, 300);
        
        // Also handle resize
        window.addEventListener('resize', updateRect);
        
        return () => {
            clearTimeout(scrollTimeout);
            window.removeEventListener('resize', updateRect);
        };
    } else {
        // If element not found, skip to next step or end tour
        handleNext();
    }
  }, [currentStep, steps]);
  
  const getPopoverPosition = () => {
    if (!targetRect || !popoverRef.current) return { top: '-9999px', left: '-9999px' };

    const popoverHeight = popoverRef.current.offsetHeight;
    const popoverWidth = popoverRef.current.offsetWidth;
    const spacing = 12;

    switch(step.position) {
        case 'bottom':
            return { top: `${targetRect.bottom + spacing}px`, left: `${targetRect.left + targetRect.width / 2 - popoverWidth / 2}px` };
        case 'top':
            return { top: `${targetRect.top - popoverHeight - spacing}px`, left: `${targetRect.left + targetRect.width / 2 - popoverWidth / 2}px` };
        case 'left':
            return { top: `${targetRect.top + targetRect.height / 2 - popoverHeight / 2}px`, left: `${targetRect.left - popoverWidth - spacing}px` };
        case 'right':
            return { top: `${targetRect.top + targetRect.height / 2 - popoverHeight / 2}px`, left: `${targetRect.right + spacing}px` };
        case 'bottom-end':
            return { top: `${targetRect.bottom + spacing}px`, left: `${targetRect.right - popoverWidth}px` };
        default:
             return { top: `${targetRect.bottom + spacing}px`, left: `${targetRect.left}px` };
    }
  };


  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSkip = () => {
    onComplete();
  };

  if (!targetRect) return null;

  return (
    <div className="fixed inset-0 z-[1000]">
      {/* Overlay with spotlight */}
      <div 
        className="fixed inset-0 transition-all duration-300"
        style={{
          boxShadow: `0 0 0 9999px rgba(0, 0, 0, 0.6)`,
        }}
      >
      </div>
       <div
          className="absolute rounded-md transition-all duration-300"
          style={{
            top: `${targetRect.top - 4}px`,
            left: `${targetRect.left - 4}px`,
            width: `${targetRect.width + 8}px`,
            height: `${targetRect.height + 8}px`,
            boxShadow: '0 0 0 9999px rgba(0, 0, 0, 0.6)',
            pointerEvents: 'none',
          }}
        ></div>

      {/* Popover */}
      <div
        ref={popoverRef}
        className="absolute w-80 bg-[#2b2b2b] text-white p-5 rounded-lg shadow-2xl border border-white/10 transition-all duration-300 animate-pop-in"
        style={getPopoverPosition()}
      >
        <p className="text-base">{step.content}</p>
        <div className="mt-5 flex items-center justify-between">
            <span className="text-sm text-gray-400">{currentStep + 1} / {steps.length}</span>
            <div className="flex items-center gap-2">
                <button onClick={handleSkip} className="text-sm text-gray-400 hover:text-white px-3 py-1">{t('tour_skip')}</button>
                {currentStep > 0 && <button onClick={handlePrev} className="text-sm font-semibold bg-gray-600 hover:bg-gray-500 rounded-md px-3 py-1.5">{t('tour_previous')}</button>}
                <button onClick={handleNext} className="text-sm font-semibold bg-[#FF6A00] hover:bg-[#ff8533] text-black rounded-md px-4 py-1.5">{currentStep === steps.length - 1 ? t('tour_finish') : t('tour_next')}</button>
            </div>
        </div>
      </div>
      <style>{`
        @keyframes pop-in {
            from { opacity: 0; transform: scale(0.9); }
            to { opacity: 1; transform: scale(1); }
        }
        .animate-pop-in {
            animation: pop-in 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
       `}</style>
    </div>
  );
};

export default GuidedTour;