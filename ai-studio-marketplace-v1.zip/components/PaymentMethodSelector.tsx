import React from 'react';
import { usePayment } from '../hooks/usePayment';
import { useI18n } from '../hooks/useI18n';
import { PaymentMethod } from '../types';
import BankIcon from './icons/BankIcon';
import MomoIcon from './icons/MomoIcon';
import PaypalIcon from './icons/PaypalIcon';
import QrCodeIcon from './icons/QrCodeIcon';

const paymentOptions: { id: PaymentMethod; icon: React.ReactNode; labelKey: string }[] = [
  { id: 'bank', icon: <BankIcon />, labelKey: 'payment_bank' },
  { id: 'momo', icon: <MomoIcon />, labelKey: 'payment_momo' },
  { id: 'paypal', icon: <PaypalIcon />, labelKey: 'payment_paypal' },
];

const PaymentMethodSelector: React.FC = () => {
  const { selectedMethod, selectMethod } = usePayment();
  const { t } = useI18n();

  return (
    <div className="space-y-4">
      {paymentOptions.map(option => {
        const isSelected = selectedMethod === option.id;
        return (
          <button
            key={option.id}
            onClick={() => selectMethod(option.id)}
            className={`w-full flex items-center p-4 rounded-lg border-2 transition-colors duration-200 text-left ${
              isSelected
                ? 'bg-[#FF6A00]/10 border-[#FF6A00]'
                : 'bg-[#0f0f0f] border-[#2b2b2b] hover:border-[#4a4a4a]'
            }`}
            role="radio"
            aria-checked={isSelected}
          >
            <div className={`w-8 h-8 flex items-center justify-center ${isSelected ? 'text-[#FF6A00]' : 'text-[#A8A8A8]'}`}>
                {option.icon}
            </div>
            <span className={`ml-4 font-semibold ${isSelected ? 'text-white' : 'text-[#A8A8A8]'}`}>
              {t(option.labelKey)}
            </span>
            <div className="ml-auto flex items-center justify-center w-5 h-5 rounded-full border-2 border-[#555]">
                {isSelected && <div className="w-2.5 h-2.5 bg-[#FF6A00] rounded-full"></div>}
            </div>
          </button>
        );
      })}
    </div>
  );
};

export default PaymentMethodSelector;