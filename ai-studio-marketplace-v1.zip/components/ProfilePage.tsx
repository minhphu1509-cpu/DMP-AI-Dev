import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useI18n } from '../hooks/useI18n';
import { useToast } from '../hooks/useToast';
import { PurchasedApp } from '../types';
import SpinnerIcon from './icons/SpinnerIcon';
import CopyIcon from './icons/CopyIcon';

const ProfilePage: React.FC = () => {
  const { user, updateProfile } = useAuth();
  const { t, locale } = useI18n();
  const { showToast } = useToast();

  const [displayName, setDisplayName] = useState(user?.displayName || '');
  const [isLoading, setIsLoading] = useState(false);

  if (!user) {
    return (
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-24 text-center">
        <p>You must be logged in to view this page.</p>
      </div>
    );
  }

  const handleProfileUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!displayName.trim()) return;
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      updateProfile({ displayName });
      showToast(t('profile_updated_successfully'), 'success');
      setIsLoading(false);
    }, 1000);
  };
  
  const handleCopyLink = (url: string) => {
    navigator.clipboard.writeText(url);
    showToast(t('link_copied'), 'success');
  };

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
      <div className="max-w-4xl mx-auto">
        <div className="mb-10 text-center">
          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">{t('profile_title')}</h1>
          <p className="mt-2 text-lg text-[#A8A8A8]">{t('profile_subtitle')}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Profile Form */}
          <div className="md:col-span-1">
            <div className="bg-[#1a1a1a] border border-[#2b2b2b] rounded-xl p-6">
              <h2 className="text-xl font-semibold text-white mb-6">{t('profile_information')}</h2>
              <form onSubmit={handleProfileUpdate} className="space-y-6">
                 <div>
                    <label className="block text-sm font-medium text-[#A8A8A8] mb-2">{t('email_address')}</label>
                    <p className="text-white bg-[#0f0f0f] px-4 py-2.5 rounded-md border border-[#2b2b2b] truncate">{user.email}</p>
                 </div>
                 <div>
                    <label htmlFor="displayName" className="block text-sm font-medium text-[#A8A8A8] mb-2">{t('display_name')}</label>
                    <input
                      id="displayName"
                      type="text"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      className="w-full px-4 py-2.5 bg-[#0f0f0f] border border-[#2b2b2b] rounded-md text-white focus:ring-2 focus:ring-[#FF6A00] focus:border-[#FF6A00] outline-none"
                    />
                 </div>
                 <div>
                    <button
                      type="submit"
                      disabled={isLoading}
                      className="w-full flex items-center justify-center bg-[#FF6A00] text-black font-semibold py-3 rounded-lg transition-all duration-300 hover:bg-[#ff8533] disabled:bg-[#FF6A00]/50 disabled:cursor-not-allowed"
                    >
                      {isLoading ? (
                        <SpinnerIcon className="animate-spin w-5 h-5" />
                      ) : (
                        t('update_profile')
                      )}
                    </button>
                 </div>
              </form>
            </div>
          </div>

          {/* Purchase History */}
          <div className="md:col-span-2">
            <div className="bg-[#1a1a1a] border border-[#2b2b2b] rounded-xl p-6">
              <h2 className="text-xl font-semibold text-white mb-6">{t('purchase_history')}</h2>
              <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
                {user.purchaseHistory && user.purchaseHistory.length > 0 ? (
                  user.purchaseHistory.map((app: PurchasedApp) => (
                    <div key={app.id} className="bg-[#0f0f0f] p-4 rounded-lg flex flex-col sm:flex-row items-center gap-4">
                      <img src={app.image} alt={app.title[locale]} className="w-24 h-16 object-cover rounded-md flex-shrink-0"/>
                      <div className="flex-grow text-center sm:text-left">
                        <h3 className="font-semibold text-white">{app.title[locale]}</h3>
                        <p className="text-sm text-gray-400">{app.price}</p>
                      </div>
                      <button
                        onClick={() => handleCopyLink(app.downloadUrl)}
                        className="flex-shrink-0 inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-[#FF6A00] bg-[#FF6A00]/10 rounded-lg hover:bg-[#FF6A00]/20 transition-colors"
                      >
                        <CopyIcon className="w-4 h-4" />
                        {t('copy_link')}
                      </button>
                    </div>
                  ))
                ) : (
                  <p className="text-center text-gray-400 py-8">{t('no_purchases')}</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
