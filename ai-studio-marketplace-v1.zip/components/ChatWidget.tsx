import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Chat, FunctionDeclaration, Type } from "@google/genai";
import { useI18n } from '../hooks/useI18n';
import { useMarketplace } from '../hooks/useMarketplace';
import ChatIcon from './icons/ChatIcon';
import SendIcon from './icons/SendIcon';
import XIcon from './icons/XIcon';
import ZaloIcon from './icons/ZaloIcon';
import WhatsappIcon from './icons/WhatsappIcon';
import TypingIndicator from './TypingIndicator';


type Message = {
  id: number;
  text: string;
  sender: 'user' | 'ai';
};

const displayManagementSystemFunctionDeclaration: FunctionDeclaration = {
  name: 'displayManagementSystem',
  description: 'Activates and displays the embedded Smart Management System for complex enterprise tasks like analytics, workflow automation, or resource planning.',
  parameters: {
    type: Type.OBJECT,
    properties: {},
  },
};

const ChatWidget: React.FC = () => {
  const { t, locale } = useI18n();
  const { apps } = useMarketplace();
  const [isOpen, setIsOpen] = useState(false);
  const [isFabExpanded, setIsFabExpanded] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const chatSessionRef = useRef<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [showManagementSystem, setShowManagementSystem] = useState(false);
  const fabRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      if (!chatSessionRef.current) {
        try {
          const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

          const appDataForAI = apps.map(app => ({
            id: app.id,
            title: app.title[locale],
            description: app.description[locale],
            price: app.price,
            tags: app.tags.join(', ')
          }));

          const systemInstruction = `You are a helpful and friendly sales assistant for the AI Studio Marketplace. Your primary goal is to help users find and understand the AI apps available for purchase. You must communicate in ${locale === 'vi' ? 'Vietnamese' : 'English'}.

          You have deep knowledge of the following applications currently available in the store:
          --- START OF APP CATALOG ---
          ${JSON.stringify(appDataForAI, null, 2)}
          --- END OF APP CATALOG ---
          
          When a user asks for recommendations, refer to this catalog. You can answer questions about app features, pricing, and what they are used for based on their title, description, and tags.
          If you recommend an app, mention its exact title. Make your recommendations sound natural and helpful, like a real sales assistant.
          
          Additionally, you have access to a powerful 'Smart Management System'. If a user's request involves complex tasks like enterprise resource planning, detailed analytics, workflow automation, or any other advanced business management function that goes beyond simple app recommendations, you should activate this system. To do this, you must call the \`displayManagementSystem\` function. You can also provide a short text response before calling the function.

          If a user asks a question you cannot answer from the provided catalog or tools, politely say that you specialize in the apps available here and can't provide information on other topics.`;

          chatSessionRef.current = ai.chats.create({
            model: 'gemini-2.5-flash',
            config: {
              systemInstruction: systemInstruction,
              tools: [{ functionDeclarations: [displayManagementSystemFunctionDeclaration] }],
            },
          });
          setMessages([{ id: Date.now(), text: t('chat_welcome'), sender: 'ai' }]);
        } catch (error) {
          console.error("Failed to initialize GoogleGenAI:", error);
          setMessages([{ id: Date.now(), text: "Sorry, I can't connect to the AI assistant right now.", sender: 'ai' }]);
        }
      }
    }
  }, [isOpen, t, apps, locale]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading, showManagementSystem]);
  
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (fabRef.current && !fabRef.current.contains(event.target as Node)) {
        setIsFabExpanded(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSendMessage = async () => {
    const trimmedInput = inputValue.trim();
    if (!trimmedInput || isLoading || !chatSessionRef.current) return;
    
    if (showManagementSystem) {
        setShowManagementSystem(false);
    }

    const userMessage: Message = { id: Date.now(), text: trimmedInput, sender: 'user' };
    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      const stream = await chatSessionRef.current.sendMessageStream({ message: trimmedInput });
      
      let aiResponseText = '';
      const aiMessageId = Date.now() + 1;
      
      setMessages(prev => [...prev, { id: aiMessageId, text: '', sender: 'ai' }]);

      for await (const chunk of stream) {
        if (chunk.text) {
            aiResponseText += chunk.text;
            setMessages(prev =>
              prev.map(msg =>
                msg.id === aiMessageId ? { ...msg, text: aiResponseText } : msg
              )
            );
        }
        
        if (chunk.functionCalls) {
            for (const fc of chunk.functionCalls) {
                if (fc.name === 'displayManagementSystem') {
                    setShowManagementSystem(true);
                    if (!aiResponseText.trim()) {
                        setMessages(prev =>
                            prev.map(msg =>
                                msg.id === aiMessageId ? { ...msg, text: t('chat_opening_management_system') } : msg
                            )
                        );
                    }
                }
            }
        }
      }
    } catch (error) {
      console.error('Error sending message to Gemini:', error);
      const errorMessage: Message = { id: Date.now() + 1, text: "Sorry, something went wrong. Please try again.", sender: 'ai' };
      setMessages(prev => [...prev.slice(0, -1), errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleOpenChat = () => {
    setIsOpen(true);
    setIsFabExpanded(false);
  };
  
  const contactOptions = [
    {
      label: t('chat_now_whatsapp'),
      icon: <WhatsappIcon className="w-6 h-6" />,
      href: 'https://wa.me/84766771509',
      action: null,
    },
    {
      label: t('chat_now_zalo'),
      icon: <ZaloIcon className="w-6 h-6" />,
      href: 'https://zalo.me/0766771509',
      action: null,
    },
    {
      label: t('chat_now_chat'),
      icon: <ChatIcon className="w-6 h-6" />,
      href: '#',
      action: handleOpenChat,
    },
  ];

  return (
    <div className="fixed bottom-6 right-6 z-[90]">
      {/* Chat Window */}
      <div
        className={`w-80 sm:w-96 bg-[#1a1a1a] border border-[#2b2b2b] rounded-xl shadow-2xl flex flex-col transition-all duration-300 ease-in-out origin-bottom-right ${
          isOpen ? 'h-[28rem] sm:h-[32rem] opacity-100 scale-100' : 'h-0 opacity-0 scale-95 pointer-events-none'
        }`}
      >
        {/* Header */}
        <div className="flex-shrink-0 flex items-center justify-between p-4 border-b border-[#2b2b2b]">
          <h3 className="font-bold text-white text-lg">{t('chat_ai_agent')}</h3>
          <button
            onClick={() => setIsOpen(false)}
            className="p-1 rounded-full text-[#A8A8A8] hover:bg-[#2b2b2b] hover:text-white"
            aria-label="Close chat"
          >
            <XIcon />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 p-4 overflow-y-auto">
          <div className="space-y-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex items-end gap-2 ${msg.sender === 'user' ? 'justify-end animate-[message-in-right_0.4s_ease-out]' : 'justify-start animate-[message-in-left_0.4s_ease-out]'}`}
              >
                <div
                  className={`max-w-[80%] rounded-xl px-4 py-2.5 text-sm whitespace-pre-wrap ${
                    msg.sender === 'user'
                      ? 'bg-[#FF6A00] text-black rounded-br-none'
                      : 'bg-[#2b2b2b] text-white rounded-bl-none'
                  }`}
                >
                  {msg.text}
                </div>
              </div>
            ))}
             {isLoading && (
              <div className="flex justify-start animate-[message-in-left_0.4s_ease-out]">
                <div className="bg-[#2b2b2b] rounded-xl px-4 py-2.5 rounded-bl-none">
                  <TypingIndicator />
                </div>
              </div>
            )}
            {showManagementSystem && (
                <div className="flex justify-start">
                    <div className="w-full bg-[#0f0f0f] border border-[#2b2b2b] rounded-xl p-2 flex flex-col animate-[pop-in_0.3s_ease-out]">
                       <iframe
                            src="https://ultimate-ai-enterprise-v1-0-4-test-khong-dang-nha-1055277262055.us-west1.run.app/"
                            className="w-full h-80 rounded-lg"
                            style={{ border: 'none' }}
                            title="Ultimate AI Enterprise"
                            sandbox="allow-scripts allow-same-origin allow-forms"
                        ></iframe>
                        <button
                            onClick={() => setShowManagementSystem(false)}
                            className="mt-2 self-end text-xs text-[#A8A8A8] hover:text-white bg-[#2b2b2b] px-3 py-1 rounded-md transition-colors"
                        >
                            {t('chat_close_system')}
                        </button>
                    </div>
                </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Input */}
        <div className="flex-shrink-0 p-4 border-t border-[#2b2b2b]">
          <div className="relative">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder={t('chat_placeholder')}
              className="w-full pl-4 pr-12 py-2.5 bg-[#0f0f0f] border border-[#2b2b2b] rounded-lg text-white focus:ring-2 focus:ring-[#FF6A00] focus:border-[#FF6A00] outline-none"
            />
            <button
              onClick={handleSendMessage}
              disabled={isLoading}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-[#FF6A00] text-black rounded-md hover:bg-[#ff8533] transition-colors disabled:opacity-50"
              aria-label="Send message"
            >
              <SendIcon />
            </button>
          </div>
        </div>
      </div>

      {/* FAB and Menu */}
      <div ref={fabRef} className={`relative mt-4 flex flex-col items-end transition-transform duration-300 ${isOpen ? 'scale-0 opacity-0' : 'scale-100 opacity-100'}`}>
        {/* Expanded Options */}
        <div className={`flex flex-col items-end gap-3 mb-4`}>
          {contactOptions.map((option, index) => (
            <div
              key={index}
              className={`transition-all duration-300 ease-out ${isFabExpanded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'}`}
              style={{ transitionDelay: `${(contactOptions.length - 1 - index) * 50}ms` }}
            >
              {option.action ? (
                <button
                  onClick={option.action}
                  className="flex items-center gap-3 bg-[#2b2b2b] text-white rounded-full shadow-lg p-3 pr-4 hover:bg-[#3c3c3c] transition-all"
                  aria-label={option.label}
                >
                  <span className="text-sm font-semibold">{option.label}</span>
                  {option.icon}
                </button>
              ) : (
                <a
                  href={option.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 bg-[#2b2b2b] text-white rounded-full shadow-lg p-3 pr-4 hover:bg-[#3c3c3c] transition-all"
                  aria-label={option.label}
                >
                  <span className="text-sm font-semibold">{option.label}</span>
                  {option.icon}
                </a>
              )}
            </div>
          ))}
        </div>

        {/* Main Toggle Button */}
        <button
          onClick={() => setIsFabExpanded(!isFabExpanded)}
          className={`group flex items-center justify-center w-16 h-16 bg-[#FF6A00] rounded-full text-black shadow-lg hover:bg-[#ff8533] transition-colors duration-300 animate-[breathing-glow_4s_ease-in-out_infinite]`}
          aria-label={t('chat_main_fab_label')}
          aria-expanded={isFabExpanded}
        >
          <div className={`transition-transform duration-300 group-hover:scale-110 group-hover:rotate-12 ${isFabExpanded ? 'rotate-45' : 'rotate-0'}`}>
            {isFabExpanded ? <XIcon className="w-7 h-7" /> : <ChatIcon className="w-7 h-7" />}
          </div>
        </button>
      </div>
    </div>
  );
};

export default ChatWidget;