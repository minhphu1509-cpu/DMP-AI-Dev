import React from 'react';
import { useI18n } from '../hooks/useI18n';
import { useCart } from '../hooks/useCart';
import { usePayment } from '../hooks/usePayment';
import OrderSummary from './OrderSummary';
import PaymentMethodSelector from './PaymentMethodSelector';
import SpinnerIcon from './icons/SpinnerIcon';
import PaymentDetails from './PaymentDetails';
import { formatCurrency, getPriceAsNumber } from '../utils/formatters';

const CheckoutPage: React.FC = () => {
  const { t, locale } = useI18n();
  const { cartItems } = useCart();
  const { selectedMethod, isProcessing, processPayment } = usePayment();

  const handlePayment = () => {
    if (selectedMethod) {
      processPayment(cartItems);
    }
  };
  
  const subtotal = cartItems.reduce((acc, item) => {
    return acc + getPriceAsNumber(item.price);
  }, 0);

  const formattedSubtotal = formatCurrency(subtotal, locale);

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white text-center mb-10">
          {t('checkout_title')}
        </h1>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Left Column: Payment Details */}
          <div className="bg-[#1a1a1a] border border-[#2b2b2b] rounded-xl p-6 md:p-8">
            <h2 className="text-xl font-semibold text-white mb-6">{t('payment_method')}</h2>
            <PaymentMethodSelector />
            <PaymentDetails />
          </div>

          {/* Right Column: Order Summary */}
          <div className="bg-[#1a1a1a] border border-[#2b2b2b] rounded-xl p-6 md:p-8 self-start">
            <OrderSummary />
            <div className="mt-8">
              <button
                onClick={handlePayment}
                disabled={isProcessing || cartItems.length === 0}
                className="w-full flex items-center justify-center bg-[#FF6A00] text-black font-semibold py-3 rounded-lg transition-all duration-300 hover:bg-[#ff8533] disabled:bg-[#FF6A00]/50 disabled:cursor-not-allowed"
              >
                {isProcessing ? (
                  <>
                    <SpinnerIcon className="animate-spin -ml-1 mr-3 h-5 w-5" />
                    {t('processing_payment')}
                  </>
                ) : (
                  `${t('pay_now')} - ${formattedSubtotal}`
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;