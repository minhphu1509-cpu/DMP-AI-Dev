import React from 'react';
import { useI18n } from '../hooks/useI18n';
import { useNews } from '../hooks/useNews';
import NewsCard from './NewsCard';

const BlogPage: React.FC = () => {
  const { t } = useI18n();
  const { newsPosts } = useNews();

  // Sort posts by date, newest first
  const sortedPosts = [...newsPosts].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
      <div className="text-center mb-12">
        <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">
          {t('blog_title')}
        </h1>
        <p className="mt-4 max-w-2xl mx-auto text-lg text-[#A8A8A8]">
          {t('blog_description')}
        </p>
      </div>
      
      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
        {sortedPosts.map((post) => (
          <NewsCard key={post.id} post={post} />
        ))}
      </div>
    </div>
  );
};

export default BlogPage;