import React, { useMemo } from 'react';
import { useAnalytics } from '../hooks/useAnalytics';
import { useI18n } from '../hooks/useI18n';
import { formatCurrency, getPriceAsNumber } from '../utils/formatters';
import { AnalyticsEvent } from '../types';
import DownloadIcon from './icons/DownloadIcon';

const AnalyticsDashboard: React.FC = () => {
  const { events } = useAnalytics();
  const { t, locale } = useI18n();

  const stats = useMemo(() => {
    const salesEvents = events.filter(e => e.type === 'ORDER_COMPLETED' && e.orderDetails);
    const totalRevenue = salesEvents.reduce((acc, event) => acc + (event.orderDetails?.total || 0), 0);
    const totalOrders = salesEvents.length;
    const appViews = events.filter(e => e.type === 'APP_VIEW').length;
    const addsToCart = events.filter(e => e.type === 'ADD_TO_CART').length;
    
    return {
      totalRevenue,
      totalOrders,
      appViews,
      addsToCart,
      salesEvents
    };
  }, [events]);

  const handleDownloadCsv = () => {
    const salesData = stats.salesEvents;
    if (salesData.length === 0) return;

    let csvContent = "data:text/csv;charset=utf-8,";
    const headers = ["Date", "User Email", "Product ID", "Product Name (EN)", "Price (USD)", "Tags"];
    csvContent += headers.join(",") + "\r\n";

    salesData.forEach(event => {
      event.orderDetails?.items.forEach(item => {
        const row = [
          new Date(event.timestamp).toLocaleString(),
          event.userId || "N/A",
          item.id,
          `"${item.title.en.replace(/"/g, '""')}"`, // Handle quotes in title
          getPriceAsNumber(item.price),
          `"${item.tags.join(", ")}"`
        ];
        csvContent += row.join(",") + "\r\n";
      });
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `sales_report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
      <div className="mb-10">
        <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">{t('analytics_dashboard')}</h1>
        <p className="mt-2 text-lg text-[#A8A8A8]">{t('dashboard_overview')}</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title={t('total_revenue')} value={formatCurrency(stats.totalRevenue, locale)} />
        <StatCard title={t('total_orders')} value={stats.totalOrders.toString()} />
        <StatCard title={t('app_views')} value={stats.appViews.toString()} />
        <StatCard title={t('adds_to_cart')} value={stats.addsToCart.toString()} />
      </div>

      {/* Sales Report Table */}
      <div className="mt-12 bg-[#1a1a1a] border border-[#2b2b2b] rounded-xl">
        <div className="p-6 flex justify-between items-center border-b border-[#2b2b2b]">
            <h2 className="text-xl font-semibold text-white">{t('sales_report')}</h2>
            <button
                onClick={handleDownloadCsv}
                disabled={stats.salesEvents.length === 0}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-black bg-[#FF6A00] border border-transparent rounded-md shadow-sm hover:bg-[#ff8533] transition-colors disabled:bg-gray-500 disabled:cursor-not-allowed"
            >
                <DownloadIcon />
                {t('download_csv')}
            </button>
        </div>
        <div className="overflow-x-auto">
          {stats.salesEvents.length > 0 ? (
            <table className="w-full text-sm text-left text-[#A8A8A8]">
              <thead className="bg-[#0f0f0f]">
                <tr>
                  <th scope="col" className="px-6 py-3 font-medium">{t('report_date')}</th>
                  <th scope="col" className="px-6 py-3 font-medium">{t('report_user')}</th>
                  <th scope="col" className="px-6 py-3 font-medium">{t('report_products')}</th>
                  <th scope="col" className="px-6 py-3 font-medium text-right">{t('report_total')}</th>
                </tr>
              </thead>
              <tbody>
                {stats.salesEvents.map((event: AnalyticsEvent) => (
                  <tr key={event.id} className="border-b border-[#2b2b2b]">
                    <td className="px-6 py-4 whitespace-nowrap">{new Date(event.timestamp).toLocaleString()}</td>
                    <td className="px-6 py-4">{event.userId || 'Guest'}</td>
                    <td className="px-6 py-4">
                      <ul className="list-disc list-inside">
                        {event.orderDetails?.items.map(item => (
                          <li key={item.id} className="truncate" title={item.title[locale]}>
                            {item.title[locale]}
                          </li>
                        ))}
                      </ul>
                    </td>
                    <td className="px-6 py-4 text-right font-semibold text-white">
                        {formatCurrency(event.orderDetails?.total || 0, locale)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p className="p-8 text-center text-gray-400">{t('report_no_sales')}</p>
          )}
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ title: string; value: string }> = ({ title, value }) => (
    <div className="bg-[#1a1a1a] p-6 rounded-xl border border-[#2b2b2b]">
        <p className="text-sm font-medium text-[#A8A8A8]">{title}</p>
        <p className="mt-2 text-3xl font-bold text-white">{value}</p>
    </div>
);


export default AnalyticsDashboard;
