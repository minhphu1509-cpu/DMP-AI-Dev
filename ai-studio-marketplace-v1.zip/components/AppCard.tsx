import React, { useState, useRef, useEffect, memo } from 'react';
import { App } from '../types';
import { useI18n } from '../hooks/useI18n';
import { useCart } from '../hooks/useCart';
import { useToast } from '../hooks/useToast';
import { useWishlist } from '../hooks/useWishlist';
import StarIcon from './icons/StarIcon';
import HeartIcon from './icons/HeartIcon';
import MoreVerticalIcon from './icons/MoreVerticalIcon';
import EditIcon from './icons/EditIcon';
import TrashIcon from './icons/TrashIcon';
import { formatCurrency, getPriceAsNumber } from '../utils/formatters';
import { useApp as useAppNavigation } from '../hooks/useApp';

interface AppCardProps {
  app: App;
  showActions?: boolean;
  onEdit?: (app: App) => void;
  onDelete?: (appId: number) => void;
}

const AppCard: React.FC<AppCardProps> = ({ app, showActions = false, onEdit, onDelete }) => {
  const { locale, t } = useI18n();
  const { addToCart, isItemInCart } = useCart();
  const { showToast } = useToast();
  const { addToWishlist, removeFromWishlist, isItemInWishlist } = useWishlist();
  const { openAppDetailModal } = useAppNavigation();
  
  const [isActionsOpen, setIsActionsOpen] = useState(false);
  const actionsMenuRef = useRef<HTMLDivElement>(null);

  const isInCart = isItemInCart(app.id);
  const isInWishlist = isItemInWishlist(app.id);

  const isSubscription = app.price.includes('/mo');
  const priceNumber = getPriceAsNumber(app.price);
  const formattedPrice = formatCurrency(priceNumber, locale);
  const billingCycle = isSubscription ? t('monthly_billing') : '';
  const displayPrice = `${formattedPrice}${billingCycle}`;

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (actionsMenuRef.current && !actionsMenuRef.current.contains(event.target as Node)) {
        setIsActionsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleAddToCart = () => {
    if (isInCart) return;
    addToCart(app);
    const message = t('app_added_to_cart').replace('{appName}', app.title[locale]);
    showToast(message, 'success');
  }

  const handleToggleWishlist = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent card click-through
    if (isInWishlist) {
      removeFromWishlist(app.id);
      const message = t('app_removed_from_wishlist').replace('{appName}', app.title[locale]);
      showToast(message, 'info');
    } else {
      addToWishlist(app);
      const message = t('app_added_to_wishlist').replace('{appName}', app.title[locale]);
      showToast(message, 'success');
    }
  }

  const handleEdit = () => {
    onEdit?.(app);
    setIsActionsOpen(false);
  };

  const handleDelete = () => {
    onDelete?.(app.id);
    setIsActionsOpen(false);
  };

  const handleViewDetails = () => {
    openAppDetailModal(app);
  }

  return (
    <div className="bg-[#1a1a1a] border border-[#2b2b2b] rounded-xl overflow-hidden flex flex-col group transition-all duration-300 hover:border-[#FF6A00] hover:shadow-lg hover:shadow-[#FF6A00]/10 transform hover:-translate-y-1">
      <div className="relative">
        <button onClick={handleViewDetails} className="w-full text-left" aria-label={`View details for ${app.title[locale]}`}>
            <img className="h-48 w-full object-cover" src={app.image} alt={app.title[locale]} />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
        </button>
        
        {showActions && (
          <div className="absolute top-2 right-2 z-10" ref={actionsMenuRef}>
            <button
              onClick={() => setIsActionsOpen(prev => !prev)}
              className="p-2 bg-black/40 rounded-full text-white hover:bg-black/60 transition-colors"
              aria-label="Actions"
            >
              <MoreVerticalIcon />
            </button>
            {isActionsOpen && (
              <div className="absolute right-0 mt-2 w-40 bg-[#2b2b2b] border border-white/10 rounded-md shadow-lg py-1 z-20">
                <button onClick={handleEdit} className="flex items-center w-full text-left px-3 py-2 text-sm text-[#A8A8A8] hover:bg-[#4a4a4a] hover:text-white">
                  <EditIcon className="w-4 h-4 mr-2" />
                  {t('edit_app')}
                </button>
                <button onClick={handleDelete} className="flex items-center w-full text-left px-3 py-2 text-sm text-red-400 hover:bg-red-500/20 hover:text-red-300">
                  <TrashIcon className="w-4 h-4 mr-2" />
                  {t('delete_app')}
                </button>
              </div>
            )}
          </div>
        )}

        <button 
          onClick={handleToggleWishlist}
          className={`absolute top-4 ${showActions ? 'right-[3.5rem]' : 'right-4'} z-10 p-2 bg-black/40 rounded-full text-white hover:text-red-500 hover:bg-black/60 transition-colors`}
          aria-label={isInWishlist ? `Remove ${app.title[locale]} from wishlist` : `Add ${app.title[locale]} to wishlist`}
        >
          <HeartIcon filled={isInWishlist} className={isInWishlist ? 'text-red-500' : ''} />
        </button>
        <div className="absolute bottom-4 left-4 flex items-center space-x-2">
          {app.tags.map((tag) => (
            <span key={tag} className="text-xs font-semibold text-white bg-black/50 px-2 py-1 rounded-full backdrop-blur-sm">
              {tag}
            </span>
          ))}
        </div>
      </div>
      <button onClick={handleViewDetails} className="text-left p-6 flex flex-col flex-grow" aria-label={`View details for ${app.title[locale]}`}>
        <h3 className="text-xl font-semibold text-white">{app.title[locale]}</h3>
        <p className="mt-2 text-sm text-[#A8A8A8] flex-grow">{app.description[locale]}</p>
        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center">
            <StarIcon className="text-yellow-400" />
            <span className="ml-1.5 text-white font-semibold">{app.rating}</span>
            <span className="ml-1 text-sm text-[#A8A8A8]">({app.reviewCount})</span>
          </div>
          <span className="text-lg font-bold text-[#FF6A00]">{displayPrice}</span>
        </div>
      </button>
      <div className="p-6 pt-0">
          <button 
            onClick={handleAddToCart}
            disabled={isInCart}
            className={`w-full font-semibold py-2.5 rounded-lg border transition-all duration-300 ${
              isInCart 
                ? 'bg-green-500/20 text-green-400 border-green-500/30 cursor-not-allowed' 
                : 'bg-[#FF6A00]/10 text-[#FF6A00] border-[#FF6A00]/20 group-hover:bg-[#FF6A00] group-hover:text-black'
            }`}>
            {isInCart ? t('added_to_cart') : t('buy_now')}
          </button>
      </div>
    </div>
  );
};

export default memo(AppCard);