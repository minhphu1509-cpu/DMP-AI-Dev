import React from 'react';
import { NewsPost } from '../types';
import { useI18n } from '../hooks/useI18n';
import { getYoutubeVideoId } from '../utils/embeds';
import YoutubeIcon from './icons/YoutubeIcon';
import ExternalLinkIcon from './icons/ExternalLinkIcon';

interface NewsCardProps {
  post: NewsPost;
}

const NewsCard: React.FC<NewsCardProps> = ({ post }) => {
  const { locale, t } = useI18n();

  const renderContent = () => {
    switch (post.type) {
      case 'youtube':
        const videoId = getYoutubeVideoId(post.url);
        if (!videoId) {
          return <div className="aspect-video bg-[#0f0f0f] flex items-center justify-center text-red-400">Invalid YouTube URL</div>;
        }
        return (
          <div className="relative aspect-video w-full overflow-hidden rounded-t-xl">
            <iframe
              src={`https://www.youtube.com/embed/${videoId}`}
              title={post.title[locale]}
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="absolute top-0 left-0 w-full h-full"
            ></iframe>
          </div>
        );
      case 'link':
      case 'social':
      default:
        return (
          <a href={post.url} target="_blank" rel="noopener noreferrer" className="block relative aspect-video w-full overflow-hidden rounded-t-xl group">
             <img src={post.imageUrl || 'https://picsum.photos/seed/news_fallback/600/400'} alt={post.title[locale]} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
             <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
             <div className="absolute top-3 right-3 p-2 bg-black/40 rounded-full text-white">
                <ExternalLinkIcon />
             </div>
          </a>
        );
    }
  };

  const getSourceIcon = () => {
    const lowerSource = post.source.toLowerCase();
    if (lowerSource.includes('youtube')) return <YoutubeIcon className="text-red-500" />;
    return <ExternalLinkIcon className="text-gray-400" />;
  };

  return (
    <div className="bg-[#1a1a1a] border border-[#2b2b2b] rounded-xl overflow-hidden flex flex-col group transition-all duration-300 hover:border-[#FF6A00] hover:shadow-lg hover:shadow-[#FF6A00]/10 transform hover:-translate-y-1">
      {renderContent()}
      <div className="p-5 flex flex-col flex-grow">
        <div className="flex items-center gap-2 text-sm text-gray-400 mb-2">
            {getSourceIcon()}
            <span className="font-semibold">{post.source}</span>
            <span>&bull;</span>
            <span>{new Date(post.timestamp).toLocaleDateString(locale)}</span>
        </div>
        <h3 className="text-lg font-bold text-white mb-2">{post.title[locale]}</h3>
        <p className="text-sm text-[#A8A8A8] flex-grow mb-4">{post.description[locale]}</p>
        <a 
            href={post.url} 
            target="_blank" 
            rel="noopener noreferrer" 
            className="mt-auto inline-flex items-center gap-2 text-sm font-semibold text-[#FF6A00] hover:text-[#ff8533] transition-colors"
        >
          {post.type === 'youtube' ? t('watch_on_youtube') : t('view_on_source', { source: post.source })}
          <ExternalLinkIcon className="w-4 h-4" />
        </a>
      </div>
    </div>
  );
};

export default NewsCard;