import React, { useState } from 'react';
import { useI18n } from '../hooks/useI18n';
import { useApp } from '../hooks/useApp';
import { useAuth } from '../hooks/useAuth';
import GoogleIcon from './icons/GoogleIcon';
import SpinnerIcon from './icons/SpinnerIcon';

const LoginPage: React.FC = () => {
  const { t } = useI18n();
  const { goToSignup, goToAdminLogin } = useApp();
  const { login } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;
    setIsLoading(true);
    login(email, password);
  };

  const handleGoogleLogin = () => {
    setIsGoogleLoading(true);
    login('user@gmail.com');
  };

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-24">
      <div className="max-w-md mx-auto bg-[#1a1a1a] border border-[#2b2b2b] rounded-xl p-8">
        <div className="text-center">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
            {t('login_title')}
          </h1>
        </div>

        <div className="mt-8">
          <button 
            onClick={handleGoogleLogin}
            disabled={isLoading || isGoogleLoading}
            className="w-full flex items-center justify-center gap-3 px-4 py-3 bg-[#2b2b2b] text-white font-semibold rounded-lg border border-transparent hover:border-[#4a4a4a] transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {isGoogleLoading ? (
              <SpinnerIcon className="animate-spin w-5 h-5" />
            ) : (
              <GoogleIcon />
            )}
            {t('continue_with_google')}
          </button>
        </div>

        <div className="my-6 flex items-center gap-4">
          <div className="h-px bg-[#2b2b2b] flex-grow"></div>
          <span className="text-[#A8A8A8] text-sm">OR</span>
          <div className="h-px bg-[#2b2b2b] flex-grow"></div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-[#A8A8A8] mb-2">
              {t('email_address')}
            </label>
            <input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-2.5 bg-[#0f0f0f] border border-[#2b2b2b] rounded-md text-white focus:ring-2 focus:ring-[#FF6A00] focus:border-[#FF6A00] outline-none"
            />
          </div>
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-[#A8A8A8] mb-2">
              {t('password')}
            </label>
            <input
              id="password"
              name="password"
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2.5 bg-[#0f0f0f] border border-[#2b2b2b] rounded-md text-white focus:ring-2 focus:ring-[#FF6A00] focus:border-[#FF6A00] outline-none"
            />
          </div>
          <div>
            <button
              type="submit"
              disabled={isLoading || isGoogleLoading}
              className="w-full flex items-center justify-center bg-[#FF6A00] text-black font-semibold py-3 rounded-lg transition-all duration-300 hover:bg-[#ff8533] disabled:bg-[#FF6A00]/50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <SpinnerIcon className="animate-spin -ml-1 mr-3 h-5 w-5" />
                  {t('logging_in')}
                </>
              ) : (
                t('login')
              )}
            </button>
          </div>
        </form>

        <p className="mt-8 text-center text-sm text-[#A8A8A8]">
          {t('no_account')}{' '}
          <button onClick={goToSignup} className="font-medium text-[#FF6A00] hover:text-[#ff8533]">
            {t('signup')}
          </button>
        </p>
        <p className="mt-4 text-center text-sm text-[#A8A8A8]">
            {t('admin_prompt')}{' '}
            <button onClick={goToAdminLogin} className="font-medium text-[#FF6A00] hover:text-[#ff8533]">
                {t('admin_login_link')}
            </button>
        </p>
      </div>
    </div>
  );
};

export default LoginPage;