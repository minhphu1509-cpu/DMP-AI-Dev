import React, { useEffect, useState } from 'react';
import { ToastMessage } from '../types';
import { useToast } from '../hooks/useToast';
import CheckCircleIcon from './icons/CheckCircleIcon';
import XCircleIcon from './icons/XCircleIcon';
import InfoIcon from './icons/InfoIcon';

interface ToastProps {
  toast: ToastMessage;
}

const toastIcons = {
  success: <CheckCircleIcon className="w-6 h-6 text-green-400" />,
  error: <XCircleIcon className="w-6 h-6 text-red-400" />,
  info: <InfoIcon className="w-6 h-6 text-blue-400" />,
};

const Toast: React.FC<ToastProps> = ({ toast }) => {
  const { removeToast } = useToast();
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    const exitTimer = setTimeout(() => {
      setIsExiting(true);
      const removeTimer = setTimeout(() => removeToast(toast.id), 300); // Match animation duration
      return () => clearTimeout(removeTimer);
    }, 4700); // Start exit animation before auto-dismiss

    return () => clearTimeout(exitTimer);
  }, [toast.id, removeToast]);
  
  const handleClose = () => {
    setIsExiting(true);
    setTimeout(() => removeToast(toast.id), 300);
  };

  return (
    <div
      className={`flex items-start p-4 mb-4 w-full max-w-sm bg-[#2b2b2b] text-white rounded-lg shadow-lg border border-white/10 transition-all duration-300 ease-in-out transform ${
        isExiting ? 'opacity-0 translate-y-4' : 'opacity-100 translate-y-0'
      }`}
      role="alert"
    >
      <div className="flex-shrink-0">{toastIcons[toast.type]}</div>
      <div className="ml-3 mr-4 flex-1 text-sm font-medium">{toast.message}</div>
      <button onClick={handleClose} aria-label="Close" className="p-1 -m-1 text-[#A8A8A8] hover:text-white">
        <XCircleIcon className="w-5 h-5" />
      </button>
    </div>
  );
};

export default Toast;