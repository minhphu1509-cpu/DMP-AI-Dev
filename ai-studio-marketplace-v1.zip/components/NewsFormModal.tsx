import React, { useState, useEffect } from 'react';
import { useI18n } from '../hooks/useI18n';
import { NewsPost, NewsPostType } from '../types';

interface NewsFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (post: NewsPost) => void;
  postToEdit: NewsPost | null;
}

const emptyPost: Omit<NewsPost, 'id' | 'timestamp'> = {
  title: { vi: '', en: '' },
  description: { vi: '', en: '' },
  url: '',
  type: 'link',
  source: '',
  imageUrl: '',
};

const NewsFormModal: React.FC<NewsFormModalProps> = ({ isOpen, onClose, onSave, postToEdit }) => {
  const { t } = useI18n();
  const [formData, setFormData] = useState(postToEdit || emptyPost);

  useEffect(() => {
    setFormData(postToEdit || emptyPost);
  }, [postToEdit, isOpen]);

  if (!isOpen) return null;
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>, lang?: 'vi' | 'en', field?: 'title' | 'description') => {
    const { name, value } = e.target;
    if (lang && field) {
        setFormData(prev => ({
            ...prev,
            [field]: { ...prev[field], [lang]: value }
        }));
    } else {
        setFormData(prev => ({...prev, [name]: value}));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalPostData: NewsPost = {
        ...formData,
        id: postToEdit?.id || Date.now(),
        timestamp: postToEdit?.timestamp || new Date().toISOString(),
    };
    onSave(finalPostData);
  };
  
  return (
    <div className="fixed inset-0 bg-black/70 z-[100] flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-[#1a1a1a] border border-[#2b2b2b] rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto flex flex-col" onClick={(e) => e.stopPropagation()}>
        <form onSubmit={handleSubmit} className="flex flex-col h-full">
          <div className="p-6 border-b border-[#2b2b2b]">
            <h2 className="text-xl font-bold text-white">
              {postToEdit ? t('edit_post') : t('add_new_post')}
            </h2>
          </div>
          <div className="p-6 space-y-5 flex-grow">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <InputField label={t('form_title_vi')} name="title_vi" value={formData.title.vi} onChange={(e: any) => handleChange(e, 'vi', 'title')} required />
                  <InputField label={t('form_title_en')} name="title_en" value={formData.title.en} onChange={(e: any) => handleChange(e, 'en', 'title')} required />
              </div>
              <TextAreaField label={t('form_desc_vi')} name="desc_vi" value={formData.description.vi} onChange={(e: any) => handleChange(e, 'vi', 'description')} required />
              <TextAreaField label={t('form_desc_en')} name="desc_en" value={formData.description.en} onChange={(e: any) => handleChange(e, 'en', 'description')} required />
              
              <div>
                <label className="block text-sm font-medium text-[#A8A8A8] mb-2">{t('form_post_type')}</label>
                <select 
                    name="type" 
                    value={formData.type} 
                    onChange={(e) => handleChange(e as React.ChangeEvent<HTMLSelectElement>)} 
                    className="w-full px-4 py-2.5 bg-[#0f0f0f] border border-[#2b2b2b] rounded-md text-white focus:ring-2 focus:ring-[#FF6A00] focus:border-[#FF6A00] outline-none"
                >
                    <option value="link">{t('form_post_type_link')}</option>
                    <option value="social">{t('form_post_type_social')}</option>
                    <option value="youtube">{t('form_post_type_youtube')}</option>
                </select>
              </div>

              <InputField label={t('form_post_url')} name="url" value={formData.url} onChange={handleChange} placeholder="https://..." required />
              <InputField label={t('form_post_source')} name="source" value={formData.source} onChange={handleChange} placeholder="e.g., TechCrunch, YouTube" required />
              
              {(formData.type === 'link' || formData.type === 'social') && (
                <InputField label={`${t('form_image_url')} (Optional)`} name="imageUrl" value={formData.imageUrl} onChange={handleChange} placeholder="https://.../image.png" />
              )}
          </div>
          <div className="p-4 bg-[#0f0f0f] border-t border-[#2b2b2b] flex justify-end gap-4 rounded-b-xl">
            <button type="button" onClick={onClose} className="px-5 py-2.5 text-sm font-medium text-[#A8A8A8] bg-transparent border border-[#2b2b2b] rounded-lg hover:bg-[#2b2b2b] transition-colors">
              {t('cancel')}
            </button>
            <button type="submit" className="px-5 py-2.5 text-sm font-medium text-black bg-[#FF6A00] rounded-lg hover:bg-[#ff8533] transition-colors">
              {t('save_changes')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

const InputField: React.FC<any> = ({ label, ...props }) => (
    <div>
        <label className="block text-sm font-medium text-[#A8A8A8] mb-2">{label}</label>
        <input {...props} className="w-full px-4 py-2.5 bg-[#0f0f0f] border border-[#2b2b2b] rounded-md text-white focus:ring-2 focus:ring-[#FF6A00] focus:border-[#FF6A00] outline-none" />
    </div>
);
const TextAreaField: React.FC<any> = ({ label, ...props }) => (
    <div>
        <label className="block text-sm font-medium text-[#A8A8A8] mb-2">{label}</label>
        <textarea {...props} rows={3} className="w-full px-4 py-2 bg-[#0f0f0f] border border-[#2b2b2b] rounded-md text-white focus:ring-2 focus:ring-[#FF6A00] focus:border-[#FF6A00] outline-none" />
    </div>
);

export default NewsFormModal;
