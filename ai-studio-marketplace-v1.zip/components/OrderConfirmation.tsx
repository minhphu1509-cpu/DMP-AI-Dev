import React from 'react';
import { useApp } from '../hooks/useApp';
import { useI18n } from '../hooks/useI18n';

const OrderConfirmation: React.FC = () => {
  const { backToMarketplace } = useApp();
  const { t } = useI18n();

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-24">
      <div className="max-w-3xl mx-auto">
        <div className="text-center">
          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">
            {t('confirmation_title')}
          </h1>
          <p className="mt-4 text-lg text-[#A8A8A8]">
            {t('confirmation_description')}
          </p>
        </div>

        <div className="mt-12 text-center">
            <button 
                onClick={backToMarketplace}
                className="inline-flex items-center justify-center px-8 py-3 text-base font-medium text-white bg-transparent border border-[#2b2b2b] rounded-md hover:bg-[#2b2b2b] transition-colors"
            >
                {t('back_to_marketplace')}
            </button>
        </div>
      </div>
    </div>
  );
};

export default OrderConfirmation;