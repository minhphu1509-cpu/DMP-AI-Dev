import React, { useState, useEffect } from 'react';
import { useI18n } from '../hooks/useI18n';

interface SplashScreenProps {
  onComplete: () => void;
}

const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const { t } = useI18n();
  const [phase, setPhase] = useState(0); // 0: initial, 1: logo, 2: text, 3: progress, 4: button, 5: fading out
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timers: ReturnType<typeof setTimeout>[] = [];
    timers.push(setTimeout(() => setPhase(1), 200));   // Logo reveal
    timers.push(setTimeout(() => setPhase(2), 1200));  // Text fade-in
    timers.push(setTimeout(() => setPhase(3), 1700));  // Progress bar start
    timers.push(setTimeout(() => setPhase(4), 2700));  // Button fade-in
    return () => timers.forEach(clearTimeout);
  }, []);

  useEffect(() => {
    if (phase === 3) {
      const interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            return 100;
          }
          return prev + 2;
        });
      }, 20);
      return () => clearInterval(interval);
    }
  }, [phase]);

  const handleEnter = () => {
    setPhase(5);
    setTimeout(onComplete, 500); // Match fade-out duration
  };

  return (
    <div 
        className={`fixed inset-0 bg-[#0f0f0f] z-[2000] flex flex-col items-center justify-center transition-opacity duration-500 ease-in-out ${
            phase === 5 ? 'opacity-0 pointer-events-none' : 'opacity-100'
        }`}
    >
      <div className="text-center">
        <div className={`text-5xl sm:text-7xl font-bold tracking-wider transition-all duration-1000 ${phase >= 1 ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4'}`}>
          <span className="animate-text-reveal-a inline-block">AI</span>
          <span className="text-[#FF6A00] animate-text-reveal-s inline-block">STUDIO</span>
        </div>
        <p className={`mt-4 text-lg sm:text-xl text-[#A8A8A8] transition-opacity duration-700 delay-300 ${phase >= 2 ? 'opacity-100' : 'opacity-0'}`}>
          {t('splash_welcome_message')}
        </p>
      </div>

      <div className={`absolute bottom-24 w-full max-w-sm px-4 transition-opacity duration-500 ${phase >= 3 ? 'opacity-100' : 'opacity-0'}`}>
        <div className="w-full bg-[#2b2b2b] rounded-full h-1.5">
          <div 
            className="bg-[#FF6A00] h-1.5 rounded-full transition-all duration-1000 ease-out"
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      </div>
      
      <div className={`absolute bottom-10 transition-opacity duration-500 ${phase >= 4 ? 'opacity-100' : 'opacity-0'}`}>
        <button
          onClick={handleEnter}
          className="px-8 py-3 text-base font-medium text-black bg-[#FF6A00] border border-transparent rounded-md shadow-lg shadow-[#FF6A00]/20 hover:shadow-[#FF6A00]/40 transition-all duration-300 transform hover:-translate-y-1"
        >
          {t('splash_enter_site')}
        </button>
      </div>
    </div>
  );
};

export default SplashScreen;
