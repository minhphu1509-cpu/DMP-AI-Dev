
import React, { memo } from 'react';

const SkeletonCard: React.FC = () => {
  return (
    <div className="bg-[#1a1a1a] border border-[#2b2b2b] rounded-xl overflow-hidden flex flex-col">
      <div className="h-48 w-full bg-[#2b2b2b] animate-pulse"></div>
      <div className="p-6 flex flex-col flex-grow">
        <div className="h-6 w-3/4 bg-[#2b2b2b] rounded animate-pulse mb-4"></div>
        <div className="space-y-2 flex-grow">
            <div className="h-4 w-full bg-[#2b2b2b] rounded animate-pulse"></div>
            <div className="h-4 w-5/6 bg-[#2b2b2b] rounded animate-pulse"></div>
        </div>
        <div className="mt-4 flex items-center justify-between">
            <div className="h-5 w-1/3 bg-[#2b2b2b] rounded animate-pulse"></div>
            <div className="h-7 w-1/4 bg-[#2b2b2b] rounded animate-pulse"></div>
        </div>
      </div>
      <div className="p-6 pt-0">
        <div className="h-10 w-full bg-[#2b2b2b] rounded-lg animate-pulse"></div>
      </div>
    </div>
  );
};

export default memo(SkeletonCard);