import React from 'react';
import StarIcon from './icons/StarIcon';

interface StarRatingProps {
  rating: number;
  maxStars?: number;
  className?: string;
}

const StarRating: React.FC<StarRatingProps> = ({ rating, maxStars = 5, className }) => {
  const roundedRating = Math.round(rating * 2) / 2; // Round to nearest 0.5
  const fullStars = Math.floor(roundedRating);
  const halfStar = roundedRating % 1 !== 0;
  const emptyStars = maxStars - fullStars - (halfStar ? 1 : 0);

  return (
    <div className={`flex items-center ${className}`}>
      {[...Array(fullStars)].map((_, i) => (
        <StarIcon key={`full-${i}`} className="w-5 h-5 text-yellow-400" />
      ))}
      {halfStar && (
        <div className="relative w-5 h-5">
          <StarIcon className="absolute top-0 left-0 w-5 h-5 text-gray-600" />
          <div className="absolute top-0 left-0 h-full w-1/2 overflow-hidden">
            <StarIcon className="w-5 h-5 text-yellow-400" />
          </div>
        </div>
      )}
      {[...Array(emptyStars)].map((_, i) => (
        <StarIcon key={`empty-${i}`} className="w-5 h-5 text-gray-600" />
      ))}
    </div>
  );
};

export default React.memo(StarRating);
