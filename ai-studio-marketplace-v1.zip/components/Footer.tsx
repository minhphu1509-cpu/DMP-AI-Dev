import React from 'react';
import { useI18n } from '../hooks/useI18n';
import ArrowRightIcon from './icons/ArrowRightIcon';
import { useApp } from '../hooks/useApp';

const Footer: React.FC = () => {
  const { t } = useI18n();
  const { goToTerms, goToPrivacy, goToAbout, goToCareers, goToPress, goToMarketplace, goToAdminLogin } = useApp();

  return (
    <footer className="bg-black border-t border-white/10">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8">
          <div className="col-span-2 md:col-span-4 lg:col-span-2">
            <div className="text-2xl font-bold tracking-tighter">
              AI<span className="text-[#FF6A00]">STUDIO</span>
            </div>
            <p className="mt-4 text-sm text-[#A8A8A8] max-w-xs">
              {t('hero_subheadline')}
            </p>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white tracking-wider uppercase">Solutions</h3>
            <ul className="mt-4 space-y-2">
              <li><button onClick={goToMarketplace} className="text-sm text-[#A8A8A8] hover:text-white">AI Apps</button></li>
              <li><button onClick={goToMarketplace} className="text-sm text-[#A8A8A8] hover:text-white">Marketplace</button></li>
              <li><button onClick={goToMarketplace} className="text-sm text-[#A8A8A8] hover:text-white">For Developers</button></li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white tracking-wider uppercase">Company</h3>
            <ul className="mt-4 space-y-2">
              <li><button onClick={goToAbout} className="text-sm text-[#A8A8A8] hover:text-white">{t('footer_about')}</button></li>
              <li><button onClick={goToCareers} className="text-sm text-[#A8A8A8] hover:text-white">{t('footer_careers')}</button></li>
              <li><button onClick={goToPress} className="text-sm text-[#A8A8A8] hover:text-white">{t('footer_press')}</button></li>
            </ul>
          </div>
          <div className="col-span-2 md:col-span-4 lg:col-span-2">
            <h3 className="text-sm font-semibold text-white tracking-wider uppercase">{t('footer_newsletter_title')}</h3>
            <form className="mt-4 flex items-center gap-2">
              <input
                type="email"
                placeholder={t('footer_newsletter_placeholder')}
                className="w-full px-4 py-2 bg-[#1a1a1a] border border-[#2b2b2b] rounded-md text-white focus:ring-2 focus:ring-[#FF6A00] focus:border-[#FF6A00] outline-none"
              />
              <button
                type="submit"
                className="p-2.5 bg-[#FF6A00] text-black rounded-md hover:bg-[#ff8533] transition-colors"
              >
                <ArrowRightIcon />
              </button>
            </form>
          </div>
        </div>
        <div className="mt-16 pt-8 border-t border-white/10 flex flex-col sm:flex-row justify-between items-center">
          <p className="text-sm text-[#A8A8A8]">{t('footer_rights')}</p>
          <div className="flex space-x-6 mt-4 sm:mt-0">
            <button onClick={goToPrivacy} className="text-sm text-[#A8A8A8] hover:text-white">{t('footer_privacy')}</button>
            <button onClick={goToTerms} className="text-sm text-[#A8A8A8] hover:text-white">{t('terms_of_service')}</button>
            <button onClick={goToAdminLogin} className="text-sm text-[#A8A8A8] hover:text-white">{t('admin_login')}</button>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;