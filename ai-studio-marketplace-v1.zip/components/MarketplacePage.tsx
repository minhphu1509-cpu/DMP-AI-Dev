import React, { useState, useMemo } from 'react';
import { useI18n } from '../hooks/useI18n';
import { useMarketplace } from '../hooks/useMarketplace';
import { useToast } from '../hooks/useToast';
import AppCard from './AppCard';
import { App } from '../types';
import { useApp } from '../hooks/useApp';
import SearchIcon from './icons/SearchIcon';
import { getPriceAsNumber } from '../utils/formatters';
import { GoogleGenAI, Type } from '@google/genai';
import SparklesIcon from './icons/SparklesIcon';
import SpinnerIcon from './icons/SpinnerIcon';
import LoadingSpinner from './LoadingSpinner';
import { useAnalytics } from '../hooks/useAnalytics';
import Tooltip from './Tooltip';

const MarketplacePage: React.FC = () => {
  const { t, locale } = useI18n();
  const { apps, deleteApp } = useMarketplace();
  const { showToast } = useToast();
  const { openAppFormModal } = useApp();
  const { events } = useAnalytics();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState('All');
  const [sortBy, setSortBy] = useState('featured');
  
  const [isAiSearching, setIsAiSearching] = useState(false);
  const [aiRecommendedApps, setAiRecommendedApps] = useState<App[] | null>(null);

  const [isFetchingPersonalized, setIsFetchingPersonalized] = useState(false);
  const [personalizedRecommendations, setPersonalizedRecommendations] = useState<App[] | null>(null);

  const recentlyViewedApps = useMemo(() => {
    const viewEvents = events.filter(e => e.type === 'APP_VIEW' && e.appId);
    // Get unique app IDs, most recent first
    const uniqueAppIds = [...new Set(viewEvents.map(e => e.appId).reverse())]; 
    return uniqueAppIds
        .slice(0, 5) // Take last 5 unique viewed apps
        .map(id => apps.find(app => app.id === id))
        .filter((app): app is App => !!app);
  }, [events, apps]);

  const allTags = useMemo(() => {
    const tags = new Set<string>();
    apps.forEach(app => app.tags.forEach(tag => tags.add(tag)));
    return [t('filter_all'), ...Array.from(tags).sort()];
  }, [apps, t]);

  const filteredAndSortedApps = useMemo(() => {
    let result = [...apps];

    // Filter by tag
    if (selectedTag !== t('filter_all')) {
      result = result.filter(app => app.tags.includes(selectedTag));
    }

    // Filter by search query
    if (searchQuery) {
      const lowercasedQuery = searchQuery.toLowerCase();
      result = result.filter(app =>
        app.title[locale].toLowerCase().includes(lowercasedQuery) ||
        app.description[locale].toLowerCase().includes(lowercasedQuery)
      );
    }

    // Sort
    switch (sortBy) {
      case 'newest':
        result.sort((a, b) => b.id - a.id);
        break;
      case 'price_asc':
        result.sort((a, b) => getPriceAsNumber(a.price) - getPriceAsNumber(b.price));
        break;
      case 'price_desc':
        result.sort((a, b) => getPriceAsNumber(b.price) - getPriceAsNumber(a.price));
        break;
      case 'rating_desc':
        result.sort((a, b) => b.rating - a.rating);
        break;
      case 'popularity_desc':
        result.sort((a, b) => (b.rating * b.reviewCount) - (a.rating * a.reviewCount));
        break;
      // 'featured' is the default, no sort needed as it uses the initial order
      default:
        break;
    }
    return result;
  }, [apps, selectedTag, searchQuery, sortBy, locale, t]);

  const handleOpenAddModal = () => {
    openAppFormModal(null);
  };

  const handleOpenEditModal = (app: App) => {
    openAppFormModal(app);
  };

  const handleDeleteApp = (appId: number) => {
    if (window.confirm(t('delete_app_confirm'))) {
      deleteApp(appId);
      showToast(t('app_deleted_successfully'), 'success');
    }
  };
  
  const handleGetPersonalizedRecommendations = async () => {
    if (recentlyViewedApps.length === 0) return;
    
    setIsFetchingPersonalized(true);
    setPersonalizedRecommendations(null);

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

        const appCatalog = apps.map(app => ({
            id: app.id,
            title: app.title[locale],
            description: app.description[locale],
            tags: app.tags
        }));
        
        const userHistory = recentlyViewedApps.map(app => ({
            id: app.id,
            title: app.title[locale],
            tags: app.tags
        }));

        const prompt = `You are an intelligent recommendation engine for an AI app marketplace. Your task is to analyze a user's recent browsing history and recommend other apps from the catalog that they might find interesting.

        Here is the complete catalog of available apps:
        ${JSON.stringify(appCatalog)}

        Here are the last few apps the user has viewed (their browsing history):
        ${JSON.stringify(userHistory)}

        Based on the user's history, identify apps from the main catalog that have similar tags, descriptions, or purposes. 

        **Crucially, DO NOT recommend any apps that are already present in the user's browsing history.**

        Return a JSON object containing an array of up to 5 app IDs for the recommended apps, ordered from most to least relevant. If no suitable new recommendations are found, return an empty array.`;
        
        const responseSchema = {
            type: Type.OBJECT,
            properties: {
                recommended_app_ids: {
                    type: Type.ARRAY,
                    description: 'An array of app IDs that best match the user query.',
                    items: { type: Type.NUMBER }
                }
            },
            required: ['recommended_app_ids']
        };

        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt,
          config: {
            responseMimeType: "application/json",
            responseSchema: responseSchema
          },
        });

        const jsonResponse = JSON.parse(response.text);
        const recommendedIds: number[] = jsonResponse.recommended_app_ids;

        const recommendations = recommendedIds
            .map(id => apps.find(app => app.id === id))
            .filter((app): app is App => !!app);
            
        setPersonalizedRecommendations(recommendations);
        
    } catch (error) {
        console.error('AI personalized recommendation failed:', error);
        showToast(t('ai_search_failed'), 'error');
    } finally {
        setIsFetchingPersonalized(false);
    }
};


  const handleAiSearch = async () => {
    if (!searchQuery.trim()) {
      showToast(t('ai_search_enter_query'), 'info');
      return;
    }
    
    setIsAiSearching(true);
    setAiRecommendedApps(null);
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
      
      const appCatalog = apps.map(app => ({
          id: app.id,
          title: app.title[locale],
          description: app.description[locale],
          tags: app.tags,
          rating: app.rating,
          reviewCount: app.reviewCount
      }));

      const prompt = `You are an intelligent AI filtering assistant for an app marketplace. Your task is to analyze a user's natural language query describing features, use cases, or characteristics, and return a list of app IDs that strictly match those criteria from the provided catalog.

      Here is the catalog of available apps:
      ${JSON.stringify(appCatalog, null, 2)}

      User's filtering criteria: "${searchQuery}"

      Analyze the user's criteria and the app catalog (including title, description, tags, and rating). Return a JSON object containing an array of IDs for only the apps that match the user's description. 
      For example:
      - If the user asks for 'apps that use image recognition', you should return apps tagged with 'Image' or with 'image recognition' in their description.
      - If they mention 'good customer support' or 'highly rated', you can infer this from a high rating (e.g., above 4.7).
      - If they ask for 'apps for business management', look for tags like 'Business' and 'Management'.
      
      If no apps match the criteria, return an empty array.`;
      
      const responseSchema = {
          type: Type.OBJECT,
          properties: {
            recommended_app_ids: {
              type: Type.ARRAY,
              description: 'An array of app IDs that best match the user query.',
              items: {
                type: Type.NUMBER,
              }
            }
          },
          required: ['recommended_app_ids']
      };
      
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: responseSchema,
        },
      });
      
      const jsonResponse = JSON.parse(response.text);
      const recommendedIds: number[] = jsonResponse.recommended_app_ids;

      if (recommendedIds.length > 0) {
        // We don't need to re-sort here, just display in the order the AI returned
        const recommendedApps = recommendedIds
          .map(id => apps.find(app => app.id === id))
          .filter((app): app is App => !!app);
        setAiRecommendedApps(recommendedApps);
      } else {
        setAiRecommendedApps([]);
      }
      
    } catch (error) {
      console.error('AI search failed:', error);
      showToast(t('ai_search_failed'), 'error');
      setAiRecommendedApps(null);
    } finally {
      setIsAiSearching(false);
    }
  };

  const clearAiSearch = () => {
    setAiRecommendedApps(null);
  };

  const appsToDisplay = aiRecommendedApps !== null ? aiRecommendedApps : filteredAndSortedApps;

  return (
    <>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div>
            <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">
              {t('nav_marketplace')}
            </h1>
            <p className="mt-2 text-lg text-[#A8A8A8]">
              {t('marketplace_description')}
            </p>
          </div>
          <button
            onClick={handleOpenAddModal}
            className="mt-6 md:mt-0 inline-flex items-center justify-center px-6 py-3 text-base font-medium text-black bg-[#FF6A00] border border-transparent rounded-md shadow-sm hover:bg-[#ff8533] transition-colors"
          >
            {t('add_new_app')}
          </button>
        </div>
        
        {/* Personalized Recommendations Section */}
        <div className="mb-10 p-6 bg-[#1a1a1a] border border-[#2b2b2b] rounded-xl">
            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 mb-4">
                <div>
                    <h2 className="text-xl font-bold text-white flex items-center gap-2">
                        <SparklesIcon className="text-[#FF6A00]" />
                        {t('ai_personalized_recommendations')}
                    </h2>
                    <p className="text-gray-400 text-sm mt-1">{t('ai_recs_description')}</p>
                </div>
                 <Tooltip text={recentlyViewedApps.length === 0 ? t('no_view_history_tooltip') : ''}>
                    {/* The div is necessary for the tooltip to work on a disabled button */}
                    <div> 
                        <button
                            onClick={handleGetPersonalizedRecommendations}
                            disabled={isFetchingPersonalized || recentlyViewedApps.length === 0}
                            className="inline-flex items-center justify-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-[#2b2b2b] rounded-lg hover:bg-[#4a4a4a] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {isFetchingPersonalized ? (
                                <>
                                    <SpinnerIcon className="w-5 h-5 animate-spin" />
                                    {t('fetching_ai_recs')}
                                </>
                            ) : (
                                t('get_ai_recommendations')
                            )}
                        </button>
                    </div>
                </Tooltip>
            </div>

            {personalizedRecommendations && (
                <div className="border-t border-white/10 pt-4">
                    {personalizedRecommendations.length > 0 ? (
                        <div className="relative">
                            <div className="flex gap-6 overflow-x-auto pb-4 -mx-6 px-6">
                                {personalizedRecommendations.map(app => (
                                    <div key={`rec-${app.id}`} className="w-72 flex-shrink-0">
                                        <AppCard app={app} />
                                    </div>
                                ))}
                            </div>
                        </div>
                    ) : (
                        <p className="text-center text-gray-400 py-4">{t('ai_no_recs_found')}</p>
                    )}
                    <div className="text-center mt-2">
                        <button onClick={() => setPersonalizedRecommendations(null)} className="text-sm font-semibold text-[#FF6A00]/80 hover:text-[#FF6A00] transition-colors">
                            {t('clear_recs')}
                        </button>
                    </div>
                </div>
            )}
        </div>
        
        {/* Search and Filter Controls */}
        <div className="mb-10 space-y-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-grow">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <SearchIcon className="text-gray-400" />
              </div>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t('search_apps_placeholder')}
                className="w-full pl-12 pr-4 py-3 bg-[#1a1a1a] border border-[#2b2b2b] rounded-lg text-white focus:ring-2 focus:ring-[#FF6A00] focus:border-[#FF6A00] outline-none"
              />
            </div>
            <button 
                onClick={handleAiSearch} 
                disabled={isAiSearching}
                className="flex items-center justify-center gap-2 px-4 py-3 bg-[#1a1a1a] border border-[#2b2b2b] rounded-lg text-white font-semibold hover:bg-[#222222] transition-colors disabled:opacity-50 disabled:cursor-wait"
            >
                {isAiSearching ? <SpinnerIcon className="w-5 h-5 animate-spin" /> : <SparklesIcon className="w-5 h-5 text-[#FF6A00]" />}
                {t('ai_search_button')}
            </button>
            {aiRecommendedApps === null && (
                <div className="relative">
                <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="w-full md:w-auto appearance-none pl-4 pr-10 py-3 bg-[#1a1a1a] border border-[#2b2b2b] rounded-lg text-white focus:ring-2 focus:ring-[#FF6A00] focus:border-[#FF6A00] outline-none"
                    aria-label={t('sort_by')}
                >
                    <option value="featured">{t('sort_featured')}</option>
                    <option value="newest">{t('sort_newest')}</option>
                    <option value="price_asc">{t('sort_price_asc')}</option>
                    <option value="price_desc">{t('sort_price_desc')}</option>
                    <option value="rating_desc">{t('sort_rating_desc')}</option>
                    <option value="popularity_desc">{t('sort_popularity_desc')}</option>
                </select>
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                    <svg className="w-5 h-5 text-gray-400" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
                </div>
                </div>
            )}
          </div>
          {aiRecommendedApps === null && (
            <div className="flex flex-wrap gap-2">
                {allTags.map(tag => (
                <button
                    key={tag}
                    onClick={() => setSelectedTag(tag)}
                    className={`px-4 py-2 text-sm font-semibold rounded-full transition-colors duration-200 ${
                    selectedTag === tag
                        ? 'bg-[#FF6A00] text-black'
                        : 'bg-[#2b2b2b] text-[#A8A8A8] hover:bg-[#4a4a4a] hover:text-white'
                    }`}
                >
                    {tag}
                </button>
                ))}
            </div>
           )}
        </div>
        
        {aiRecommendedApps !== null && (
            <div className="mb-8 p-4 bg-[#FF6A00]/10 border border-[#FF6A00]/20 rounded-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                    <h3 className="font-semibold text-white flex items-center gap-2">
                        <SparklesIcon className="w-5 h-5 text-[#FF6A00]" />
                        {t('ai_recommendations_for', { query: searchQuery })}
                    </h3>
                    <p className="text-sm text-gray-400 mt-1 pl-7">
                        {aiRecommendedApps.length > 0
                        ? t('ai_apps_found_count', { count: aiRecommendedApps.length })
                        : t('ai_no_apps_found')}
                    </p>
                </div>
                <button onClick={clearAiSearch} className="px-4 py-2 text-sm font-semibold text-[#FF6A00] hover:bg-[#FF6A00]/20 rounded-lg transition-colors flex-shrink-0">
                    {t('clear_ai_search')}
                </button>
            </div>
        )}
        
        {isAiSearching ? (
             <div className="flex justify-center items-center py-16">
                <LoadingSpinner />
            </div>
        ) : appsToDisplay.length > 0 ? (
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {appsToDisplay.map((app) => (
              <AppCard
                key={app.id}
                app={app}
                showActions={true}
                onEdit={handleOpenEditModal}
                onDelete={handleDeleteApp}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
             <p className="text-xl text-[#A8A8A8]">{aiRecommendedApps !== null ? t('ai_no_apps_found') : t('no_apps_found')}</p>
          </div>
        )}
      </div>
    </>
  );
};

export default MarketplacePage;