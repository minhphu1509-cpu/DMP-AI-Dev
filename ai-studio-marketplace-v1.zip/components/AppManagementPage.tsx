import React, { useState, useMemo, useCallback } from 'react';
import { useMarketplace } from '../hooks/useMarketplace';
import { useApp as useAppNavigation } from '../hooks/useApp';
import { useI18n } from '../hooks/useI18n';
import { useToast } from '../hooks/useToast';
import { App } from '../types';
import { getPriceAsNumber, formatCurrency } from '../utils/formatters';
import EditIcon from './icons/EditIcon';
import TrashIcon from './icons/TrashIcon';
import SortIcon from './icons/SortIcon';

type SortableKeys = 'id' | 'title' | 'price' | 'rating' | 'reviewCount';

const AppManagementPage: React.FC = () => {
    const { apps, deleteApp } = useMarketplace();
    const { openAppFormModal } = useAppNavigation();
    const { t, locale } = useI18n();
    const { showToast } = useToast();

    const [selectedAppIds, setSelectedAppIds] = useState<Set<number>>(new Set());
    const [sortConfig, setSortConfig] = useState<{ key: SortableKeys; direction: 'asc' | 'desc' }>({ key: 'id', direction: 'desc' });

    const sortedApps = useMemo(() => {
        let sortableApps = [...apps];
        if (sortConfig !== null) {
            sortableApps.sort((a, b) => {
                let aValue, bValue;

                switch (sortConfig.key) {
                    case 'title':
                        aValue = a.title[locale];
                        bValue = b.title[locale];
                        break;
                    case 'price':
                        aValue = getPriceAsNumber(a.price);
                        bValue = getPriceAsNumber(b.price);
                        break;
                    default:
                        aValue = a[sortConfig.key];
                        bValue = b[sortConfig.key];
                }

                if (aValue < bValue) {
                    return sortConfig.direction === 'asc' ? -1 : 1;
                }
                if (aValue > bValue) {
                    return sortConfig.direction === 'asc' ? 1 : -1;
                }
                return 0;
            });
        }
        return sortableApps;
    }, [apps, sortConfig, locale]);

    const requestSort = (key: SortableKeys) => {
        let direction: 'asc' | 'desc' = 'asc';
        if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
            direction = 'desc';
        }
        setSortConfig({ key, direction });
    };

    const handleSelectOne = (appId: number) => {
        const newSelection = new Set(selectedAppIds);
        if (newSelection.has(appId)) {
            newSelection.delete(appId);
        } else {
            newSelection.add(appId);
        }
        setSelectedAppIds(newSelection);
    };

    const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.checked) {
            const allAppIds = new Set(apps.map(app => app.id));
            setSelectedAppIds(allAppIds);
        } else {
            setSelectedAppIds(new Set());
        }
    };
    
    const handleEdit = (app: App) => openAppFormModal(app);

    const handleDelete = (appId: number) => {
        if (window.confirm(t('delete_app_confirm'))) {
            deleteApp(appId);
            showToast(t('app_deleted_successfully'), 'success');
        }
    };

    const handleBulkDelete = () => {
        const count = selectedAppIds.size;
        if (count === 0) return;
        
        if (window.confirm(t('delete_selected_confirm', { count }))) {
            selectedAppIds.forEach(id => deleteApp(id));
            showToast(t('apps_deleted_successfully', { count }), 'success');
            setSelectedAppIds(new Set());
        }
    };
    
    const SortableHeader: React.FC<{ sortKey: SortableKeys, children: React.ReactNode }> = ({ sortKey, children }) => (
        <th scope="col" className="px-6 py-3">
            <button onClick={() => requestSort(sortKey)} className="flex items-center gap-2 group">
                {children}
                <SortIcon className={`w-4 h-4 text-gray-500 transition-opacity ${sortConfig?.key === sortKey ? 'opacity-100' : 'opacity-30 group-hover:opacity-100'}`} />
            </button>
        </th>
    );

    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
                <div>
                    <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">{t('app_management')}</h1>
                    <p className="mt-2 text-lg text-[#A8A8A8]">{t('app_management_desc')}</p>
                </div>
                <button onClick={() => openAppFormModal(null)} className="mt-6 md:mt-0 inline-flex items-center justify-center px-6 py-3 text-base font-medium text-black bg-[#FF6A00] border border-transparent rounded-md shadow-sm hover:bg-[#ff8533] transition-colors">
                    {t('add_new_app')}
                </button>
            </div>

            <div className="bg-[#1a1a1a] border border-[#2b2b2b] rounded-xl overflow-hidden">
                <div className={`min-h-[4rem] px-6 py-3 flex items-center transition-all duration-300 ${selectedAppIds.size > 0 ? 'opacity-100' : 'opacity-0 h-0 p-0'}`}>
                    {selectedAppIds.size > 0 && (
                        <div className="flex items-center gap-4 w-full">
                            <span className="font-semibold text-white">{selectedAppIds.size} selected</span>
                            <div className="flex-grow"></div>
                            <button onClick={handleBulkDelete} className="flex items-center gap-2 px-4 py-2 text-sm font-semibold text-red-400 bg-red-500/10 rounded-lg hover:bg-red-500/20 transition-colors">
                                <TrashIcon className="w-4 h-4"/>
                                {t('delete_selected')}
                            </button>
                        </div>
                    )}
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-[#A8A8A8]">
                        <thead className="bg-[#0f0f0f] text-xs text-white uppercase tracking-wider">
                            <tr>
                                <th scope="col" className="p-4">
                                    <input type="checkbox" onChange={handleSelectAll} checked={selectedAppIds.size === apps.length && apps.length > 0} className="w-4 h-4 text-[#FF6A00] bg-[#2b2b2b] border-[#4a4a4a] rounded focus:ring-[#FF6A00] focus:ring-offset-[#1a1a1a]" />
                                </th>
                                <SortableHeader sortKey="id">{t('table_id')}</SortableHeader>
                                <SortableHeader sortKey="title">{t('table_title')}</SortableHeader>
                                <SortableHeader sortKey="price">{t('table_price')}</SortableHeader>
                                <SortableHeader sortKey="rating">{t('table_rating')}</SortableHeader>
                                <SortableHeader sortKey="reviewCount">{t('table_reviews')}</SortableHeader>
                                <th scope="col" className="px-6 py-3">{t('table_tags')}</th>
                                <th scope="col" className="px-6 py-3">{t('table_actions')}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {sortedApps.map((app) => (
                                <tr key={app.id} className="border-b border-[#2b2b2b] hover:bg-[#222222]">
                                    <td className="w-4 p-4">
                                        <input type="checkbox" checked={selectedAppIds.has(app.id)} onChange={() => handleSelectOne(app.id)} className="w-4 h-4 text-[#FF6A00] bg-[#2b2b2b] border-[#4a4a4a] rounded focus:ring-[#FF6A00] focus:ring-offset-[#1a1a1a]" />
                                    </td>
                                    <td className="px-6 py-4 font-medium text-gray-400">{app.id}</td>
                                    <td className="px-6 py-4 font-semibold text-white">{app.title[locale]}</td>
                                    <td className="px-6 py-4">{formatCurrency(getPriceAsNumber(app.price), locale)}{app.price.includes('/mo') ? t('monthly_billing') : ''}</td>
                                    <td className="px-6 py-4">{app.rating.toFixed(1)} ⭐</td>
                                    <td className="px-6 py-4">{app.reviewCount}</td>
                                    <td className="px-6 py-4">
                                        <div className="flex flex-wrap gap-1 max-w-xs">
                                            {app.tags.map(tag => <span key={tag} className="text-xs bg-[#2b2b2b] px-2 py-0.5 rounded">{tag}</span>)}
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex items-center gap-4">
                                            <button onClick={() => handleEdit(app)} className="text-gray-400 hover:text-[#FF6A00]" title={t('edit_app')}><EditIcon className="w-5 h-5"/></button>
                                            <button onClick={() => handleDelete(app.id)} className="text-gray-400 hover:text-red-500" title={t('delete_app')}><TrashIcon className="w-5 h-5"/></button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default AppManagementPage;