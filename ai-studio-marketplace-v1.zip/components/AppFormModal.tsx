import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useI18n } from '../hooks/useI18n';
import { App, Locale, DemoImage, Comment } from '../types';
import { GoogleGenAI } from '@google/genai';
import { useToast } from '../hooks/useToast';
import SparklesIcon from './icons/SparklesIcon';
import SpinnerIcon from './icons/SpinnerIcon';
import TrashIcon from './icons/TrashIcon';
import Tooltip from './Tooltip';
import QuestionMarkCircleIcon from './icons/QuestionMarkCircleIcon';
import { useAuth } from '../hooks/useAuth';
import { useMarketplace } from '../hooks/useMarketplace';
import Avatar from './Avatar';
import UsersIcon from './icons/UsersIcon';

interface AppFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (app: App) => void;
  appToEdit: App | null;
}

const emptyApp: Omit<App, 'id' | 'rating' | 'reviewCount'> = {
  title: { vi: '', en: '' },
  description: { vi: '', en: '' },
  price: '',
  tags: [],
  image: 'https://source.unsplash.com/random/600x400/?technology,abstract',
  demoImages: [],
  comments: [],
};

// Custom debounce hook
const useDebounce = (callback: (...args: any[]) => void, delay: number) => {
  // Fix: Use ReturnType<typeof setTimeout> for browser compatibility instead of NodeJS.Timeout.
  const timeoutRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  
  const debouncedCallback = useMemo(() => {
    return (...args: any[]) => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
      timeoutRef.current = setTimeout(() => {
        callback(...args);
      }, delay);
    };
  }, [callback, delay]);

  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  return debouncedCallback;
};


const AppFormModal: React.FC<AppFormModalProps> = ({ isOpen, onClose, onSave, appToEdit }) => {
  const { t } = useI18n();
  const { user } = useAuth();
  const { addComment } = useMarketplace();
  const { showToast } = useToast();
  const [formData, setFormData] = useState(appToEdit || emptyApp);
  const [tagsInput, setTagsInput] = useState(appToEdit?.tags.join(', ') || '');
  const [isGeneratingDesc, setIsGeneratingDesc] = useState({ vi: false, en: false });
  const [isGeneratingCaption, setIsGeneratingCaption] = useState<Record<number, { vi: boolean, en: boolean }>>({});
  const [newCommentText, setNewCommentText] = useState('');
  const [guestActivity, setGuestActivity] = useState<string | null>(null);


  useEffect(() => {
    if (appToEdit) {
      setFormData({
        ...appToEdit,
        demoImages: appToEdit.demoImages || [],
        comments: appToEdit.comments || [],
      });
      setTagsInput(appToEdit.tags.join(', '));
    } else {
      setFormData(emptyApp);
      setTagsInput('');
    }
  }, [appToEdit, isOpen]);
  
  const handleGuestUpdate = useCallback(async (targetLang: Locale) => {
      const sourceLang = targetLang === 'vi' ? 'en' : 'vi';
      const sourceText = formData.description[sourceLang];

      if (!sourceText.trim()) return;
      
      const targetLanguageName = targetLang === 'vi' ? 'Vietnamese' : 'English';
      setGuestActivity(t('guest_activity_translating', { language: targetLanguageName }));
      
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
        const prompt = `Translate the following app description to ${targetLanguageName}. Keep the tone engaging and suitable for a marketplace.
        Description: "${sourceText}"`;
        
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt,
        });

        const translatedText = response.text;
        setFormData(prev => ({
          ...prev,
          description: {
            ...prev.description,
            [targetLang]: translatedText,
          },
        }));

      } catch (error) {
        console.error('Error in guest update simulation:', error);
      } finally {
        setTimeout(() => setGuestActivity(null), 2000);
      }
  }, [formData.description, t]);

  const debouncedGuestUpdateVi = useDebounce(() => handleGuestUpdate('vi'), 2000);
  const debouncedGuestUpdateEn = useDebounce(() => handleGuestUpdate('en'), 2000);
  
  useEffect(() => {
    if(formData.description.en) debouncedGuestUpdateVi();
  }, [formData.description.en, debouncedGuestUpdateVi]);
  
  useEffect(() => {
     if(formData.description.vi) debouncedGuestUpdateEn();
  }, [formData.description.vi, debouncedGuestUpdateEn]);


  if (!isOpen) return null;
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>, lang?: 'vi' | 'en', field?: 'title' | 'description') => {
    const { name, value } = e.target;
    if (lang && field) {
        setFormData(prev => ({
            ...prev,
            [field]: {
                ...prev[field],
                [lang]: value
            }
        }));
    } else {
        setFormData(prev => ({...prev, [name]: value}));
    }
  };

  const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;

    const isMonthly = /\/mo/i.test(value);
    
    const numberMatch = value.match(/[0-9]+(\.[0-9]{0,2})?|\.[0-9]{1,2}/);
    let numberPart = numberMatch ? numberMatch[0] : '';

    let finalPrice = '';
    if (numberPart) {
        if (numberPart.startsWith('.')) {
            numberPart = '0' + numberPart;
        }
        finalPrice = `$${numberPart}`;
        if (isMonthly) {
            finalPrice += '/mo';
        }
    }

    setFormData(prev => ({ ...prev, price: finalPrice }));
  };

  const handleTagsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTagsInput(e.target.value);
    setFormData(prev => ({...prev, tags: e.target.value.split(',').map(tag => tag.trim()).filter(Boolean)}));
  };

  const handleGenerateDescription = async (lang: Locale) => {
    const title = formData.title[lang];
    const tags = formData.tags.join(', ');

    if (!title || !tags) {
      showToast(t('ai_missing_info'), 'info');
      return;
    }
    
    setIsGeneratingDesc(prev => ({ ...prev, [lang]: true }));

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
      const languageName = lang === 'vi' ? 'Vietnamese' : 'English';
      const prompt = `Generate a short, compelling marketplace description in ${languageName} for an AI application.
      
      App Title: "${title}"
      Features/Tags: ${tags}
      
      The description should be concise, engaging, and suitable for an app store listing. Focus on the key benefits for the user. Do not include the app title in the description itself.`;
      
      const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt,
      });

      const generatedText = response.text;
      
      setFormData(prev => ({
        ...prev,
        description: {
          ...prev.description,
          [lang]: generatedText,
        },
      }));

    } catch (error) {
      console.error('Error generating description with AI:', error);
      showToast(t('ai_generation_error'), 'error');
    } finally {
      setIsGeneratingDesc(prev => ({ ...prev, [lang]: false }));
    }
  };
  
  const handleGenerateCaption = async (index: number, lang: Locale) => {
    const title = formData.title[lang];
    const tags = formData.tags.join(', ');

    if (!title || !tags) {
      showToast(t('ai_caption_missing_info'), 'info');
      return;
    }

    setIsGeneratingCaption(prev => ({ ...prev, [index]: { ...prev[index], [lang]: true } }));

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
      const languageName = lang === 'vi' ? 'Vietnamese' : 'English';
      const prompt = `Generate a concise and engaging app store caption in ${languageName} for a demo image of an AI application.
- App Name: "${title}"
- Key Features: "${tags}"

Focus on one key feature from the list and write a caption that implies a visual demonstration of that feature. For example, if a feature is 'instant analysis', the caption could be 'See instant data analysis in action.' Make the caption short and punchy.`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
      });

      const generatedText = response.text.replace(/"/g, "");
      
      handleDemoImageChange(index, 'caption', generatedText, lang);

    } catch (error) {
      console.error('Error generating caption with AI:', error);
      showToast(t('ai_generation_error'), 'error');
    } finally {
      setIsGeneratingCaption(prev => ({ ...prev, [index]: { ...prev[index], [lang]: false } }));
    }
  };
  
  const handleAddDemoImage = () => {
    setFormData(prev => ({
        ...prev,
        demoImages: [...(prev.demoImages || []), { url: '', caption: { vi: '', en: '' } }]
    }));
  };

  const handleRemoveDemoImage = (index: number) => {
    setFormData(prev => ({
        ...prev,
        demoImages: prev.demoImages?.filter((_, i) => i !== index)
    }));
  };

  const handleDemoImageChange = (index: number, field: 'url' | 'caption', value: string, lang?: 'vi' | 'en') => {
      setFormData(prev => {
          const newDemoImages = [...(prev.demoImages || [])];
          if (field === 'caption' && lang) {
              newDemoImages[index].caption[lang as Locale] = value;
          } else if (field === 'url') {
              newDemoImages[index].url = value;
          }
          return { ...prev, demoImages: newDemoImages };
      });
  };
  
  const handlePostComment = () => {
    if (!newCommentText.trim() || !appToEdit) return;
    if (user?.email) {
      addComment(appToEdit.id, { authorEmail: user.email, text: newCommentText });
      setNewCommentText('');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalAppData: App = {
        ...formData,
        demoImages: formData.demoImages?.filter(img => img.url.trim() !== ''),
        comments: formData.comments || [],
        id: appToEdit?.id || Date.now(),
        rating: appToEdit?.rating || parseFloat((Math.random() * (5.0 - 3.5) + 3.5).toFixed(1)),
        reviewCount: appToEdit?.reviewCount || Math.floor(Math.random() * 500),
    };
    onSave(finalAppData);
  };
  
  return (
    <div className="fixed inset-0 bg-black/70 z-[100] flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-[#1a1a1a] border border-[#2b2b2b] rounded-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto flex flex-col" onClick={(e) => e.stopPropagation()}>
        <form onSubmit={handleSubmit} className="flex flex-col h-full">
          <div className="p-6 border-b border-[#2b2b2b] sticky top-0 bg-[#1a1a1a] z-10">
            <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold text-white">
                {appToEdit ? t('edit_app') : t('add_new_app')}
                </h2>
                <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-400 font-medium">{t('editing_now')}</span>
                    <div className="flex -space-x-2">
                        <Avatar email={user?.email || 'You'} />
                        <Avatar email={t('guest_user')} />
                    </div>
                </div>
            </div>
            {guestActivity && (
                 <div className="mt-2 text-center text-sm text-[#FF6A00] bg-[#FF6A00]/10 px-3 py-1.5 rounded-md animate-pulse">
                    {guestActivity}
                 </div>
            )}
          </div>
          <div className="p-6 space-y-6 flex-grow">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <InputField label={t('form_title_vi')} tooltip={t('tooltip_title')} value={formData.title.vi} onChange={(e: any) => handleChange(e, 'vi', 'title')} required />
                  <InputField label={t('form_title_en')} tooltip={t('tooltip_title')} value={formData.title.en} onChange={(e: any) => handleChange(e, 'en', 'title')} required />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 <TextAreaField 
                    label={t('form_desc_vi')} 
                    tooltip={t('tooltip_desc')}
                    value={formData.description.vi} 
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => handleChange(e, 'vi', 'description')} 
                    required 
                    onGenerate={() => handleGenerateDescription('vi')}
                    isGenerating={isGeneratingDesc.vi}
                    generateDisabled={!formData.title.vi || !tagsInput}
                  />
                 <TextAreaField 
                    label={t('form_desc_en')} 
                    tooltip={t('tooltip_desc')}
                    value={formData.description.en} 
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => handleChange(e, 'en', 'description')} 
                    required 
                    onGenerate={() => handleGenerateDescription('en')}
                    isGenerating={isGeneratingDesc.en}
                    generateDisabled={!formData.title.en || !tagsInput}
                  />
              </div>
              <InputField label={t('form_tags')} tooltip={t('tooltip_tags')} value={tagsInput} onChange={handleTagsChange} placeholder="Productivity, Text, Art" required />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <InputField label={t('form_price')} tooltip={t('tooltip_price')} name="price" value={formData.price} onChange={handlePriceChange} placeholder="$19.99 or $25.00/mo" required />
                <InputField label={t('form_image_url')} tooltip={t('tooltip_image_url')} name="image" value={formData.image} onChange={handleChange} />
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-[#A8A8A8] mb-3">
                    {t('form_demo_images')}
                    <Tooltip text={t('tooltip_demo_images')}>
                        <QuestionMarkCircleIcon className="w-4 h-4 text-gray-400" />
                    </Tooltip>
                </label>
                <div className="space-y-4">
                    {(formData.demoImages || []).map((img, index) => (
                        <div key={index} className="bg-[#0f0f0f] p-4 rounded-lg border border-[#2b2b2b] space-y-3 relative">
                           <InputField label={t('form_demo_image_url')} value={img.url} onChange={(e: any) => handleDemoImageChange(index, 'url', e.target.value)} />
                           <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                              <TextAreaField 
                                label={t('form_demo_caption_vi')} 
                                value={img.caption.vi} 
                                onChange={(e: any) => handleDemoImageChange(index, 'caption', e.target.value, 'vi')}
                                rows={2}
                                onGenerate={() => handleGenerateCaption(index, 'vi')}
                                isGenerating={isGeneratingCaption[index]?.vi}
                                generateDisabled={!formData.title.vi || !tagsInput}
                                title={t('ai_caption_missing_info')}
                              />
                              <TextAreaField 
                                label={t('form_demo_caption_en')} 
                                value={img.caption.en} 
                                onChange={(e: any) => handleDemoImageChange(index, 'caption', e.target.value, 'en')}
                                rows={2}
                                onGenerate={() => handleGenerateCaption(index, 'en')}
                                isGenerating={isGeneratingCaption[index]?.en}
                                generateDisabled={!formData.title.en || !tagsInput}
                                title={t('ai_caption_missing_info')}
                              />
                           </div>
                           <button type="button" onClick={() => handleRemoveDemoImage(index)} className="absolute top-2 right-2 p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-500/10 rounded-full">
                             <TrashIcon className="w-4 h-4" />
                           </button>
                        </div>
                    ))}
                    <button type="button" onClick={handleAddDemoImage} className="w-full text-center py-2.5 text-sm font-semibold text-[#FF6A00] bg-[#FF6A00]/10 rounded-lg border-2 border-dashed border-[#FF6A00]/30 hover:bg-[#FF6A00]/20 transition-colors">
                        {t('form_add_demo_image')}
                    </button>
                </div>
              </div>

              {/* Comments Section */}
              {appToEdit && (
                <div className="pt-6 border-t border-[#2b2b2b]">
                    <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                        <UsersIcon />
                        {t('comments')}
                    </h3>
                    <div className="space-y-4 max-h-64 overflow-y-auto pr-2">
                       {(formData.comments || []).map((comment) => (
                          <div key={comment.id} className="flex items-start gap-3">
                            <Avatar email={comment.authorEmail} />
                            <div className="bg-[#0f0f0f] px-4 py-2 rounded-lg w-full">
                                <div className="flex items-center justify-between">
                                    <span className="text-sm font-semibold text-white">{comment.authorEmail}</span>
                                    <span className="text-xs text-gray-500">{new Date(comment.timestamp).toLocaleString()}</span>
                                </div>
                                <p className="text-sm text-gray-300 mt-1">{comment.text}</p>
                            </div>
                          </div>
                       ))}
                    </div>
                    <div className="mt-4 flex items-start gap-3">
                        <Avatar email={user?.email || 'You'} />
                        <div className="w-full">
                           <textarea
                                value={newCommentText}
                                onChange={(e) => setNewCommentText(e.target.value)}
                                placeholder={t('add_a_comment')}
                                rows={2}
                                className="w-full px-3 py-2 bg-[#0f0f0f] border border-[#2b2b2b] rounded-md text-white focus:ring-2 focus:ring-[#FF6A00] outline-none"
                            />
                            <button type="button" onClick={handlePostComment} className="mt-2 px-4 py-1.5 text-sm font-semibold text-black bg-[#FF6A00] rounded-lg hover:bg-[#ff8533] transition-colors">
                               {t('post_comment')}
                            </button>
                        </div>
                    </div>
                </div>
              )}

          </div>
          <div className="p-4 bg-[#0f0f0f] border-t border-[#2b2b2b] flex justify-end gap-4 rounded-b-xl sticky bottom-0 z-10">
            <button type="button" onClick={onClose} className="px-5 py-2.5 text-sm font-medium text-[#A8A8A8] bg-transparent border border-[#2b2b2b] rounded-lg hover:bg-[#2b2b2b] transition-colors">
              {t('cancel')}
            </button>
            <button type="submit" className="px-5 py-2.5 text-sm font-medium text-black bg-[#FF6A00] rounded-lg hover:bg-[#ff8533] transition-colors">
              {appToEdit ? t('save_changes') : t('create_app')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

const InputField: React.FC<any> = ({ label, tooltip, ...props }) => (
    <div>
        <label className="flex items-center gap-2 text-sm font-medium text-[#A8A8A8] mb-2">
            {label}
            {tooltip && (
                <Tooltip text={tooltip}>
                    <QuestionMarkCircleIcon className="w-4 h-4 text-gray-400" />
                </Tooltip>
            )}
        </label>
        <input {...props} className="w-full px-4 py-2 bg-[#0f0f0f] border border-[#2b2b2b] rounded-md text-white focus:ring-2 focus:ring-[#FF6A00] focus:border-[#FF6A00] outline-none" />
    </div>
);
const TextAreaField: React.FC<any> = ({ label, onGenerate, isGenerating, generateDisabled, title, tooltip, ...props }) => {
  const { t } = useI18n();
  return (
    <div>
        <div className="flex justify-between items-center mb-2">
            <label className="flex items-center gap-2 text-sm font-medium text-[#A8A8A8]">
                {label}
                {tooltip && (
                    <Tooltip text={tooltip}>
                        <QuestionMarkCircleIcon className="w-4 h-4 text-gray-400" />
                    </Tooltip>
                )}
            </label>
            {onGenerate && (
                <button 
                    type="button" 
                    onClick={onGenerate}
                    disabled={isGenerating || generateDisabled}
                    className="flex items-center gap-1.5 text-xs font-semibold text-[#FF6A00] hover:text-[#ff8533] disabled:text-gray-500 disabled:cursor-not-allowed transition-colors"
                    title={generateDisabled ? t('ai_missing_info') : ''}
                >
                    {isGenerating ? (
                        <>
                            <SpinnerIcon className="w-4 h-4 animate-spin" />
                            {t('generating')}
                        </>
                    ) : (
                        <>
                            <SparklesIcon className="w-4 h-4" />
                            {t('generate_with_ai')}
                        </>
                    )}
                </button>
            )}
        </div>
        <textarea {...props} className="w-full px-4 py-2 bg-[#0f0f0f] border border-[#2b2b2b] rounded-md text-white focus:ring-2 focus:ring-[#FF6A00] focus:border-[#FF6A00] outline-none" />
    </div>
);
};


export default AppFormModal;