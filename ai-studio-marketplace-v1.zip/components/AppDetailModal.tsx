import React, { useState, useEffect } from 'react';
import { App, DemoImage, Review } from '../types';
import { useI18n } from '../hooks/useI18n';
import { useCart } from '../hooks/useCart';
import { useToast } from '../hooks/useToast';
import XIcon from './icons/XIcon';
import { formatCurrency, getPriceAsNumber } from '../utils/formatters';
import { useAuth } from '../hooks/useAuth';
import { useMarketplace } from '../hooks/useMarketplace';
import StarRating from './StarRating';
import StarRatingInput from './StarRatingInput';
import { useApp as useAppNavigation } from '../hooks/useApp';
import { useAnalytics } from '../hooks/useAnalytics';

interface AppDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  app: App | null;
}

const AppDetailModal: React.FC<AppDetailModalProps> = ({ isOpen, onClose, app }) => {
  const { locale, t } = useI18n();
  const { addToCart, isItemInCart } = useCart();
  const { showToast } = useToast();
  const { isAuthenticated, user } = useAuth();
  const { addReview } = useMarketplace();
  const { goToLogin, setPostLoginAction } = useAppNavigation();
  const { logEvent } = useAnalytics();
  
  const [currentImage, setCurrentImage] = useState<DemoImage | null>(null);
  const [activeTab, setActiveTab] = useState<'details' | 'reviews'>('details');
  const [newRating, setNewRating] = useState(0);
  const [newComment, setNewComment] = useState('');

  useEffect(() => {
    if (app && isOpen) {
      logEvent('APP_VIEW', { appId: app.id, appName: app.title.en });
      setCurrentImage({
          url: app.image,
          caption: {
              vi: app.title.vi,
              en: app.title.en,
          }
      });
      setActiveTab('details');
      setNewRating(0);
      setNewComment('');
    }
  }, [app, isOpen, logEvent]);

  if (!isOpen || !app) return null;

  const isInCart = isItemInCart(app.id);
  const galleryImages: DemoImage[] = [{ url: app.image, caption: { vi: app.title.vi, en: app.title.en } }, ...(app.demoImages || [])];
  
  const isSubscription = app.price.includes('/mo');
  const priceNumber = getPriceAsNumber(app.price);
  const formattedPrice = formatCurrency(priceNumber, locale);
  const billingCycle = isSubscription ? t('monthly_billing') : '';
  const displayPrice = `${formattedPrice}${billingCycle}`;

  const handleAddToCart = () => {
    if (isInCart) return;
    addToCart(app);
    const message = t('app_added_to_cart').replace('{appName}', app.title[locale]);
    showToast(message, 'success');
    onClose();
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newRating === 0 || !newComment.trim()) return;

    if (!isAuthenticated || !user) {
        showToast(t('login_to_review'), 'info');
        setPostLoginAction(null);
        goToLogin();
        return;
    }
    
    const review: Review = {
        id: Date.now(),
        author: user.email.split('@')[0],
        rating: newRating,
        comment: newComment,
        date: new Date().toISOString(),
    };

    addReview(app.id, review);
    showToast(t('review_submitted'), 'success');
    setNewRating(0);
    setNewComment('');
  };

  const renderDetailsTab = () => (
    <>
      <div className="flex items-center flex-wrap gap-2 mb-6">
        {app.tags.map((tag) => (
          <span key={tag} className="text-xs font-semibold text-[#FF6A00] bg-[#FF6A00]/10 px-3 py-1 rounded-full">
            {tag}
          </span>
        ))}
      </div>
      <p className="text-[#A8A8A8] text-base mb-6 flex-grow">{app.description[locale]}</p>
    </>
  );

  const renderReviewsTab = () => (
    <div className="flex flex-col h-full">
        <div className="bg-[#0f0f0f] p-4 rounded-lg mb-4 flex items-center justify-around text-center">
            <div>
                <p className="text-3xl font-bold text-yellow-400">{app.rating.toFixed(1)}</p>
                <StarRating rating={app.rating} />
                <p className="text-sm text-gray-400 mt-1">{t('average_rating')}</p>
            </div>
             <div>
                <p className="text-3xl font-bold text-white">{app.reviewCount}</p>
                <p className="text-sm text-gray-400 mt-2">{t('reviews_count', { count: app.reviewCount })}</p>
            </div>
        </div>
        
        <div className="flex-grow overflow-y-auto space-y-4 pr-2 mb-4">
            {app.reviews && app.reviews.length > 0 ? app.reviews.map(review => (
                <div key={review.id} className="bg-[#0f0f0f] p-4 rounded-lg">
                    <div className="flex items-center justify-between mb-1">
                        <span className="font-semibold text-white">{review.author}</span>
                        <span className="text-xs text-gray-400">{new Date(review.date).toLocaleDateString()}</span>
                    </div>
                    <StarRating rating={review.rating} />
                    <p className="mt-2 text-gray-300 text-sm">{review.comment}</p>
                </div>
            )) : <p className="text-center text-gray-400 py-8">No reviews yet.</p>}
        </div>
        
        {isAuthenticated ? (
            <form onSubmit={handleReviewSubmit} className="mt-auto pt-4 border-t border-white/10">
                <h4 className="font-semibold text-white mb-2">{t('leave_a_review')}</h4>
                <div className="mb-2">
                    <StarRatingInput rating={newRating} onRatingChange={setNewRating} />
                </div>
                <textarea
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder={t('your_comment')}
                    rows={2}
                    className="w-full px-3 py-2 bg-[#0f0f0f] border border-[#2b2b2b] rounded-md text-white focus:ring-2 focus:ring-[#FF6A00] outline-none"
                    required
                />
                <button type="submit" className="w-full mt-2 bg-[#FF6A00] text-black font-semibold py-2 rounded-lg hover:bg-[#ff8533] transition-colors">
                    {t('submit_review')}
                </button>
            </form>
        ) : (
            <div className="mt-auto pt-4 border-t border-white/10 text-center">
                <p className="text-gray-400">{t('login_to_review')}</p>
                <button onClick={goToLogin} className="mt-2 font-semibold text-[#FF6A00] hover:text-[#ff8533]">
                    {t('login')}
                </button>
            </div>
        )}

    </div>
  );

  return (
    <div
      className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-4 transition-opacity duration-300"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="app-detail-title"
    >
      <div
        className="bg-[#1a1a1a] border border-[#2b2b2b] rounded-xl w-full max-w-4xl max-h-[90vh] flex flex-col md:flex-row overflow-hidden transition-transform duration-300 scale-95 animate-scale-in"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Image Gallery */}
        <div className="w-full md:w-1/2 flex-shrink-0 bg-[#0f0f0f] flex flex-col p-4 sm:p-6">
          <div className="relative aspect-video w-full rounded-lg overflow-hidden mb-4">
            <img src={currentImage?.url || ''} alt="Selected app view" className="w-full h-full object-cover" />
            {currentImage && currentImage.caption[locale] !== app.title[locale] && (
                 <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/70 to-transparent">
                    <p className="text-white text-sm font-medium">{currentImage.caption[locale]}</p>
                </div>
            )}
          </div>
          <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-2">{t('app_details_demo_gallery')}</h3>
          <div className="flex-1 overflow-y-auto pr-2">
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
              {galleryImages.map((img, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentImage(img)}
                  className={`aspect-square rounded-md overflow-hidden border-2 transition-colors ${
                    currentImage?.url === img.url ? 'border-[#FF6A00]' : 'border-transparent hover:border-gray-600'
                  }`}
                >
                  <img src={img.url} alt={`Demo image ${index + 1}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* App Details */}
        <div className="w-full md:w-1/2 flex flex-col p-6 sm:p-8 overflow-y-auto">
          <div className="flex justify-between items-start mb-2">
             <h2 id="app-detail-title" className="text-2xl sm:text-3xl font-bold text-white pr-4">{app.title[locale]}</h2>
             <button onClick={onClose} className="p-2 -m-2 text-[#A8A8A8] hover:text-white hover:bg-[#2b2b2b] rounded-full transition-colors">
                <XIcon className="w-6 h-6" />
             </button>
          </div>
          <div className="flex items-center mb-4">
            <StarRating rating={app.rating} />
            <button onClick={() => setActiveTab('reviews')} className="ml-2 text-sm text-[#A8A8A8] hover:underline">({t('reviews_count', { count: app.reviewCount })})</button>
          </div>
          
          {/* Tabs */}
          <div className="flex border-b border-[#2b2b2b] mb-4">
            <button
              onClick={() => setActiveTab('details')}
              className={`px-4 py-2 text-sm font-semibold transition-colors ${activeTab === 'details' ? 'text-white border-b-2 border-[#FF6A00]' : 'text-gray-400 hover:text-white'}`}
            >
              {t('details_tab')}
            </button>
            <button
              onClick={() => setActiveTab('reviews')}
              className={`px-4 py-2 text-sm font-semibold transition-colors ${activeTab === 'reviews' ? 'text-white border-b-2 border-[#FF6A00]' : 'text-gray-400 hover:text-white'}`}
            >
              {t('reviews_tab')}
            </button>
          </div>
          
          <div className="flex-grow relative">
             <div className={`transition-opacity duration-300 ease-in-out ${activeTab === 'details' ? 'opacity-100' : 'opacity-0 hidden'}`}>
                {renderDetailsTab()}
             </div>
              <div className={`transition-opacity duration-300 ease-in-out h-full ${activeTab === 'reviews' ? 'opacity-100' : 'opacity-0 hidden'}`}>
                {renderReviewsTab()}
             </div>
          </div>
          
          <div className="mt-auto pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
            <span className="text-3xl font-bold text-[#FF6A00]">{displayPrice}</span>
            <button
                onClick={handleAddToCart}
                disabled={isInCart}
                className={`w-full sm:w-auto px-8 py-3 font-semibold rounded-lg border transition-all duration-300 ${
                isInCart 
                    ? 'bg-green-500/20 text-green-400 border-green-500/30 cursor-not-allowed' 
                    : 'bg-[#FF6A00] text-black border-transparent hover:bg-[#ff8533]'
                }`}
            >
                {isInCart ? t('added_to_cart') : t('buy_now')}
            </button>
          </div>
        </div>
      </div>
       <style>{`
        @keyframes scale-in {
            from { transform: scale(0.95); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }
        .animate-scale-in {
            animation: scale-in 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
       `}</style>
    </div>
  );
};

export default AppDetailModal;