import React from 'react';
import { useApp } from '../hooks/useApp';
import { useI18n } from '../hooks/useI18n';
import { useSiteContent } from '../hooks/useSiteContent';


const PrivacyPolicyPage: React.FC = () => {
  const { backToMarketplace } = useApp();
  const { t, locale } = useI18n();
  const { siteContent } = useSiteContent();
  const content = siteContent.privacy[locale] || '';

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-24">
      <div className="max-w-3xl mx-auto">
        <div className="text-center">
          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">
            {t('privacy_policy_title')}
          </h1>
        </div>
        
        <div className="mt-12 text-left prose prose-invert prose-lg max-w-none text-[#A8A8A8] space-y-6">
             <div className="whitespace-pre-wrap">{content}</div>
        </div>

        <div className="mt-12 text-center">
            <button 
                onClick={backToMarketplace}
                className="inline-flex items-center justify-center px-8 py-3 text-base font-medium text-white bg-transparent border border-[#2b2b2b] rounded-md hover:bg-[#2b2b2b] transition-colors"
            >
                {t('back_to_marketplace')}
            </button>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicyPage;