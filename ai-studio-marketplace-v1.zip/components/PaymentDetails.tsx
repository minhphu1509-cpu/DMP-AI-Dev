import React from 'react';
import { usePayment } from '../hooks/usePayment';
import { useI18n } from '../hooks/useI18n';

const PaymentDetails: React.FC = () => {
    const { selectedMethod } = usePayment();
    const { t } = useI18n();

    if (!selectedMethod) return null;

    const DetailRow: React.FC<{ label: string; value: string }> = ({ label, value }) => (
        <div className="flex justify-between items-center py-1">
            <span className="text-sm text-[#A8A8A8]">{label}:</span>
            <span className="text-sm font-semibold text-white">{value}</span>
        </div>
    );

    const renderDetails = () => {
        switch (selectedMethod) {
            case 'bank':
                const qrUrl = `https://img.vietqr.io/image/970407-554646686868-compact2.png?accountName=DONG%20MINH%20PHU`;
                return (
                    <div className="space-y-4">
                        <div>
                            <DetailRow label={t('bank_name')} value={t('techcombank')} />
                            <DetailRow label={t('account_number')} value="554646686868" />
                            <DetailRow label={t('account_holder')} value="DONG MINH PHU" />
                        </div>
                        <div className="text-center pt-2">
                            <div className="bg-white p-3 rounded-xl inline-block shadow-lg shadow-black/50 transform transition-transform hover:scale-105">
                                <img src={qrUrl} alt="VietQR Code" className="w-48 h-48" />
                            </div>
                            <p className="mt-3 text-base font-semibold text-white">{t('scan_qr_to_pay')}</p>
                        </div>
                    </div>
                );
            case 'momo':
                 return <DetailRow label={t('momo_account')} value="0766771509" />;
            case 'paypal':
                 return <DetailRow label={t('paypal_account')} value="dmpaidev@gmail.com" />;
            default:
                return null;
        }
    };

    return (
        <div className="mt-6 pt-6 border-t border-white/10">
            <h3 className="text-lg font-semibold text-white mb-4">{t('payment_details')}</h3>
            <div className="bg-[#0f0f0f] p-4 rounded-lg">
                {renderDetails()}
            </div>
        </div>
    );
};

export default PaymentDetails;