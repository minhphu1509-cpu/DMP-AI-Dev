import React from 'react';
import { useI18n } from '../hooks/useI18n';

const ManagementSystemPage: React.FC = () => {
  const { t } = useI18n();

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
      <div className="mb-10">
        <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">
          {t('management_system_title')}
        </h1>
      </div>
      <div className="bg-[#0f0f0f] border border-[#2b2b2b] rounded-xl p-2">
        <iframe
          src="https://ultimate-ai-enterprise-v1-0-4-test-khong-dang-nha-1055277262055.us-west1.run.app/"
          width="100%"
          height="800"
          style={{ border: 'none', borderRadius: '8px' }}
          title="Ultimate AI Enterprise"
          sandbox="allow-scripts allow-same-origin allow-forms"
        ></iframe>
      </div>
    </div>
  );
};

export default ManagementSystemPage;
