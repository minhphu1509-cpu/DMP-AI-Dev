import React, { useState, useRef, useEffect } from 'react';
import { useI18n } from '../hooks/useI18n';
import { Locale } from '../types';
import { useCart } from '../hooks/useCart';
import { useWishlist } from '../hooks/useWishlist';
import { useAuth } from '../hooks/useAuth';
import { useApp } from '../hooks/useApp';
import GlobeIcon from './icons/GlobeIcon';
import ShoppingCartIcon from './icons/ShoppingCartIcon';
import HeartIcon from './icons/HeartIcon';
import UserIcon from './icons/UserIcon';
import LogOutIcon from './icons/LogOutIcon';
import MiniCart from './MiniCart';
import WishlistPanel from './WishlistPanel';
import { useToast } from '../hooks/useToast';
import ChartBarIcon from './icons/ChartBarIcon';
import ServerIcon from './icons/ServerIcon';
import SettingsIcon from './icons/SettingsIcon';
import RssIcon from './icons/RssIcon';
import IdCardIcon from './icons/IdCardIcon';


const Header: React.FC = () => {
  const { t, locale, setLocale } = useI18n();
  const { cartItems } = useCart();
  const { wishlistItems } = useWishlist();
  const { isAuthenticated, user, logout, isAdmin } = useAuth();
  const { goToLogin, goToSignup, goToMarketplace, backToMarketplace, openAppFormModal, setPostLoginAction, goToContact, goToAnalytics, goToSiteManagement, goToAppManagement, goToBlog, goToNewsManagement, goToProfile } = useApp();
  const { showToast } = useToast();
  
  const [isLangDropdownOpen, setLangDropdownOpen] = useState(false);
  const [isCartOpen, setCartOpen] = useState(false);
  const [isWishlistOpen, setWishlistOpen] = useState(false);
  const [isUserMenuOpen, setUserMenuOpen] = useState(false);

  const langDropdownRef = useRef<HTMLDivElement>(null);
  const cartRef = useRef<HTMLDivElement>(null);
  const wishlistRef = useRef<HTMLDivElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);

  const handleAppSubmission = () => {
    if (isAuthenticated) {
      openAppFormModal(null);
    } else {
      showToast(t('login_to_submit'), 'info');
      setPostLoginAction('submit_app');
      goToLogin();
    }
  };
  
  const navItems = [
    { key: 'home', action: backToMarketplace },
    { key: 'apps', isLink: true },
    { key: 'marketplace', action: goToMarketplace },
    { key: 'submit', action: handleAppSubmission },
    { key: 'blog', action: goToBlog },
    { key: 'contact', action: goToContact },
  ];

  const adminNavItems = [
    { key: 'app_management', action: goToAppManagement, icon: <SettingsIcon className="w-4 h-4 mr-1.5"/> },
    { key: 'news_management', action: goToNewsManagement, icon: <RssIcon className="w-4 h-4 mr-1.5"/> },
    { key: 'site_management', action: goToSiteManagement, icon: <ServerIcon className="w-4 h-4 mr-1.5"/> },
    { key: 'analytics', action: goToAnalytics, icon: <ChartBarIcon className="w-4 h-4 mr-1.5"/> },
  ];

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Node;
      if (langDropdownRef.current && !langDropdownRef.current.contains(target)) setLangDropdownOpen(false);
      if (cartRef.current && !cartRef.current.contains(target)) setCartOpen(false);
      if (wishlistRef.current && !wishlistRef.current.contains(target)) setWishlistOpen(false);
      if (userMenuRef.current && !userMenuRef.current.contains(target)) setUserMenuOpen(false);
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleLocaleChange = (newLocale: Locale) => {
    setLocale(newLocale);
    setLangDropdownOpen(false);
  }
  
  const closeAllPanels = () => {
      setCartOpen(false);
      setWishlistOpen(false);
      setLangDropdownOpen(false);
      setUserMenuOpen(false);
  }

  const toggleCart = () => {
      const currentlyOpen = isCartOpen;
      closeAllPanels();
      setCartOpen(!currentlyOpen);
  }

  const toggleWishlist = () => {
      const currentlyOpen = isWishlistOpen;
      closeAllPanels();
      setWishlistOpen(!currentlyOpen);
  }
  
  const toggleUserMenu = () => {
      const currentlyOpen = isUserMenuOpen;
      closeAllPanels();
      setUserMenuOpen(!currentlyOpen);
  }

  const toggleLangDropdown = () => {
      const currentlyOpen = isLangDropdownOpen;
      closeAllPanels();
      setLangDropdownOpen(!currentlyOpen);
  }

  const renderNavItem = (item: typeof navItems[0]) => {
    if (item.action) {
      return (
        <button key={item.key} onClick={item.action} className="text-sm font-medium text-[#A8A8A8] hover:text-[#EAEAEA] transition-colors">
          {t(`nav_${item.key}`)}
        </button>
      );
    }
    return (
      <a key={item.key} href="#" className="text-sm font-medium text-[#A8A8A8] hover:text-[#EAEAEA] transition-colors">
        {t(`nav_${item.key}`)}
      </a>
    );
  };
  
  return (
    <header className="sticky top-0 z-50 bg-[#0f0f0f]/80 backdrop-blur-lg border-b border-white/10">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center">
            <button onClick={backToMarketplace} className="flex-shrink-0">
               <div className="text-2xl font-bold tracking-tighter">
                AI<span className="text-[#FF6A00]">STUDIO</span>
               </div>
            </button>
            <nav className="hidden md:flex items-center md:ml-10 md:space-x-8">
              {navItems.map(renderNavItem)}
               {isAdmin && <div className="h-4 w-px bg-white/10 mx-2"></div>}
               {isAdmin && adminNavItems.map(item => (
                <button key={item.key} onClick={item.action} className="flex items-center text-sm font-medium text-[#FF6A00] hover:text-[#ff8533] transition-colors">
                  {item.icon}
                  {t(item.key)}
                </button>
              ))}
            </nav>
          </div>
          <div className="flex items-center space-x-2">
            
            {isAuthenticated ? (
                <div className="relative" ref={userMenuRef}>
                    <button
                        onClick={toggleUserMenu}
                        className="flex items-center justify-center w-10 h-10 rounded-full text-[#A8A8A8] hover:bg-[#2b2b2b] hover:text-white transition-colors focus:outline-none"
                        aria-label="Open user menu"
                        aria-haspopup="true"
                        aria-expanded={isUserMenuOpen}
                    >
                        <UserIcon />
                    </button>
                    <div className={`absolute right-0 mt-2 w-52 bg-[#1a1a1a] border border-white/10 rounded-md shadow-lg py-1 transition-all duration-300 ease-in-out ${ isUserMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible' }`}>
                         <div className="px-4 py-2 border-b border-white/10">
                            <p className="text-sm text-gray-400">{t('welcome_back')}</p>
                            <p className="text-sm font-medium text-white truncate">{user?.displayName || user?.email}</p>
                         </div>
                         <button onClick={goToProfile} className="flex items-center w-full text-left px-4 py-2 text-sm text-[#A8A8A8] hover:bg-[#2b2b2b] hover:text-white">
                            <IdCardIcon className="mr-2"/>
                            {t('my_profile')}
                         </button>
                         <button onClick={logout} className="flex items-center w-full text-left px-4 py-2 text-sm text-[#A8A8A8] hover:bg-[#2b2b2b] hover:text-white">
                            <LogOutIcon className="mr-2"/>
                            {t('logout')}
                         </button>
                    </div>
                </div>
            ) : (
                <div className="hidden md:flex items-center space-x-4">
                  <button onClick={goToLogin} className="text-sm font-medium text-[#A8A8A8] hover:text-[#EAEAEA] transition-colors">
                    {t('login')}
                  </button>
                  <button onClick={goToSignup} className="inline-flex items-center justify-center px-4 py-2 text-sm font-medium text-[#0f0f0f] bg-[#FF6A00] border border-transparent rounded-md shadow-sm hover:bg-[#ff8533] transition-colors">
                    {t('signup')}
                  </button>
                </div>
            )}
            
            <div className="relative" ref={wishlistRef}>
              <button
                onClick={toggleWishlist}
                className="flex items-center justify-center w-10 h-10 rounded-full text-[#A8A8A8] hover:bg-[#2b2b2b] hover:text-white transition-colors focus:outline-none"
                aria-label="Open wishlist"
                aria-haspopup="true"
                aria-expanded={isWishlistOpen}
              >
                <HeartIcon />
                {wishlistItems.length > 0 && (
                  <span className="absolute -top-1 -right-1 flex items-center justify-center w-5 h-5 text-xs font-bold text-white bg-[#FF6A00] rounded-full">
                    {wishlistItems.length}
                  </span>
                )}
              </button>
              <div className={`transition-all duration-300 ease-in-out ${isWishlistOpen ? 'opacity-100 visible' : 'opacity-0 invisible'}`}>
                <WishlistPanel />
              </div>
            </div>

            <div className="relative" ref={cartRef}>
              <button
                onClick={toggleCart}
                className="flex items-center justify-center w-10 h-10 rounded-full text-[#A8A8A8] hover:bg-[#2b2b2b] hover:text-white transition-colors focus:outline-none"
                aria-label="Open shopping cart"
                aria-haspopup="true"
                aria-expanded={isCartOpen}
              >
                <ShoppingCartIcon />
                {cartItems.length > 0 && (
                  <span className="absolute -top-1 -right-1 flex items-center justify-center w-5 h-5 text-xs font-bold text-white bg-[#FF6A00] rounded-full">
                    {cartItems.length}
                  </span>
                )}
              </button>
              <div className={`transition-all duration-300 ease-in-out ${isCartOpen ? 'opacity-100 visible' : 'opacity-0 invisible'}`}>
                <MiniCart />
              </div>
            </div>

            <div className="relative" ref={langDropdownRef}>
              <button
                onClick={toggleLangDropdown}
                className="flex items-center justify-center w-10 h-10 rounded-full text-[#A8A8A8] hover:bg-[#2b2b2b] hover:text-white transition-colors focus:outline-none"
                aria-label="Open language selection"
                aria-haspopup="true"
                aria-expanded={isLangDropdownOpen}
              >
                <GlobeIcon />
              </button>
              <div
                className={`absolute right-0 mt-2 w-28 bg-[#1a1a1a] border border-white/10 rounded-md shadow-lg py-1 transition-all duration-300 ease-in-out ${
                  isLangDropdownOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
                }`}
              >
                <button onClick={() => handleLocaleChange('vi')} className={`block w-full text-left px-4 py-2 text-sm ${locale === 'vi' ? 'text-white' : 'text-[#A8A8A8]'} hover:bg-[#2b2b2b]`}>
                  Tiếng Việt
                </button>
                <button onClick={() => handleLocaleChange('en')} className={`block w-full text-left px-4 py-2 text-sm ${locale === 'en' ? 'text-white' : 'text-[#A8A8A8]'} hover:bg-[#2b2b2b]`}>
                  English
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;