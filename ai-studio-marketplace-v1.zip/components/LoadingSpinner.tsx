import React from 'react';
import SpinnerIcon from './icons/SpinnerIcon';

const LoadingSpinner: React.FC = () => {
  return (
    <div className="flex justify-center items-center w-full h-full min-h-[60vh]">
      <SpinnerIcon className="w-12 h-12 animate-spin text-[#FF6A00]" />
    </div>
  );
};

export default React.memo(LoadingSpinner);
