

import React from 'react';
import { useI18n } from '../hooks/useI18n';
import ArrowRightIcon from './icons/ArrowRightIcon';
import { useApp } from '../hooks/useApp';

const Hero: React.FC = () => {
  const { t } = useI18n();
  const { goToMarketplace, goToSignup } = useApp();

  return (
    <div className="relative overflow-hidden bg-black">
      <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
      <div className="absolute inset-0 bg-gradient-to-b from-[#0f0f0f] via-transparent to-[#0f0f0f]"></div>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="pt-24 pb-32 sm:pt-32 sm:pb-40 text-center">
          <h1 className="text-4xl sm:text-5xl lg:text-7xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-gray-200 to-gray-400">
            {t('hero_headline')}
          </h1>
          <p className="mt-6 max-w-2xl mx-auto text-lg text-[#A8A8A8]">
            {t('hero_subheadline')}
          </p>
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={goToMarketplace}
              className="group inline-flex items-center justify-center px-8 py-3 text-base font-medium text-black bg-[#FF6A00] border border-transparent rounded-md shadow-sm hover:shadow-lg hover:shadow-[#FF6A00]/40 transition-all duration-300 transform hover:-translate-y-1 w-full sm:w-auto"
            >
              {t('hero_cta_explore')}
              <ArrowRightIcon className="ml-2 transition-transform duration-300 group-hover:translate-x-1" />
            </button>
            <button
              onClick={goToSignup}
              className="group relative inline-flex items-center justify-center px-8 py-3 text-base font-medium text-white bg-transparent border border-[#2b2b2b] rounded-md hover:border-white/50 transition-all duration-300 w-full sm:w-auto overflow-hidden"
            >
              <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent transition-all duration-700 transform -translate-x-full group-hover:translate-x-full ease-out"></span>
              <span className="relative flex items-center">
                {t('hero_cta_signup')}{' '}
                <ArrowRightIcon className="ml-2 transition-transform duration-300 group-hover:translate-x-1" />
              </span>
            </button>
          </div>
        </div>
         <div className="relative w-full h-64 -mt-20">
            <div className="absolute inset-0 bg-gradient-to-t from-[#0f0f0f] to-transparent z-10"></div>
            <div className="absolute inset-0 animate-pulse-slow">
                <div className="absolute top-1/2 left-1/2 w-96 h-96 bg-[#FF6A00]/10 rounded-full -translate-x-1/2 -translate-y-1/2 blur-3xl"></div>
                <div className="absolute top-1/2 left-1/4 w-80 h-80 bg-blue-500/10 rounded-full -translate-x-1/2 -translate-y-1/2 blur-3xl"></div>
                <div className="absolute top-1/3 right-1/4 w-72 h-72 bg-purple-500/10 rounded-full -translate-x-1/2 -translate-y-1/2 blur-3xl"></div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;